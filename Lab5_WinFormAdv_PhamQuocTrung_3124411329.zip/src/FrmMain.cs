// Lab 5D - Bài tập về nhà - Bài 2: Form main (MDI) có MenuStrip gắn tất cả bài tập
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Lab5
{
    public class FrmMain : Form
    {
        private readonly Timer timerDongHo = new Timer { Interval = 1000 };
        private ToolStripStatusLabel lblGio;

        public FrmMain()
        {
            Text = "Lab 5 - Lập trình WinForm nâng cao | Phạm Quốc Trung - 3124411329";
            Font = UI.FontChung;
            IsMdiContainer = true;
            WindowState = FormWindowState.Maximized;
            StartPosition = FormStartPosition.CenterScreen;
            Size = new Size(1100, 750);

            var menu = new MenuStrip();

            var mnu5C = new ToolStripMenuItem("Lab 5&C");
            mnu5C.DropDownItems.Add("Trên lớp - Bài 1: Ước số", null, (s, e) => HienForm<FrmUocSo>());
            mnu5C.DropDownItems.Add("Trên lớp - Bài 2: Danh sách lớp (TreeView)", null, (s, e) => HienForm<FrmLopHoc>());
            mnu5C.DropDownItems.Add(new ToolStripSeparator());
            mnu5C.DropDownItems.Add("Nâng cao - Bài 1: Xử lý chuỗi", null, (s, e) => HienForm<FrmXuLyChuoi>());
            mnu5C.DropDownItems.Add(new ToolStripSeparator());
            mnu5C.DropDownItems.Add("Về nhà - Bài 1: Từ điển", null, (s, e) => HienForm<FrmTuDien>());
            mnu5C.DropDownItems.Add("Về nhà - Bài 2: Số tự nhiên", null, (s, e) => HienForm<FrmSoTuNhien>());
            mnu5C.DropDownItems.Add("Về nhà - Bài 3: Danh bạ", null, (s, e) => HienForm<FrmDanhBa>());

            var mnu5D = new ToolStripMenuItem("Lab 5&D");
            mnu5D.DropDownItems.Add("Trên lớp - Bài 1: Sinh viên (ListView)", null, (s, e) => HienForm<FrmSinhVienListView>());
            mnu5D.DropDownItems.Add("Trên lớp - Bài 2: Tài khoản ngân hàng", null, (s, e) => HienForm<FrmNganHang>());
            mnu5D.DropDownItems.Add(new ToolStripSeparator());
            mnu5D.DropDownItems.Add("Nâng cao - Bài 1: Học viên lớp A/B", null, (s, e) => HienForm<FrmHocVien>());
            mnu5D.DropDownItems.Add(new ToolStripSeparator());
            mnu5D.DropDownItems.Add("Về nhà - Bài 1: Đếm ngược", null, (s, e) => HienForm<FrmDemNguoc>());

            var mnuCSDL = new ToolStripMenuItem("&ADO.NET (CSDL)");
            mnuCSDL.DropDownItems.Add("Trên lớp - Bài 1: Môn học", null, (s, e) => HienForm<FrmMonHoc>());
            mnuCSDL.DropDownItems.Add("Nâng cao - Bài 1: Sinh viên", null, (s, e) => HienForm<FrmSinhVienCSDL>());
            mnuCSDL.DropDownItems.Add("Nâng cao - Bài 2: Điểm", null, (s, e) => HienForm<FrmDiem>());
            mnuCSDL.DropDownItems.Add("Về nhà - Bài 1: Lớp", null, (s, e) => HienForm<FrmLop>());

            var mnuCuaSo = new ToolStripMenuItem("Cửa &sổ");
            mnuCuaSo.DropDownItems.Add("Xếp chồng", null, (s, e) => LayoutMdi(MdiLayout.Cascade));
            mnuCuaSo.DropDownItems.Add("Xếp ngang", null, (s, e) => LayoutMdi(MdiLayout.TileHorizontal));
            mnuCuaSo.DropDownItems.Add("Đóng tất cả", null, (s, e) => { foreach (Form f in MdiChildren) f.Close(); });
            mnuCuaSo.DropDownItems.Add(new ToolStripSeparator());

            var mnuThoat = new ToolStripMenuItem("&Thoát", null, (s, e) => Close());

            menu.Items.AddRange(new ToolStripItem[] { mnu5C, mnu5D, mnuCSDL, mnuCuaSo, mnuThoat });
            menu.MdiWindowListItem = mnuCuaSo; // tự liệt kê các form con đang mở
            MainMenuStrip = menu;
            Controls.Add(menu);

            var thanhTrangThai = new StatusStrip();
            thanhTrangThai.Items.Add(new ToolStripStatusLabel("Sinh viên: Phạm Quốc Trung - MSSV: 3124411329") { Spring = true, TextAlign = ContentAlignment.MiddleLeft });
            lblGio = new ToolStripStatusLabel(DateTime.Now.ToString("HH:mm:ss  dd/MM/yyyy"));
            thanhTrangThai.Items.Add(lblGio);
            Controls.Add(thanhTrangThai);

            timerDongHo.Tick += (s, e) => lblGio.Text = DateTime.Now.ToString("HH:mm:ss  dd/MM/yyyy");
            timerDongHo.Start();

            FormClosing += (s, e) =>
            {
                if (!UI.Hoi("Thoát chương trình?")) e.Cancel = true;
            };
        }

        /// <summary>Mở form con trong MDI; nếu form đã mở thì đưa lên trước, không mở trùng.</summary>
        private void HienForm<T>() where T : Form, new()
        {
            foreach (Form f in MdiChildren)
            {
                if (f is T)
                {
                    if (f.WindowState == FormWindowState.Minimized) f.WindowState = FormWindowState.Normal;
                    f.Activate();
                    return;
                }
            }
            var moi = new T { MdiParent = this };
            moi.Show();
        }
    }
}
