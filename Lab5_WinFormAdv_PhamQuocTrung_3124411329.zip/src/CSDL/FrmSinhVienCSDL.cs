// ADO.NET - Bài tập nâng cao - Bài 1: Quản lý sinh viên (bảng SinhVien)
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Windows.Forms;

namespace Lab5
{
    public class FrmSinhVienCSDL : FrmCSDLCoSo
    {
        private TextBox txtMaLop, txtMaSV, txtTenSV, txtNgaySinh;

        public FrmSinhVienCSDL() : base("CSDL - Nâng cao Bài 1: Quản lý sinh viên",
            "SELECT MaSinhVien AS [Mã SV], HoTen AS [Tên sinh viên], CONVERT(varchar(10), NgaySinh, 103) AS [Ngày sinh], MaLop AS [Mã lớp] FROM SinhVien", 225)
        {
            UI.Nhan(this, "Mã lớp:", 15, 15);
            txtMaLop = UI.O(this, 135, 15, 200);
            UI.Nhan(this, "Mã sinh viên:", 15, 55);
            txtMaSV = UI.O(this, 135, 55, 200);
            UI.Nhan(this, "Tên sinh viên:", 15, 95);
            txtTenSV = UI.O(this, 135, 95, 300);
            UI.Nhan(this, "Ngày sinh:", 15, 135);
            txtNgaySinh = UI.O(this, 135, 135, 200);
            UI.Nhan(this, "(dd/MM/yyyy)", 345, 135, 120);

            UI.Nut(this, "Thêm", 135, 178, 100, 34, Them_Click);
            UI.Nut(this, "Xóa", 245, 178, 100, 34, Xoa_Click);
            UI.Nut(this, "Sửa", 355, 178, 100, 34, Sua_Click);
            UI.Nut(this, "Làm trống", 465, 178, 110, 34, (s, e) => LamTrong(txtMaLop, txtMaSV, txtTenSV, txtNgaySinh));
        }

        private bool DocNgay(out DateTime ngay)
        {
            if (DateTime.TryParseExact(txtNgaySinh.Text.Trim(), new[] { "dd/MM/yyyy", "d/M/yyyy" },
                    CultureInfo.InvariantCulture, DateTimeStyles.None, out ngay) && ngay < DateTime.Today)
                return true;
            UI.CanhBao("Ngày sinh không hợp lệ (định dạng dd/MM/yyyy, phải trước hôm nay)!", txtNgaySinh);
            return false;
        }

        private bool LopTonTai()
        {
            if (CSDL.TonTai("SELECT COUNT(*) FROM Lop WHERE MaLop = @l", CSDL.TS("@l", txtMaLop.Text.Trim()))) return true;
            UI.CanhBao("Mã lớp không tồn tại trong bảng Lop!", txtMaLop);
            return false;
        }

        private void Them_Click(object sender, EventArgs e)
        {
            foreach (TextBox t in new[] { txtMaLop, txtMaSV, txtTenSV, txtNgaySinh })
                if (Rong(t)) { UI.CanhBao("Mã lớp, Mã sinh viên, Tên sinh viên, Ngày sinh không được để trống!", t); return; }
            DateTime ngay;
            if (!DocNgay(out ngay)) return;
            try
            {
                if (!LopTonTai()) return;
                if (CSDL.TonTai("SELECT COUNT(*) FROM SinhVien WHERE MaSinhVien = @m", CSDL.TS("@m", txtMaSV.Text.Trim())))
                { UI.CanhBao("Mã sinh viên đã tồn tại!", txtMaSV); return; }

                CSDL.ThucThi("INSERT INTO SinhVien (MaSinhVien, HoTen, NgaySinh, MaLop) VALUES (@m, @t, @n, @l)",
                    CSDL.TS("@m", txtMaSV.Text.Trim()), CSDL.TS("@t", txtTenSV.Text.Trim()),
                    CSDL.TS("@n", ngay), CSDL.TS("@l", txtMaLop.Text.Trim()));
                UI.ThongBao("Thêm sinh viên thành công!");
                LamTrong(txtMaLop, txtMaSV, txtTenSV, txtNgaySinh);
                TaiLai();
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }

        private void Xoa_Click(object sender, EventArgs e)
        {
            if (Rong(txtMaSV) || Rong(txtTenSV)) { UI.CanhBao("Mã sinh viên và Tên sinh viên không được để trống!", Rong(txtMaSV) ? txtMaSV : txtTenSV); return; }
            if (!Rong(txtMaLop) || !Rong(txtNgaySinh)) { UI.CanhBao("Khi xóa không nhập Mã lớp và Ngày sinh!"); return; }
            if (!UI.Hoi("Xóa sinh viên " + txtMaSV.Text.Trim() + " - " + txtTenSV.Text.Trim() + "?")) return;
            try
            {
                int n = CSDL.ThucThi("DELETE FROM SinhVien WHERE MaSinhVien = @m AND HoTen = @t",
                    CSDL.TS("@m", txtMaSV.Text.Trim()), CSDL.TS("@t", txtTenSV.Text.Trim()));
                if (n == 0) UI.CanhBao("Không có sinh viên nào trùng cả mã và tên vừa nhập!");
                else { UI.ThongBao("Xóa thành công!"); LamTrong(txtMaLop, txtMaSV, txtTenSV, txtNgaySinh); TaiLai(); }
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }

        private void Sua_Click(object sender, EventArgs e)
        {
            if (Rong(txtMaSV)) { UI.CanhBao("Mã sinh viên không được để trống!", txtMaSV); return; }
            if (Rong(txtMaLop) && Rong(txtTenSV) && Rong(txtNgaySinh))
            { UI.CanhBao("Phải nhập ít nhất một trong các trường: Mã lớp, Tên sinh viên, Ngày sinh!", txtMaLop); return; }

            // Chỉ cập nhật những trường có nhập dữ liệu
            var cot = new List<string>();
            var ts = new List<SqlParameter> { CSDL.TS("@m", txtMaSV.Text.Trim()) };
            try
            {
                if (!Rong(txtMaLop))
                {
                    if (!LopTonTai()) return;
                    cot.Add("MaLop = @l"); ts.Add(CSDL.TS("@l", txtMaLop.Text.Trim()));
                }
                if (!Rong(txtTenSV)) { cot.Add("HoTen = @t"); ts.Add(CSDL.TS("@t", txtTenSV.Text.Trim())); }
                if (!Rong(txtNgaySinh))
                {
                    DateTime ngay;
                    if (!DocNgay(out ngay)) return;
                    cot.Add("NgaySinh = @n"); ts.Add(CSDL.TS("@n", ngay));
                }

                int n = CSDL.ThucThi("UPDATE SinhVien SET " + string.Join(", ", cot) + " WHERE MaSinhVien = @m", ts.ToArray());
                if (n == 0) UI.CanhBao("Không tìm thấy sinh viên có mã này!");
                else { UI.ThongBao("Sửa thành công!"); LamTrong(txtMaLop, txtMaSV, txtTenSV, txtNgaySinh); TaiLai(); }
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }
    }
}
