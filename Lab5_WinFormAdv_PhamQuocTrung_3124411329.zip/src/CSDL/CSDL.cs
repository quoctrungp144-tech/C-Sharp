// Lớp truy cập CSDL QLSinhVien dùng chung cho các form ADO.NET
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace Lab5
{
    internal static class CSDL
    {
        // Sửa "Data Source" cho đúng tên SQL Server trên máy (VD: .\SQLEXPRESS hoặc (localdb)\MSSQLLocalDB)
        public static string ChuoiKetNoi = @"Data Source=.\SQLEXPRESS;Initial Catalog=QLSinhVien;Integrated Security=True";

        /// <summary>Thực thi INSERT / UPDATE / DELETE, trả về số dòng bị ảnh hưởng.</summary>
        public static int ThucThi(string sql, params SqlParameter[] thamSo)
        {
            using (var conn = new SqlConnection(ChuoiKetNoi))
            using (var cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddRange(thamSo);
                conn.Open();
                return cmd.ExecuteNonQuery();
            }
        }

        /// <summary>Thực thi câu truy vấn trả về 1 giá trị (COUNT, SUM...).</summary>
        public static object LayGiaTri(string sql, params SqlParameter[] thamSo)
        {
            using (var conn = new SqlConnection(ChuoiKetNoi))
            using (var cmd = new SqlCommand(sql, conn))
            {
                cmd.Parameters.AddRange(thamSo);
                conn.Open();
                return cmd.ExecuteScalar();
            }
        }

        public static bool TonTai(string sql, params SqlParameter[] thamSo)
        {
            return Convert.ToInt32(LayGiaTri(sql, thamSo)) > 0;
        }

        public static DataTable LayBang(string sql)
        {
            using (var da = new SqlDataAdapter(sql, ChuoiKetNoi))
            {
                var bang = new DataTable();
                da.Fill(bang);
                return bang;
            }
        }

        public static SqlParameter TS(string ten, object giaTri)
        {
            return new SqlParameter(ten, giaTri ?? DBNull.Value);
        }

        /// <summary>Thông báo lỗi SQL dễ hiểu cho người dùng.</summary>
        public static void BaoLoi(SqlException ex)
        {
            string noiDung;
            switch (ex.Number)
            {
                case 2627: case 2601: noiDung = "Dữ liệu bị trùng khóa chính!"; break;
                case 547: noiDung = "Vi phạm ràng buộc khóa ngoại (dữ liệu đang được bảng khác tham chiếu hoặc mã tham chiếu không tồn tại)."; break;
                case 2: case 53: case 4060: noiDung = "Không kết nối được CSDL. Hãy kiểm tra chuỗi kết nối trong CSDL.cs."; break;
                default: noiDung = ex.Message; break;
            }
            MessageBox.Show("Thất bại: " + noiDung, "Lỗi CSDL", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    /// <summary>Form cơ sở: có sẵn DataGridView để xem dữ liệu bảng sau mỗi thao tác.</summary>
    public class FrmCSDLCoSo : Form
    {
        protected DataGridView dgvDuLieu;
        private readonly string cauXem;

        public FrmCSDLCoSo(string tieuDe, string cauLenhXem, int caoPhanNhap)
        {
            cauXem = cauLenhXem;
            UI.CauHinhForm(this, tieuDe, 640, caoPhanNhap + 250);
            dgvDuLieu = new DataGridView
            {
                Location = new Point(15, caoPhanNhap), Size = new Size(610, 235),
                ReadOnly = true, AllowUserToAddRows = false, AllowUserToDeleteRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect, MultiSelect = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, BackgroundColor = SystemColors.Window
            };
            Controls.Add(dgvDuLieu);
            Load += (s, e) => TaiLai();
        }

        protected void TaiLai()
        {
            try { dgvDuLieu.DataSource = CSDL.LayBang(cauXem); }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }

        protected static bool Rong(TextBox t) { return t.Text.Trim() == ""; }

        protected static void LamTrong(params TextBox[] ds)
        {
            foreach (TextBox t in ds) t.Clear();
            if (ds.Length > 0) ds[0].Focus();
        }
    }
}
