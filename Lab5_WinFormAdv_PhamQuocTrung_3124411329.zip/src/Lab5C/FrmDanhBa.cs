// Lab 5C - Bài tập về nhà - Bài 3: Danh bạ theo chữ cái đầu của tên
using System;
using System.Drawing;
using System.Globalization;
using System.Text;
using System.Windows.Forms;

namespace Lab5
{
    public class FrmDanhBa : Form
    {
        private TreeView trvDanhBa;
        private TextBox txtTen, txtHo, txtDienThoai;

        public FrmDanhBa()
        {
            UI.CauHinhForm(this, "5C - Về nhà Bài 3: Danh bạ", 640, 460);

            var anh = new ImageList { ImageSize = new Size(16, 16) };
            anh.Images.Add(VeBieuTuong(Color.Goldenrod, true));   // 0: nhóm chữ cái
            anh.Images.Add(VeBieuTuong(Color.SteelBlue, false));  // 1: liên hệ

            trvDanhBa = new TreeView { Location = new Point(15, 15), Size = new Size(290, 430), ImageList = anh, HideSelection = false };
            Controls.Add(trvDanhBa);

            var grp = new GroupBox { Text = "Thông tin liên hệ", Location = new Point(320, 15), Size = new Size(305, 200) };
            UI.Nhan(grp, "Tên (First):", 10, 30, 100);
            txtTen = UI.O(grp, 115, 30, 175);
            UI.Nhan(grp, "Họ (Last):", 10, 75, 100);
            txtHo = UI.O(grp, 115, 75, 175);
            UI.Nhan(grp, "Điện thoại:", 10, 120, 100);
            txtDienThoai = UI.O(grp, 115, 120, 175);
            Controls.Add(grp);

            AcceptButton = UI.Nut(this, "Thêm (Add)", 320, 230, 145, 40, Them_Click);
            UI.Nut(this, "Thoát (Exit)", 480, 230, 145, 40, (s, e) => Close());

            // Khi load: TreeView chứa các chữ cái A -> Z
            trvDanhBa.BeginUpdate();
            for (char c = 'A'; c <= 'Z'; c++)
                trvDanhBa.Nodes.Add(c.ToString(), c.ToString(), 0, 0);
            trvDanhBa.EndUpdate();

            UI.XacNhanKhiDong(this);
        }

        private static Bitmap VeBieuTuong(Color mau, bool laThuMuc)
        {
            var bmp = new Bitmap(16, 16);
            using (Graphics g = Graphics.FromImage(bmp))
            using (var co = new SolidBrush(mau))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                if (laThuMuc)
                {
                    g.FillRectangle(co, 1, 3, 7, 3);
                    g.FillRectangle(co, 1, 5, 14, 9);
                }
                else
                {
                    g.FillEllipse(co, 5, 1, 6, 6);
                    g.FillEllipse(co, 2, 8, 12, 8);
                }
            }
            return bmp;
        }

        /// <summary>Bỏ dấu tiếng Việt để lấy chữ cái đầu (VD: "Đức" -> "Duc").</summary>
        private static string BoDau(string s)
        {
            string tach = s.Normalize(NormalizationForm.FormD);
            var sb = new StringBuilder();
            foreach (char c in tach)
                if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark) sb.Append(c);
            return sb.ToString().Normalize(NormalizationForm.FormC).Replace('đ', 'd').Replace('Đ', 'D');
        }

        private void Them_Click(object sender, EventArgs e)
        {
            string ten = txtTen.Text.Trim(), ho = txtHo.Text.Trim(), dt = txtDienThoai.Text.Trim();
            if (ten == "") { UI.CanhBao("Tên (First name) không được để trống!", txtTen); return; }
            if (ho == "") { UI.CanhBao("Họ (Last name) không được để trống!", txtHo); return; }

            string chuDau = BoDau(ten).Substring(0, 1).ToUpper();
            if (chuDau[0] < 'A' || chuDau[0] > 'Z') { UI.CanhBao("Tên phải bắt đầu bằng chữ cái!", txtTen); return; }

            string hienThi = ten + " " + ho + (dt != "" ? "  (" + dt + ")" : "");
            TreeNode nhom = trvDanhBa.Nodes[chuDau];
            foreach (TreeNode n in nhom.Nodes)
                if (string.Compare(n.Text, hienThi, true) == 0) { UI.CanhBao("Liên hệ này đã có trong danh bạ!"); return; }

            TreeNode moi = nhom.Nodes.Add(hienThi, hienThi, 1, 1);
            nhom.Expand();
            trvDanhBa.SelectedNode = moi;

            txtTen.Clear(); txtHo.Clear(); txtDienThoai.Clear();
            txtTen.Focus();
        }
    }
}
