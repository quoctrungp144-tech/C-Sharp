// Lab 5C - Bài tập về nhà - Bài 1: Từ điển Anh - Việt và Việt - Anh
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Lab5
{
    public class MucTu
    {
        public string Tu { get; set; }
        public string Nghia { get; set; }
        public MucTu(string tu, string nghia) { Tu = tu; Nghia = nghia; }
        public override string ToString() { return Tu; }
    }

    public class FrmTuDien : Form
    {
        // Danh sách các từ lưu sẵn vào List
        private readonly List<MucTu> anhViet = new List<MucTu>
        {
            new MucTu("apple", "quả táo"), new MucTu("book", "quyển sách"), new MucTu("computer", "máy tính"),
            new MucTu("dog", "con chó"), new MucTu("engineer", "kỹ sư"), new MucTu("family", "gia đình"),
            new MucTu("garden", "khu vườn"), new MucTu("happy", "vui vẻ"), new MucTu("keyboard", "bàn phím"),
            new MucTu("library", "thư viện"), new MucTu("mouse", "con chuột"), new MucTu("network", "mạng lưới"),
            new MucTu("program", "chương trình"), new MucTu("school", "trường học"), new MucTu("student", "sinh viên"),
            new MucTu("teacher", "giáo viên"), new MucTu("window", "cửa sổ"), new MucTu("world", "thế giới")
        };

        private readonly List<MucTu> vietAnh = new List<MucTu>
        {
            new MucTu("bàn phím", "keyboard"), new MucTu("cửa sổ", "window"), new MucTu("con chó", "dog"),
            new MucTu("con chuột", "mouse"), new MucTu("gia đình", "family"), new MucTu("giáo viên", "teacher"),
            new MucTu("khu vườn", "garden"), new MucTu("kỹ sư", "engineer"), new MucTu("máy tính", "computer"),
            new MucTu("mạng lưới", "network"), new MucTu("quả táo", "apple"), new MucTu("quyển sách", "book"),
            new MucTu("sinh viên", "student"), new MucTu("thế giới", "world"), new MucTu("thư viện", "library"),
            new MucTu("trường học", "school"), new MucTu("vui vẻ", "happy")
        };

        public FrmTuDien()
        {
            UI.CauHinhForm(this, "5C - Về nhà Bài 1: Từ điển", 640, 400);

            var tab = new TabControl { Location = new Point(10, 10), Size = new Size(620, 335) };
            var tabAV = new TabPage("Anh - Việt");
            var tabVA = new TabPage("Việt - Anh");
            TaoTrangTraTu(tabAV, anhViet, "Từ tiếng Anh:", "Nghĩa tiếng Việt:");
            TaoTrangTraTu(tabVA, vietAnh, "Từ tiếng Việt:", "Nghĩa tiếng Anh:");
            tab.TabPages.Add(tabAV);
            tab.TabPages.Add(tabVA);
            Controls.Add(tab);

            UI.Nut(this, "Thoát", 500, 355, 130, 36, (s, e) => Close());
            UI.XacNhanKhiDong(this);
        }

        /// <summary>Tạo giao diện tra từ cho một TabPage ứng với một bộ từ điển.</summary>
        private void TaoTrangTraTu(TabPage trang, List<MucTu> tuDien, string nhanTu, string nhanNghia)
        {
            tuDien.Sort((a, b) => string.Compare(a.Tu, b.Tu, StringComparison.CurrentCultureIgnoreCase));

            UI.Nhan(trang, nhanTu, 10, 12, 200);
            var cboTu = new ComboBox
            {
                Location = new Point(10, 40), Width = 230,
                AutoCompleteMode = AutoCompleteMode.SuggestAppend,
                AutoCompleteSource = AutoCompleteSource.ListItems
            };
            var lstTu = new ListBox { Location = new Point(10, 75), Size = new Size(230, 220) };
            foreach (MucTu m in tuDien) { cboTu.Items.Add(m.Tu); lstTu.Items.Add(m.Tu); }
            trang.Controls.Add(cboTu);
            trang.Controls.Add(lstTu);

            UI.Nhan(trang, nhanNghia, 330, 12, 200);
            var txtNghia = new TextBox { Location = new Point(330, 40), Size = new Size(270, 150), Multiline = true, ReadOnly = true, Font = new Font("Segoe UI", 13F) };
            trang.Controls.Add(txtNghia);
            var btnEnter = UI.Nut(trang, "Enter", 250, 38, 70, 30);

            Action traTu = () =>
            {
                string tu = cboTu.Text.Trim();
                if (tu == "") { UI.CanhBao("Hãy nhập từ cần tra!", cboTu); return; }
                MucTu kq = tuDien.Find(m => string.Equals(m.Tu, tu, StringComparison.CurrentCultureIgnoreCase));
                txtNghia.Text = kq != null ? kq.Nghia : "Không tìm thấy từ \"" + tu + "\" trong từ điển.";
            };

            // Gõ tới đâu, ListBox tự nhảy tới từ khớp gần nhất tới đó
            cboTu.TextChanged += (s, e) =>
            {
                if (cboTu.Text == "") { lstTu.ClearSelected(); return; }
                int viTri = lstTu.FindString(cboTu.Text);
                if (viTri != ListBox.NoMatches) lstTu.SelectedIndex = viTri;
            };
            cboTu.KeyDown += (s, e) =>
            {
                if (e.KeyCode == Keys.Enter) { traTu(); e.SuppressKeyPress = true; }
            };
            btnEnter.Click += (s, e) => traTu();
            lstTu.DoubleClick += (s, e) =>
            {
                if (lstTu.SelectedItem == null) return;
                cboTu.Text = lstTu.SelectedItem.ToString();
                traTu();
            };
        }
    }
}
