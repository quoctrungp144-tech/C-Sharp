// Lab 5C - Bài tập trên lớp - Bài 1: Ước số
using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Lab5
{
    public class FrmUocSo : Form
    {
        private TextBox txtNhapSo;
        private ComboBox cboDanhSachSo;
        private ListBox lstUocSo;

        public FrmUocSo()
        {
            UI.CauHinhForm(this, "5C - Bài 1: Danh sách ước số", 600, 360);

            UI.Nhan(this, "Nhập số:", 20, 20, 80);
            txtNhapSo = UI.O(this, 105, 20, 150);
            var btnCapNhat = UI.Nut(this, "&Cập nhật", 270, 17, 110, 32, CapNhat_Click);
            AcceptButton = btnCapNhat;

            UI.Nhan(this, "Chọn số:", 20, 65, 80);
            cboDanhSachSo = new ComboBox { Location = new Point(105, 65), Width = 150, DropDownStyle = ComboBoxStyle.DropDownList };
            cboDanhSachSo.SelectedIndexChanged += DanhSachSo_SelectedIndexChanged;
            Controls.Add(cboDanhSachSo);

            var grp = new GroupBox { Text = "Các ước số", Location = new Point(400, 15), Size = new Size(180, 325) };
            lstUocSo = new ListBox { Location = new Point(10, 25), Size = new Size(160, 290) };
            grp.Controls.Add(lstUocSo);
            Controls.Add(grp);

            UI.Nut(this, "&Tổng các ước số", 20, 120, 360, 36, TongUoc_Click);
            UI.Nut(this, "Số lượng các ước số c&hẵn", 20, 165, 360, 36, DemUocChan_Click);
            UI.Nut(this, "Số lượng các ước số &nguyên tố", 20, 210, 360, 36, DemUocNguyenTo_Click);
            UI.Nut(this, "Th&oát", 20, 290, 120, 36, (s, e) => Close());

            UI.XacNhanKhiDong(this);
        }

        private void CapNhat_Click(object sender, EventArgs e)
        {
            int so;
            if (!int.TryParse(txtNhapSo.Text.Trim(), out so) || so <= 0)
            {
                UI.CanhBao("Vui lòng nhập một số nguyên dương!", txtNhapSo);
                txtNhapSo.SelectAll();
                return;
            }
            if (cboDanhSachSo.Items.Contains(so))
            {
                UI.CanhBao("Số " + so + " đã có trong danh sách.", txtNhapSo);
                txtNhapSo.SelectAll();
                return;
            }
            cboDanhSachSo.Items.Add(so);
            txtNhapSo.Clear();
            txtNhapSo.Focus();
        }

        private void DanhSachSo_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstUocSo.Items.Clear();
            if (cboDanhSachSo.SelectedItem == null) return;
            int n = (int)cboDanhSachSo.SelectedItem;
            for (int i = 1; i * i <= n; i++)
            {
                if (n % i != 0) continue;
                lstUocSo.Items.Add(i);
                if (i != n / i) lstUocSo.Items.Add(n / i);
            }
            // sắp xếp tăng dần để hiển thị đẹp
            var sapXep = lstUocSo.Items.Cast<int>().OrderBy(x => x).ToArray();
            lstUocSo.Items.Clear();
            foreach (int u in sapXep) lstUocSo.Items.Add(u);
        }

        private bool ChuaCoUoc()
        {
            if (lstUocSo.Items.Count == 0)
            {
                UI.CanhBao("Hãy chọn một số trong ComboBox trước.");
                return true;
            }
            return false;
        }

        private void TongUoc_Click(object sender, EventArgs e)
        {
            if (ChuaCoUoc()) return;
            long tong = 0;
            foreach (int u in lstUocSo.Items) tong += u;
            UI.ThongBao("Tổng các ước số của " + cboDanhSachSo.SelectedItem + " là: " + tong);
        }

        private void DemUocChan_Click(object sender, EventArgs e)
        {
            if (ChuaCoUoc()) return;
            int dem = lstUocSo.Items.Cast<int>().Count(u => u % 2 == 0);
            UI.ThongBao("Số lượng ước số chẵn: " + dem);
        }

        private void DemUocNguyenTo_Click(object sender, EventArgs e)
        {
            if (ChuaCoUoc()) return;
            int dem = 0;
            foreach (int u in lstUocSo.Items)
                if (LaNguyenTo(u)) dem++;
            UI.ThongBao("Số lượng ước số nguyên tố: " + dem);
        }

        private static bool LaNguyenTo(int x)
        {
            if (x < 2) return false;
            for (int i = 2; i * i <= x; i++)
                if (x % i == 0) return false;
            return true;
        }
    }
}
