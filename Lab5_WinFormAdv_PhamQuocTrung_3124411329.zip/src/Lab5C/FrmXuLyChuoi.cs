// Lab 5C - Bài tập nâng cao - Bài 1: Xử lý chuỗi họ tên trên ListBox
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace Lab5
{
    public class FrmXuLyChuoi : Form
    {
        private static readonly string[] HO = { "Lê", "Nguyễn", "Lý", "Trần", "Lâm", "Hồ", "Lai", "Huỳnh", "La" };
        private static readonly string[] TENLOT = { "Quang", "Thành", "Ngọc", "Anh", "Xuân", "Bảo", "Cẩm", "Thị", "Kim", "Thái", "Hồng" };
        private static readonly string[] TEN = { "Hà", "Danh", "Sơn", "Mai", "Thắng", "Kỳ", "Thành", "Lâm", "Tâm", "Phụng", "Thắm" };

        private readonly Random rnd = new Random();
        private readonly TextInfo vanBanVN = new CultureInfo("vi-VN").TextInfo;
        private ListBox lstHoTen;
        private Label lblSoLuong;

        public FrmXuLyChuoi()
        {
            UI.CauHinhForm(this, "5C - Nâng cao: Xử lý chuỗi", 640, 470);

            lstHoTen = new ListBox { Location = new Point(15, 15), Size = new Size(300, 410), SelectionMode = SelectionMode.MultiExtended };
            lstHoTen.MouseDoubleClick += LstHoTen_MouseDoubleClick;
            Controls.Add(lstHoTen);
            lblSoLuong = UI.Nhan(this, "Số phần tử: 0", 15, 432, 300);

            int x = 330, y = 15, r = 295, h = 40, k = 47;
            UI.Nut(this, "Nhập ngẫu nhiên 50 tên", x, y, r, h, NgauNhien_Click);
            UI.Nut(this, "Xóa phần tử đang chọn", x, y += k, r, h, XoaDangChon_Click);
            UI.Nut(this, "Xóa người có họ \"Lê\"", x, y += k, r, h, (s, e) => XoaTheoDieuKien(t => TachTu(t)[0] == "Lê", "họ Lê"));
            UI.Nut(this, "Xóa người có tên \"Sơn\"", x, y += k, r, h, (s, e) => XoaTheoDieuKien(t => { var a = TachTu(t); return a[a.Length - 1] == "Sơn"; }, "tên Sơn"));
            UI.Nut(this, "CHUYỂN THÀNH CHỮ HOA", x, y += k, r, h, (s, e) => DoiChuoi(t => t.ToUpper()));
            UI.Nut(this, "chuyển thành chữ thường", x, y += k, r, h, (s, e) => DoiChuoi(t => t.ToLower()));
            UI.Nut(this, "Viết Hoa Đầu Mỗi Từ", x, y += k, r, h, (s, e) => DoiChuoi(t => vanBanVN.ToTitleCase(t.ToLower())));
            UI.Nut(this, "Xóa tất cả", x, y += k, r, h, XoaTatCa_Click);
            UI.Nhan(this, "(Double-click vào một tên để sửa)", x, y + k, r);

            UI.XacNhanKhiDong(this);
        }

        private static string[] TachTu(string hoTen)
        {
            return hoTen.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        }

        private void CapNhatSoLuong()
        {
            lblSoLuong.Text = "Số phần tử: " + lstHoTen.Items.Count;
        }

        private void NgauNhien_Click(object sender, EventArgs e)
        {
            // Dùng HashSet để 50 tên thêm vào không trùng nhau và không trùng tên đã có
            var daCo = new HashSet<string>();
            foreach (object o in lstHoTen.Items) daCo.Add(o.ToString());

            int daThem = 0;
            lstHoTen.BeginUpdate();
            while (daThem < 50)
            {
                string ten = HO[rnd.Next(HO.Length)] + " " + TENLOT[rnd.Next(TENLOT.Length)] + " " + TEN[rnd.Next(TEN.Length)];
                if (daCo.Add(ten))
                {
                    lstHoTen.Items.Add(ten);
                    daThem++;
                }
            }
            lstHoTen.EndUpdate();
            CapNhatSoLuong();
        }

        private void XoaDangChon_Click(object sender, EventArgs e)
        {
            if (lstHoTen.SelectedIndices.Count == 0) { UI.CanhBao("Chưa chọn phần tử nào!"); return; }
            // Xóa từ cuối lên đầu để chỉ số không bị lệch
            for (int i = lstHoTen.SelectedIndices.Count - 1; i >= 0; i--)
                lstHoTen.Items.RemoveAt(lstHoTen.SelectedIndices[i]);
            CapNhatSoLuong();
        }

        private void XoaTheoDieuKien(Func<string, bool> dieuKien, string moTa)
        {
            int dem = 0;
            for (int i = lstHoTen.Items.Count - 1; i >= 0; i--)
            {
                // so sánh không phân biệt hoa thường (vì có thể đã đổi sang chữ hoa)
                string chuan = vanBanVN.ToTitleCase(lstHoTen.Items[i].ToString().ToLower());
                if (dieuKien(chuan))
                {
                    lstHoTen.Items.RemoveAt(i);
                    dem++;
                }
            }
            CapNhatSoLuong();
            UI.ThongBao("Đã xóa " + dem + " người có " + moTa + ".");
        }

        private void DoiChuoi(Func<string, string> bienDoi)
        {
            if (lstHoTen.Items.Count == 0) { UI.CanhBao("Danh sách đang rỗng!"); return; }
            var viTri = new List<int>();
            if (lstHoTen.SelectedIndices.Count > 0)
                foreach (int i in lstHoTen.SelectedIndices) viTri.Add(i);
            else
                for (int i = 0; i < lstHoTen.Items.Count; i++) viTri.Add(i); // không chọn -> áp dụng cho tất cả

            foreach (int i in viTri)
                lstHoTen.Items[i] = bienDoi(lstHoTen.Items[i].ToString());
            foreach (int i in viTri)
                lstHoTen.SetSelected(i, true);
        }

        private void XoaTatCa_Click(object sender, EventArgs e)
        {
            if (lstHoTen.Items.Count > 0 && UI.Hoi("Xóa toàn bộ danh sách?"))
            {
                lstHoTen.Items.Clear();
                CapNhatSoLuong();
            }
        }

        private void LstHoTen_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            int i = lstHoTen.IndexFromPoint(e.Location);
            if (i == ListBox.NoMatches) return;
            string moi = HopNhap.Hien("Sửa họ tên", lstHoTen.Items[i].ToString());
            if (moi == null) return;
            moi = string.Join(" ", TachTu(moi));
            if (moi == "") { UI.CanhBao("Họ tên không được rỗng!"); return; }
            lstHoTen.Items[i] = moi;
        }
    }
}
