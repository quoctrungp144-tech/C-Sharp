// Lab 5C - Bài tập về nhà - Bài 2: Xử lý danh sách số tự nhiên trên ListBox
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Lab5
{
    public class FrmSoTuNhien : Form
    {
        private TextBox txtSo;
        private ListBox lstSo;

        public FrmSoTuNhien()
        {
            UI.CauHinhForm(this, "5C - Về nhà Bài 2: Số tự nhiên", 560, 470);

            UI.Nhan(this, "Nhập số N:", 15, 15, 85);
            txtSo = UI.O(this, 105, 15, 120);
            AcceptButton = UI.Nut(this, "Nhập", 235, 12, 80, 32, Nhap_Click);

            lstSo = new ListBox { Location = new Point(15, 60), Size = new Size(300, 390), SelectionMode = SelectionMode.MultiExtended };
            Controls.Add(lstSo);

            int x = 335, y = 60, r = 210, h = 38, k = 45;
            UI.Nut(this, "Tổng các phần tử", x, y, r, h, Tong_Click);
            UI.Nut(this, "Xóa phần tử đầu và cuối", x, y += k, r, h, XoaDauCuoi_Click);
            UI.Nut(this, "Xóa phần tử đang chọn", x, y += k, r, h, XoaDangChon_Click);
            UI.Nut(this, "Tăng mỗi phần tử lên 2", x, y += k, r, h, (s, e) => BienDoi(v => checked(v + 2)));
            UI.Nut(this, "Thay bằng bình phương", x, y += k, r, h, (s, e) => BienDoi(v => checked(v * v)));
            UI.Nut(this, "Chọn số chẵn", x, y += k, r, h, (s, e) => ChonTheo(v => v % 2 == 0, "chẵn"));
            UI.Nut(this, "Chọn số lẻ", x, y += k, r, h, (s, e) => ChonTheo(v => v % 2 != 0, "lẻ"));
            UI.Nut(this, "Kết thúc", x, y += k + 15, r, h, (s, e) => Close());

            UI.XacNhanKhiDong(this);
        }

        private void Nhap_Click(object sender, EventArgs e)
        {
            long n;
            if (!long.TryParse(txtSo.Text.Trim(), out n) || n < 0)
            {
                UI.CanhBao("N phải là số tự nhiên (số nguyên >= 0)!", txtSo);
                txtSo.SelectAll();
                return;
            }
            lstSo.Items.Add(n);
            txtSo.Clear();
            txtSo.Focus();
        }

        private bool Rong()
        {
            if (lstSo.Items.Count > 0) return false;
            UI.CanhBao("ListBox chưa có phần tử nào!", txtSo);
            return true;
        }

        private void Tong_Click(object sender, EventArgs e)
        {
            if (Rong()) return;
            long tong = 0;
            try
            {
                foreach (long v in lstSo.Items) tong = checked(tong + v);
                UI.ThongBao("Tổng các phần tử trong ListBox = " + tong);
            }
            catch (OverflowException) { UI.CanhBao("Tổng quá lớn, bị tràn số!"); }
        }

        private void XoaDauCuoi_Click(object sender, EventArgs e)
        {
            if (Rong()) return;
            lstSo.Items.RemoveAt(lstSo.Items.Count - 1);
            if (lstSo.Items.Count > 0) lstSo.Items.RemoveAt(0);
        }

        private void XoaDangChon_Click(object sender, EventArgs e)
        {
            if (Rong()) return;
            if (lstSo.SelectedIndices.Count == 0) { UI.CanhBao("Hãy chọn phần tử cần xóa!"); return; }
            while (lstSo.SelectedIndices.Count > 0)
                lstSo.Items.RemoveAt(lstSo.SelectedIndices[0]);
        }

        private void BienDoi(Func<long, long> phepToan)
        {
            if (Rong()) return;
            long[] moi = new long[lstSo.Items.Count];
            try
            {
                for (int i = 0; i < moi.Length; i++) moi[i] = phepToan((long)lstSo.Items[i]);
            }
            catch (OverflowException)
            {
                UI.CanhBao("Có giá trị quá lớn, không thể thực hiện!");
                return;
            }
            lstSo.BeginUpdate();
            for (int i = 0; i < moi.Length; i++) lstSo.Items[i] = moi[i];
            lstSo.EndUpdate();
        }

        private void ChonTheo(Func<long, bool> dieuKien, string ten)
        {
            if (Rong()) return;
            lstSo.ClearSelected();
            int dem = 0;
            for (int i = 0; i < lstSo.Items.Count; i++)
                if (dieuKien((long)lstSo.Items[i])) { lstSo.SetSelected(i, true); dem++; }
            if (dem == 0) UI.ThongBao("Không có số " + ten + " nào trong danh sách.");
        }
    }
}
