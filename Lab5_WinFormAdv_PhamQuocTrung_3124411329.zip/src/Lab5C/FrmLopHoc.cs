// Lab 5C - Bài tập trên lớp - Bài 2: Quản lý lớp - sinh viên bằng TreeView
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Lab5
{
    public class FrmLopHoc : Form
    {
        private const string TIEN_TO_TEN = "Họ tên: ";
        private const string TIEN_TO_DIA_CHI = "Địa chỉ: ";

        private TreeView trvLop;
        private CheckBox chkThemLop;
        private GroupBox grpThongTinLop;
        private TextBox txtTenLop, txtMaSV, txtHoTen, txtDiaChi;
        private ComboBox cboLop;

        public FrmLopHoc()
        {
            UI.CauHinhForm(this, "5C - Bài 2: Danh sách lớp", 720, 430);

            var grpDs = new GroupBox { Text = "Danh sách lớp", Location = new Point(15, 10), Size = new Size(280, 405) };
            trvLop = new TreeView { Location = new Point(10, 25), Size = new Size(260, 370), HideSelection = false };
            trvLop.AfterSelect += TrvLop_AfterSelect;
            grpDs.Controls.Add(trvLop);
            Controls.Add(grpDs);

            chkThemLop = new CheckBox { Text = "Thêm lớp", Location = new Point(310, 15), AutoSize = true };
            chkThemLop.CheckedChanged += (s, e) => grpThongTinLop.Visible = chkThemLop.Checked;
            Controls.Add(chkThemLop);

            grpThongTinLop = new GroupBox { Text = "Thông tin lớp", Location = new Point(310, 45), Size = new Size(395, 75), Visible = false };
            UI.Nhan(grpThongTinLop, "Tên lớp:", 10, 30, 70);
            txtTenLop = UI.O(grpThongTinLop, 85, 30, 170);
            UI.Nut(grpThongTinLop, "Thêm lớp", 265, 26, 115, 32, ThemLop_Click);
            Controls.Add(grpThongTinLop);

            var grpSV = new GroupBox { Text = "Thông tin sinh viên", Location = new Point(310, 130), Size = new Size(395, 220) };
            UI.Nhan(grpSV, "Chọn lớp:", 10, 30);
            cboLop = new ComboBox { Location = new Point(125, 30), Width = 255, DropDownStyle = ComboBoxStyle.DropDownList };
            grpSV.Controls.Add(cboLop);
            UI.Nhan(grpSV, "Mã sinh viên:", 10, 75);
            txtMaSV = UI.O(grpSV, 125, 75, 255);
            UI.Nhan(grpSV, "Họ và tên:", 10, 120);
            txtHoTen = UI.O(grpSV, 125, 120, 255);
            UI.Nhan(grpSV, "Địa chỉ:", 10, 165);
            txtDiaChi = UI.O(grpSV, 125, 165, 255);
            Controls.Add(grpSV);

            UI.Nut(this, "Cập nhật", 310, 365, 125, 38, CapNhat_Click);
            UI.Nut(this, "Xóa", 445, 365, 125, 38, Xoa_Click);
            UI.Nut(this, "Thoát", 580, 365, 125, 38, (s, e) => Close());

            // Một số lớp có sẵn khi form hiện lên
            foreach (string lop in new[] { "12DHTH01", "12DHTH02", "12DHTH03" })
            {
                trvLop.Nodes.Add(lop);
                cboLop.Items.Add(lop);
            }
            cboLop.SelectedIndex = 0;

            UI.XacNhanKhiDong(this);
        }

        private TreeNode TimLop(string tenLop)
        {
            foreach (TreeNode nut in trvLop.Nodes)
                if (string.Compare(nut.Text, tenLop, true) == 0) return nut;
            return null;
        }

        private bool TrungMaSV(string maSV)
        {
            foreach (TreeNode lop in trvLop.Nodes)
                foreach (TreeNode sv in lop.Nodes)
                    if (string.Compare(sv.Text, maSV, true) == 0) return true;
            return false;
        }

        private void ThemLop_Click(object sender, EventArgs e)
        {
            string ten = txtTenLop.Text.Trim();
            if (ten == "") { UI.CanhBao("Chưa nhập tên lớp!", txtTenLop); return; }
            if (TimLop(ten) != null) { UI.CanhBao("Lớp \"" + ten + "\" đã tồn tại!", txtTenLop); return; }

            trvLop.Nodes.Add(ten);
            cboLop.Items.Add(ten);
            cboLop.SelectedItem = ten;
            txtTenLop.Clear();
            UI.ThongBao("Đã thêm lớp " + ten);
        }

        private void CapNhat_Click(object sender, EventArgs e)
        {
            if (cboLop.SelectedItem == null) { UI.CanhBao("Hãy chọn lớp!", cboLop); return; }
            TextBox[] bat = { txtMaSV, txtHoTen, txtDiaChi };
            foreach (TextBox t in bat)
                if (t.Text.Trim() == "") { UI.CanhBao("Vui lòng nhập đầy đủ thông tin sinh viên!", t); return; }

            string ma = txtMaSV.Text.Trim();
            if (TrungMaSV(ma)) { UI.CanhBao("Mã sinh viên " + ma + " đã tồn tại!", txtMaSV); return; }

            TreeNode lop = TimLop(cboLop.SelectedItem.ToString());
            TreeNode nutSV = lop.Nodes.Add(ma);
            nutSV.Nodes.Add(TIEN_TO_TEN + txtHoTen.Text.Trim());
            nutSV.Nodes.Add(TIEN_TO_DIA_CHI + txtDiaChi.Text.Trim());
            lop.ExpandAll();

            foreach (TextBox t in bat) t.Clear();
            txtMaSV.Focus();
        }

        private void Xoa_Click(object sender, EventArgs e)
        {
            TreeNode chon = trvLop.SelectedNode;
            if (chon == null || chon.Level != 1)
            {
                UI.CanhBao("Chỉ được xóa node là mã sinh viên. Hãy chọn một sinh viên!");
                return;
            }
            if (UI.Hoi("Xóa sinh viên " + chon.Text + "?"))
                chon.Remove();
        }

        private void TrvLop_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (e.Node.Level != 1) return; // chỉ xử lý node mã sinh viên
            txtMaSV.Text = e.Node.Text;
            txtHoTen.Text = e.Node.Nodes[0].Text.Substring(TIEN_TO_TEN.Length);
            txtDiaChi.Text = e.Node.Nodes[1].Text.Substring(TIEN_TO_DIA_CHI.Length);
            cboLop.SelectedItem = e.Node.Parent.Text;
        }
    }
}
