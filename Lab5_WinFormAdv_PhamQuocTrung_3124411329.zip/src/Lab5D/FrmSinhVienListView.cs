// Lab 5D - Bài tập trên lớp - Bài 1: Quản lý sinh viên bằng ListView + ContextMenuStrip
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Lab5
{
    public class FrmSinhVienListView : Form
    {
        private TextBox txtMaSV, txtHoTen;
        private DateTimePicker dtpNgaySinh;
        private RadioButton radNam, radNu;
        private ComboBox cboDanToc;
        private ListView lvSinhVien;

        public FrmSinhVienListView()
        {
            UI.CauHinhForm(this, "5D - Bài 1: Thông tin sinh viên", 780, 470);

            var grp = new GroupBox { Text = "Nhập thông tin", Location = new Point(15, 10), Size = new Size(750, 130) };
            UI.Nhan(grp, "Mã SV:", 15, 30, 80);
            txtMaSV = UI.O(grp, 100, 30, 200);
            UI.Nhan(grp, "Họ tên:", 15, 75, 80);
            txtHoTen = UI.O(grp, 100, 75, 200);

            UI.Nhan(grp, "Ngày sinh:", 330, 30, 85);
            dtpNgaySinh = new DateTimePicker { Location = new Point(420, 30), Width = 130, Format = DateTimePickerFormat.Custom, CustomFormat = "dd/MM/yyyy" };
            grp.Controls.Add(dtpNgaySinh);
            UI.Nhan(grp, "Giới tính:", 570, 30, 75);
            radNam = new RadioButton { Text = "Nam", Location = new Point(645, 20), AutoSize = true, Checked = true };
            radNu = new RadioButton { Text = "Nữ", Location = new Point(645, 45), AutoSize = true };
            grp.Controls.Add(radNam); grp.Controls.Add(radNu);

            UI.Nhan(grp, "Dân tộc:", 330, 75, 85);
            cboDanToc = new ComboBox { Location = new Point(420, 75), Width = 130, DropDownStyle = ComboBoxStyle.DropDownList };
            grp.Controls.Add(cboDanToc);
            Controls.Add(grp);

            int y = 150;
            UI.Nut(this, "Thêm", 15, y, 110, 36, Them_Click);
            UI.Nut(this, "Sửa", 135, y, 110, 36, Sua_Click);
            UI.Nut(this, "Xóa", 255, y, 110, 36, Xoa_Click);
            UI.Nut(this, "Làm mới", 375, y, 110, 36, (s, e) => LamMoi());
            UI.Nut(this, "Thoát", 655, y, 110, 36, (s, e) => Close());

            lvSinhVien = new ListView
            {
                Location = new Point(15, 195), Size = new Size(750, 260),
                View = View.Details, FullRowSelect = true, GridLines = true, MultiSelect = true, HideSelection = false
            };
            lvSinhVien.Columns.Add("Mã SV", 110);
            lvSinhVien.Columns.Add("Họ và tên", 220);
            lvSinhVien.Columns.Add("Ngày sinh", 110);
            lvSinhVien.Columns.Add("Giới tính", 90);
            lvSinhVien.Columns.Add("Dân tộc", 120);
            lvSinhVien.SelectedIndexChanged += LvSinhVien_SelectedIndexChanged;
            Controls.Add(lvSinhVien);

            // Menu chuột phải trên ListView để xóa
            var menuPhai = new ContextMenuStrip();
            var mnuXoa = new ToolStripMenuItem("Xóa sinh viên đang chọn");
            mnuXoa.Click += Xoa_Click;
            menuPhai.Items.Add(mnuXoa);
            menuPhai.Opening += (s, e) => mnuXoa.Enabled = lvSinhVien.SelectedItems.Count > 0;
            lvSinhVien.ContextMenuStrip = menuPhai;

            Load += (s, e) =>
            {
                cboDanToc.Items.AddRange(new object[] { "Kinh", "Hoa", "Khmer", "Tày", "Thái", "Mường", "Chăm", "Khác" });
                cboDanToc.SelectedIndex = 0;
            };
            UI.XacNhanKhiDong(this);
        }

        private bool TrungMa(string ma)
        {
            foreach (ListViewItem it in lvSinhVien.Items)
                if (string.Compare(it.Text, ma, true) == 0) return true;
            return false;
        }

        private string GioiTinh() { return radNam.Checked ? "Nam" : "Nữ"; }

        private bool KiemTraNhap()
        {
            if (txtMaSV.Text.Trim() == "") { UI.CanhBao("Chưa nhập mã sinh viên!", txtMaSV); return false; }
            if (txtHoTen.Text.Trim() == "") { UI.CanhBao("Chưa nhập họ tên!", txtHoTen); return false; }
            return true;
        }

        private void Them_Click(object sender, EventArgs e)
        {
            if (!KiemTraNhap()) return;
            string ma = txtMaSV.Text.Trim();
            if (TrungMa(ma)) { UI.CanhBao("Mã sinh viên " + ma + " đã tồn tại, không được thêm trùng!", txtMaSV); return; }

            var dong = new ListViewItem(new[]
            {
                ma, txtHoTen.Text.Trim(), dtpNgaySinh.Value.ToString("dd/MM/yyyy"), GioiTinh(), cboDanToc.Text
            });
            lvSinhVien.Items.Add(dong);
            LamMoi();
        }

        private void Sua_Click(object sender, EventArgs e)
        {
            if (lvSinhVien.SelectedItems.Count != 1) { UI.CanhBao("Hãy chọn đúng 1 sinh viên để sửa!"); return; }
            if (!KiemTraNhap()) return;
            ListViewItem dong = lvSinhVien.SelectedItems[0];
            // Không cho sửa mã sinh viên (cột 0)
            dong.SubItems[1].Text = txtHoTen.Text.Trim();
            dong.SubItems[2].Text = dtpNgaySinh.Value.ToString("dd/MM/yyyy");
            dong.SubItems[3].Text = GioiTinh();
            dong.SubItems[4].Text = cboDanToc.Text;
            UI.ThongBao("Đã cập nhật sinh viên " + dong.Text);
        }

        private void Xoa_Click(object sender, EventArgs e)
        {
            int soLuong = lvSinhVien.SelectedItems.Count;
            if (soLuong == 0) { UI.CanhBao("Chưa chọn sinh viên cần xóa!"); return; }
            if (!UI.Hoi("Xóa " + soLuong + " sinh viên đang chọn?")) return;
            foreach (ListViewItem it in lvSinhVien.SelectedItems) it.Remove();
            LamMoi();
        }

        private void LvSinhVien_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvSinhVien.SelectedItems.Count == 0) return;
            ListViewItem dong = lvSinhVien.SelectedItems[0];
            txtMaSV.Text = dong.SubItems[0].Text;
            txtMaSV.ReadOnly = true; // đang xem/sửa -> khóa mã SV
            txtHoTen.Text = dong.SubItems[1].Text;
            dtpNgaySinh.Value = DateTime.ParseExact(dong.SubItems[2].Text, "dd/MM/yyyy", null);
            radNam.Checked = dong.SubItems[3].Text == "Nam";
            radNu.Checked = !radNam.Checked;
            cboDanToc.Text = dong.SubItems[4].Text;
        }

        private void LamMoi()
        {
            lvSinhVien.SelectedItems.Clear();
            txtMaSV.ReadOnly = false;
            txtMaSV.Clear();
            txtHoTen.Clear();
            dtpNgaySinh.Value = DateTime.Today;
            radNam.Checked = true;
            if (cboDanToc.Items.Count > 0) cboDanToc.SelectedIndex = 0;
            txtMaSV.Focus();
        }
    }
}
