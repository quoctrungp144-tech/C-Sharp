// Lab 5D - Bài tập nâng cao - Bài 1: Quản lý học viên lớp A / lớp B bằng MenuStrip
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Lab5
{
    public class FrmHocVien : Form
    {
        public const string LOP_A = "Lớp A";
        public const string LOP_B = "Lớp B";

        private ListBox lstLopA, lstLopB;

        public FrmHocVien()
        {
            UI.CauHinhForm(this, "5D - Nâng cao: Quản lý học viên", 620, 430);

            var menu = new MenuStrip();
            var mnuCapNhat = new ToolStripMenuItem("&Cập nhật");
            mnuCapNhat.DropDownItems.Add("Xóa học viên", null, XoaHocVien_Click);
            mnuCapNhat.DropDownItems.Add("Chuyển sang lớp A", null, (s, e) => ChuyenLop(lstLopB, lstLopA, LOP_B));
            mnuCapNhat.DropDownItems.Add("Chuyển sang lớp B", null, (s, e) => ChuyenLop(lstLopA, lstLopB, LOP_A));
            mnuCapNhat.DropDownItems.Add(new ToolStripSeparator());
            mnuCapNhat.DropDownItems.Add("Nhập học viên mới", null, NhapMoi_Click);
            var mnuKetThuc = new ToolStripMenuItem("&Kết thúc", null, (s, e) => Close());
            menu.Items.Add(mnuCapNhat);
            menu.Items.Add(mnuKetThuc);
            MainMenuStrip = menu;
            Controls.Add(menu);

            lstLopA = TaoDanhSach(LOP_A, 20);
            lstLopB = TaoDanhSach(LOP_B, 315);

            lstLopA.Items.AddRange(new object[] { "Võ Minh Khang", "Đặng Thu Trang", "Bùi Gia Huy", "Phan Ngọc Hân" });
            lstLopB.Items.AddRange(new object[] { "Đỗ Quốc Bảo", "Tạ Mỹ Linh", "Châu Tuấn Kiệt", "Mai Phương Thảo" });

            UI.XacNhanKhiDong(this); // mục Kết thúc gọi Close() -> hỏi trước khi dừng
        }

        private ListBox TaoDanhSach(string tieuDe, int x)
        {
            var grp = new GroupBox { Text = tieuDe, Location = new Point(x, 40), Size = new Size(285, 370) };
            var lst = new ListBox { Location = new Point(10, 25), Size = new Size(265, 335), SelectionMode = SelectionMode.MultiExtended };
            grp.Controls.Add(lst);
            Controls.Add(grp);
            return lst;
        }

        private static void XoaMucDangChon(ListBox lst)
        {
            for (int i = lst.SelectedIndices.Count - 1; i >= 0; i--)
                lst.Items.RemoveAt(lst.SelectedIndices[i]);
        }

        private void XoaHocVien_Click(object sender, EventArgs e)
        {
            int tong = lstLopA.SelectedItems.Count + lstLopB.SelectedItems.Count;
            if (tong == 0) { UI.CanhBao("Hãy chọn học viên cần xóa trước!"); return; }
            if (!UI.Hoi("Xóa " + tong + " học viên đang chọn ở cả hai lớp?")) return;
            XoaMucDangChon(lstLopA);
            XoaMucDangChon(lstLopB);
        }

        private void ChuyenLop(ListBox nguon, ListBox dich, string tenNguon)
        {
            if (nguon.SelectedItems.Count == 0)
            {
                UI.CanhBao("Bạn phải chọn học viên trong " + tenNguon + " trước!");
                return;
            }
            var canChuyen = new List<object>();
            foreach (object o in nguon.SelectedItems) canChuyen.Add(o);
            foreach (object o in canChuyen) dich.Items.Add(o);
            XoaMucDangChon(nguon);
        }

        private void NhapMoi_Click(object sender, EventArgs e)
        {
            using (var f = new FrmNhapHocVien(this))
                f.ShowDialog(this);
        }

        /// <summary>Được form nhập gọi để thêm học viên vào lớp tương ứng.</summary>
        public void ThemHocVien(string lop, string hoTen)
        {
            ListBox dich = lop == LOP_A ? lstLopA : lstLopB;
            dich.Items.Add(hoTen);
            dich.ClearSelected();
            dich.SelectedIndex = dich.Items.Count - 1;
        }
    }

    /// <summary>Form phụ: nhập học viên mới.</summary>
    public class FrmNhapHocVien : Form
    {
        private readonly FrmHocVien formChinh;
        private TextBox txtHoTen;
        private ComboBox cboLop;

        public FrmNhapHocVien(FrmHocVien chinh)
        {
            formChinh = chinh;
            UI.CauHinhForm(this, "Nhập học viên mới", 400, 180);
            StartPosition = FormStartPosition.CenterParent;
            MinimizeBox = false;

            UI.Nhan(this, "Họ và tên:", 15, 20, 90);
            txtHoTen = UI.O(this, 110, 20, 270);
            UI.Nhan(this, "Lớp:", 15, 65, 90);
            cboLop = new ComboBox { Location = new Point(110, 65), Width = 150, DropDownStyle = ComboBoxStyle.DropDownList };
            cboLop.Items.AddRange(new object[] { FrmHocVien.LOP_A, FrmHocVien.LOP_B });
            cboLop.SelectedIndex = 0;
            Controls.Add(cboLop);

            AcceptButton = UI.Nut(this, "Cập nhật", 130, 120, 120, 36, CapNhat_Click);
            var btnTroVe = UI.Nut(this, "Trở về", 260, 120, 120, 36, (s, e) => Close());
            CancelButton = btnTroVe;
        }

        private void CapNhat_Click(object sender, EventArgs e)
        {
            string ten = txtHoTen.Text.Trim();
            if (ten == "")
            {
                UI.CanhBao("Bạn phải nhập họ và tên!", txtHoTen);
                return;
            }
            formChinh.ThemHocVien(cboLop.Text, ten);
            UI.ThongBao("Đã thêm \"" + ten + "\" vào " + cboLop.Text);
            txtHoTen.Clear();
            txtHoTen.Focus();
        }
    }
}
