// Lab 5D - Bài tập trên lớp - Bài 2: Quản lý tài khoản ngân hàng
using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace Lab5
{
    public class FrmNganHang : Form
    {
        private static readonly CultureInfo VN = new CultureInfo("vi-VN");

        private TextBox txtSoTK, txtTenKH, txtDiaChi, txtSoTien;
        private Button btnThem, btnLuu, btnXoa;
        private ListView lvTaiKhoan;
        private Label lblTongTien;

        public FrmNganHang()
        {
            UI.CauHinhForm(this, "5D - Bài 2: Quản lý tài khoản ngân hàng", 760, 500);

            var lblTieuDe = new Label { Text = "THÔNG TIN TÀI KHOẢN KHÁCH HÀNG", Font = new Font("Segoe UI", 14F, FontStyle.Bold), ForeColor = Color.DarkBlue, Location = new Point(15, 10), AutoSize = true };
            Controls.Add(lblTieuDe);

            UI.Nhan(this, "Số tài khoản:", 15, 55);
            txtSoTK = UI.O(this, 130, 55, 220);
            UI.Nhan(this, "Tên khách hàng:", 380, 55, 120);
            txtTenKH = UI.O(this, 505, 55, 240);
            UI.Nhan(this, "Địa chỉ:", 15, 95);
            txtDiaChi = UI.O(this, 130, 95, 220);
            UI.Nhan(this, "Số tiền (VNĐ):", 380, 95, 120);
            txtSoTien = UI.O(this, 505, 95, 240);

            int y = 140;
            btnThem = UI.Nut(this, "Thêm", 130, y, 120, 36, Them_Click);
            btnLuu = UI.Nut(this, "Lưu", 260, y, 120, 36, Luu_Click);
            btnXoa = UI.Nut(this, "Xóa", 390, y, 120, 36, Xoa_Click);
            UI.Nut(this, "Thoát", 625, y, 120, 36, (s, e) => Close());

            lvTaiKhoan = new ListView
            {
                Location = new Point(15, 190), Size = new Size(730, 260),
                View = View.Details, FullRowSelect = true, GridLines = true, MultiSelect = false, HideSelection = false
            };
            lvTaiKhoan.Columns.Add("STT", 50, HorizontalAlignment.Center);
            lvTaiKhoan.Columns.Add("Số tài khoản", 130);
            lvTaiKhoan.Columns.Add("Tên khách hàng", 190);
            lvTaiKhoan.Columns.Add("Địa chỉ", 190);
            lvTaiKhoan.Columns.Add("Số tiền", 145, HorizontalAlignment.Right);
            lvTaiKhoan.SelectedIndexChanged += LvTaiKhoan_SelectedIndexChanged;
            Controls.Add(lvTaiKhoan);

            lblTongTien = new Label { Location = new Point(400, 460), Size = new Size(345, 25), TextAlign = ContentAlignment.MiddleRight, Font = new Font("Segoe UI", 11F, FontStyle.Bold), ForeColor = Color.Firebrick };
            Controls.Add(lblTongTien);

            TrangThaiBanDau();
            TinhTongTien();
            UI.XacNhanKhiDong(this);
        }

        private void KhoaO(bool khoa)
        {
            foreach (TextBox t in new[] { txtSoTK, txtTenKH, txtDiaChi, txtSoTien }) t.ReadOnly = khoa;
        }

        private void XoaTrang()
        {
            foreach (TextBox t in new[] { txtSoTK, txtTenKH, txtDiaChi, txtSoTien }) t.Clear();
        }

        private void TrangThaiBanDau()
        {
            btnThem.Text = "Thêm";
            btnLuu.Enabled = false;
            btnXoa.Enabled = lvTaiKhoan.SelectedItems.Count > 0;
            KhoaO(true);
        }

        private void Them_Click(object sender, EventArgs e)
        {
            if (btnThem.Text == "Thêm")
            {
                lvTaiKhoan.SelectedItems.Clear();
                btnThem.Text = "Hủy";
                btnLuu.Enabled = true;
                btnXoa.Enabled = false;
                KhoaO(false);
                XoaTrang();
                txtSoTK.Focus();
            }
            else // đang ở chế độ Hủy
            {
                XoaTrang();
                TrangThaiBanDau();
            }
        }

        private void Luu_Click(object sender, EventArgs e)
        {
            foreach (TextBox t in new[] { txtSoTK, txtTenKH, txtDiaChi, txtSoTien })
                if (t.Text.Trim() == "") { UI.CanhBao("Vui lòng nhập đầy đủ thông tin!", t); return; }

            decimal soTien;
            if (!decimal.TryParse(txtSoTien.Text.Trim(), NumberStyles.Number, VN, out soTien) || soTien < 0)
            {
                UI.CanhBao("Số tiền phải là số không âm (VD: 1500000 hoặc 1.500.000)!", txtSoTien);
                return;
            }
            string soTK = txtSoTK.Text.Trim();
            foreach (ListViewItem it in lvTaiKhoan.Items)
                if (it.SubItems[1].Text == soTK) { UI.CanhBao("Số tài khoản " + soTK + " đã tồn tại!", txtSoTK); return; }

            var dong = new ListViewItem(new[] { "", soTK, txtTenKH.Text.Trim(), txtDiaChi.Text.Trim(), soTien.ToString("N0", VN) });
            dong.Tag = soTien; // lưu giá trị số để tính tổng chính xác
            lvTaiKhoan.Items.Add(dong);

            DanhSoThuTu();
            TinhTongTien();
            XoaTrang();
            TrangThaiBanDau();
            UI.ThongBao("Đã lưu tài khoản " + soTK);
        }

        private void Xoa_Click(object sender, EventArgs e)
        {
            if (lvTaiKhoan.SelectedItems.Count == 0) return;
            ListViewItem dong = lvTaiKhoan.SelectedItems[0];
            if (!UI.Hoi("Xóa tài khoản " + dong.SubItems[1].Text + " của khách hàng " + dong.SubItems[2].Text + "?")) return;
            dong.Remove();
            DanhSoThuTu();
            TinhTongTien();
            XoaTrang();
            TrangThaiBanDau();
        }

        private void LvTaiKhoan_SelectedIndexChanged(object sender, EventArgs e)
        {
            bool coChon = lvTaiKhoan.SelectedItems.Count > 0;
            if (coChon && btnThem.Text == "Hủy") TrangThaiBanDau(); // chọn dòng khi đang thêm -> hủy thêm
            btnXoa.Enabled = coChon;
            if (!coChon) return;
            ListViewItem dong = lvTaiKhoan.SelectedItems[0];
            txtSoTK.Text = dong.SubItems[1].Text;
            txtTenKH.Text = dong.SubItems[2].Text;
            txtDiaChi.Text = dong.SubItems[3].Text;
            txtSoTien.Text = dong.SubItems[4].Text;
        }

        private void DanhSoThuTu()
        {
            for (int i = 0; i < lvTaiKhoan.Items.Count; i++)
                lvTaiKhoan.Items[i].SubItems[0].Text = (i + 1).ToString();
        }

        private void TinhTongTien()
        {
            decimal tong = 0;
            foreach (ListViewItem it in lvTaiKhoan.Items) tong += (decimal)it.Tag;
            lblTongTien.Text = "Tổng tiền: " + tong.ToString("N0", VN) + " VNĐ";
        }
    }
}
