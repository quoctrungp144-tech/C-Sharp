// Lab 5D - Bài tập về nhà - Bài 1: Đồng hồ đếm ngược dùng Timer
using System;
using System.Drawing;
using System.Media;
using System.Windows.Forms;

namespace Lab5
{
    public class FrmDemNguoc : Form
    {
        private readonly Timer timerDem = new Timer { Interval = 1000 };
        private Label lblThoiGian;
        private NumericUpDown nudPhut;
        private ProgressBar thanhTienDo;
        private Button btnChay;
        private int tongGiay, conLai;

        public FrmDemNguoc()
        {
            UI.CauHinhForm(this, "5D - Về nhà Bài 1: Đếm ngược thời gian", 460, 300);

            UI.Nhan(this, "Số phút:", 20, 20, 70);
            nudPhut = new NumericUpDown { Location = new Point(95, 20), Width = 80, Minimum = 1, Maximum = 180, Value = 30 };
            nudPhut.ValueChanged += (s, e) => { if (!timerDem.Enabled) DatLai(); };
            Controls.Add(nudPhut);

            lblThoiGian = new Label
            {
                Location = new Point(20, 60), Size = new Size(420, 100), TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Consolas", 48F, FontStyle.Bold), BorderStyle = BorderStyle.FixedSingle, BackColor = Color.Black, ForeColor = Color.Lime
            };
            Controls.Add(lblThoiGian);

            thanhTienDo = new ProgressBar { Location = new Point(20, 170), Size = new Size(420, 20) };
            Controls.Add(thanhTienDo);

            btnChay = UI.Nut(this, "Bắt đầu", 20, 210, 130, 40, Chay_Click);
            UI.Nut(this, "Đặt lại", 165, 210, 130, 40, (s, e) => { timerDem.Stop(); DatLai(); });
            UI.Nut(this, "Thoát", 310, 210, 130, 40, (s, e) => Close());

            timerDem.Tick += TimerDem_Tick;
            FormClosed += (s, e) => timerDem.Dispose();
            DatLai();
        }

        private void DatLai()
        {
            tongGiay = (int)nudPhut.Value * 60;
            conLai = tongGiay;
            btnChay.Text = "Bắt đầu";
            nudPhut.Enabled = true;
            lblThoiGian.ForeColor = Color.Lime;
            HienThi();
        }

        private void HienThi()
        {
            lblThoiGian.Text = string.Format("{0:00}:{1:00}", conLai / 60, conLai % 60);
            thanhTienDo.Maximum = tongGiay;
            thanhTienDo.Value = conLai;
        }

        private void Chay_Click(object sender, EventArgs e)
        {
            if (timerDem.Enabled)
            {
                timerDem.Stop();
                btnChay.Text = "Tiếp tục";
                return;
            }
            if (conLai == 0) DatLai();
            nudPhut.Enabled = false;
            timerDem.Start();
            btnChay.Text = "Tạm dừng";
        }

        private void TimerDem_Tick(object sender, EventArgs e)
        {
            conLai--;
            if (conLai <= 10) lblThoiGian.ForeColor = Color.OrangeRed; // 10 giây cuối đổi màu
            HienThi();
            if (conLai > 0) return;

            timerDem.Stop();
            btnChay.Text = "Bắt đầu";
            nudPhut.Enabled = true;
            SystemSounds.Exclamation.Play();
            UI.ThongBao("Hết giờ!");
        }
    }
}
