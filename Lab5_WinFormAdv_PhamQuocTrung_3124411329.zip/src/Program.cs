// Lab 5 - Lập trình WinForm nâng cao
// Sinh viên: Phạm Quốc Trung - MSSV: 3124411329
using System;
using System.Windows.Forms;

namespace Lab5
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FrmMain());
        }
    }
}
