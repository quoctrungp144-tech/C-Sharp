using System;
using System.Drawing;
using System.Windows.Forms;

namespace Lab5
{
    /// <summary>
    /// Các hàm tiện ích dùng chung để tạo control nhanh và hiển thị thông báo.
    /// </summary>
    internal static class UI
    {
        public static readonly Font FontChung = new Font("Segoe UI", 10F);

        public static void CauHinhForm(Form f, string tieuDe, int rong, int cao)
        {
            f.Text = tieuDe;
            f.Font = FontChung;
            f.ClientSize = new Size(rong, cao);
            f.StartPosition = FormStartPosition.CenterScreen;
            f.FormBorderStyle = FormBorderStyle.FixedSingle;
            f.MaximizeBox = false;
        }

        public static Label Nhan(Control cha, string chu, int x, int y, int rong = 110)
        {
            var lbl = new Label { Text = chu, Location = new Point(x, y + 3), Size = new Size(rong, 23) };
            cha.Controls.Add(lbl);
            return lbl;
        }

        public static TextBox O(Control cha, int x, int y, int rong = 200)
        {
            var txt = new TextBox { Location = new Point(x, y), Width = rong };
            cha.Controls.Add(txt);
            return txt;
        }

        public static Button Nut(Control cha, string chu, int x, int y, int rong = 130, int cao = 34, EventHandler khiBam = null)
        {
            var btn = new Button { Text = chu, Location = new Point(x, y), Size = new Size(rong, cao) };
            if (khiBam != null) btn.Click += khiBam;
            cha.Controls.Add(btn);
            return btn;
        }

        public static void ThongBao(string noiDung)
        {
            MessageBox.Show(noiDung, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        public static void CanhBao(string noiDung, Control dua = null)
        {
            MessageBox.Show(noiDung, "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            if (dua != null) dua.Focus();
        }

        public static bool Hoi(string cauHoi)
        {
            return MessageBox.Show(cauHoi, "Xác nhận", MessageBoxButtons.YesNo,
                       MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes;
        }

        /// <summary>
        /// Gắn hộp thoại hỏi xác nhận khi người dùng đóng form.
        /// Không hỏi lại khi cả chương trình (form MDI cha) đang đóng.
        /// </summary>
        public static void XacNhanKhiDong(Form f)
        {
            f.FormClosing += (s, e) =>
            {
                if (e.CloseReason == CloseReason.MdiFormClosing || e.CloseReason == CloseReason.ApplicationExitCall)
                    return;
                if (!Hoi("Bạn có chắc muốn đóng \"" + f.Text + "\" không?"))
                    e.Cancel = true;
            };
        }
    }

    /// <summary>
    /// Hộp nhập liệu đơn giản (thay cho InputBox của VB).
    /// </summary>
    internal static class HopNhap
    {
        public static string Hien(string tieuDe, string giaTriCu)
        {
            using (var f = new Form())
            {
                UI.CauHinhForm(f, tieuDe, 380, 120);
                f.MinimizeBox = false;
                var txt = UI.O(f, 15, 20, 350);
                txt.Text = giaTriCu;
                var ok = UI.Nut(f, "Đồng ý", 150, 65, 100);
                var huy = UI.Nut(f, "Hủy", 265, 65, 100);
                ok.DialogResult = DialogResult.OK;
                huy.DialogResult = DialogResult.Cancel;
                f.AcceptButton = ok;
                f.CancelButton = huy;
                return f.ShowDialog() == DialogResult.OK ? txt.Text : null;
            }
        }
    }
}
