LAB 5 - LẬP TRÌNH WINFORM NÂNG CAO - Phạm Quốc Trung - 3124411329

CÁCH CHẠY
1. Cài Visual Studio 2022 (workload ".NET desktop development") và SQL Server (Express được).
2. Mở file src\Lab5_PhamQuocTrung.csproj bằng Visual Studio -> Build -> Run (F5).
   Lần đầu VS tự tải gói System.Data.SqlClient từ NuGet.
3. Phần ADO.NET:
   - Mở SQL Server Management Studio, chạy file QLSinhVien.sql.
   - Mở src\CSDL\CSDL.cs, sửa "Data Source=..." cho đúng tên server trên máy
     (xem tên ở màn hình đăng nhập SSMS, VD: .\SQLEXPRESS, (localdb)\MSSQLLocalDB, TEN-MAY).
4. Chạy chương trình -> chọn bài trên menu Lab 5C / Lab 5D / ADO.NET.

HOÀN THIỆN BÁO CÁO
- Mở Bao_cao_LAB_5_PhamQuocTrung.docx, thay các ô vàng "[ CHÈN ẢNH: ... ]" bằng ảnh chụp
  màn hình (Win + Shift + S) khi chạy đúng trường hợp được ghi.
- Sửa dòng "TRƯỜNG ĐẠI HỌC ..." ở trang bìa.
