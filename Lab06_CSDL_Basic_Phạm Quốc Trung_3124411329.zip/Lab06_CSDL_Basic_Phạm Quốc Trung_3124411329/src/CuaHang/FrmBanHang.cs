// Lab 6B - Bài tập về nhà: Bán hàng (tạo hóa đơn, thêm chi tiết, cập nhật tồn kho, thanh toán)
using System;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace Lab6
{
    public class FrmBanHang : Form
    {
        private Button btnTaoHD, btnThem, btnHuy, btnThanhToan;
        private TextBox txtMaHD, txtSoLuong;
        private ComboBox cboSanPham;
        private Label lblTon;
        private ListView lvChiTiet;
        private int maHD = 0; // 0 = chưa có hóa đơn đang lập

        public FrmBanHang()
        {
            UI.CauHinhForm(this, "Bán hàng", 620, 470);
            StartPosition = FormStartPosition.CenterParent;

            btnTaoHD = UI.Nut(this, "Tạo hóa đơn mới", 440, 12, 165, 34, TaoHoaDon_Click);

            var grp = new GroupBox { Text = "Chi tiết hóa đơn", Location = new Point(15, 55), Size = new Size(590, 175) };
            UI.Nhan(grp, "Mã hóa đơn:", 15, 30);
            txtMaHD = UI.O(grp, 130, 30, 150); txtMaHD.ReadOnly = true;
            UI.Nhan(grp, "Mã sản phẩm:", 15, 70);
            cboSanPham = new ComboBox { Location = new Point(130, 70), Width = 250, DropDownStyle = ComboBoxStyle.DropDownList };
            cboSanPham.SelectedIndexChanged += (s, e) => HienTon();
            grp.Controls.Add(cboSanPham);
            lblTon = UI.Nhan(grp, "", 390, 70, 190);
            lblTon.ForeColor = Color.DarkGreen;
            UI.Nhan(grp, "Số lượng:", 15, 110);
            txtSoLuong = UI.O(grp, 130, 110, 100);
            btnThem = UI.Nut(grp, "Thêm", 390, 105, 90, 32, Them_Click);
            btnHuy = UI.Nut(grp, "Hủy", 490, 105, 90, 32, Huy_Click);
            Controls.Add(grp);

            lvChiTiet = new ListView { Location = new Point(15, 240), Size = new Size(590, 170), View = View.Details, FullRowSelect = true, GridLines = true };
            lvChiTiet.Columns.Add("Mã SP", 80);
            lvChiTiet.Columns.Add("Tên sản phẩm", 330);
            lvChiTiet.Columns.Add("Số lượng", 100, HorizontalAlignment.Right);
            Controls.Add(lvChiTiet);

            btnThanhToan = UI.Nut(this, "Thanh toán", 455, 420, 150, 38, ThanhToan_Click);

            BatTat(false);
            FormClosing += FrmBanHang_FormClosing;
        }

        /// <summary>Bật/tắt các control nhập chi tiết (lúc đầu bị mờ).</summary>
        private void BatTat(bool dangLapHD)
        {
            txtMaHD.Enabled = cboSanPham.Enabled = txtSoLuong.Enabled = dangLapHD;
            btnThem.Enabled = btnHuy.Enabled = btnThanhToan.Enabled = dangLapHD;
            btnTaoHD.Enabled = !dangLapHD;
        }

        private void NapSanPham()
        {
            cboSanPham.Items.Clear();
            using (SqlConnection conn = CuaHangDB.MoKetNoi())
            using (SqlCommand cmd = CuaHangDB.Lenh(conn, "SELECT MaSP, TenSP FROM SANPHAM ORDER BY MaSP"))
            using (SqlDataReader rd = cmd.ExecuteReader())
                while (rd.Read())
                    cboSanPham.Items.Add(new SanPham { MaSP = Convert.ToInt32(rd["MaSP"]), TenSP = rd["TenSP"].ToString() });
            if (cboSanPham.Items.Count > 0) cboSanPham.SelectedIndex = 0;
        }

        private void HienTon()
        {
            var sp = cboSanPham.SelectedItem as SanPham;
            if (sp == null) { lblTon.Text = ""; return; }
            try
            {
                int ton = CuaHangDB.SoLuongTon(sp.MaSP);
                lblTon.Text = ton < 0 ? "Chưa có tồn kho hôm nay" : "Tồn hiện tại: " + ton;
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }

        private void TaoHoaDon_Click(object sender, EventArgs e)
        {
            try
            {
                if (!CuaHangDB.DaTaoTonKhoHomNay())
                {
                    UI.CanhBao("Chưa tạo tồn kho ngày hôm nay. Hãy chọn menu \"Tạo tồn kho\" trước khi bán hàng!");
                    return;
                }
                using (SqlConnection conn = CuaHangDB.MoKetNoi())
                    maHD = Convert.ToInt32(CuaHangDB.Lenh(conn,
                        "INSERT INTO HOADON (NgayTao, TinhTrangThanhToan) OUTPUT INSERTED.MaHD VALUES (@ngay, 0)", null,
                        new SqlParameter("@ngay", DateTime.Today)).ExecuteScalar());

                txtMaHD.Text = maHD.ToString();
                lvChiTiet.Items.Clear();
                NapSanPham();
                BatTat(true);
                txtSoLuong.Focus();
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }

        private void Them_Click(object sender, EventArgs e)
        {
            var sp = cboSanPham.SelectedItem as SanPham;
            if (sp == null) { UI.CanhBao("Bạn phải chọn sản phẩm!", cboSanPham); return; }
            int soLuong;
            if (!int.TryParse(txtSoLuong.Text.Trim(), out soLuong) || soLuong <= 0)
            { UI.CanhBao("Số lượng bán phải là số nguyên lớn hơn 0!", txtSoLuong); return; }

            try
            {
                using (SqlConnection conn = CuaHangDB.MoKetNoi())
                {
                    // Khóa ngoại: hóa đơn và sản phẩm phải tồn tại
                    using (SqlDataReader rd = CuaHangDB.Lenh(conn, "SELECT * FROM SANPHAM WHERE MaSP = @sp", null, new SqlParameter("@sp", sp.MaSP)).ExecuteReader())
                        if (!rd.HasRows) { UI.CanhBao("Sản phẩm không tồn tại!"); return; }
                    using (SqlDataReader rd = CuaHangDB.Lenh(conn, "SELECT * FROM HOADON WHERE MaHD = @hd", null, new SqlParameter("@hd", maHD)).ExecuteReader())
                        if (!rd.HasRows) { UI.CanhBao("Hóa đơn không tồn tại!"); return; }
                    // Khóa chính (MaHD, MaSP) không được trùng
                    using (SqlDataReader rd = CuaHangDB.Lenh(conn, "SELECT * FROM CHITIET_HOADON WHERE MaHD = @hd AND MaSP = @sp", null,
                               new SqlParameter("@hd", maHD), new SqlParameter("@sp", sp.MaSP)).ExecuteReader())
                        if (rd.HasRows) { UI.CanhBao("Sản phẩm này đã có trong hóa đơn (trùng khóa chính)!"); return; }
                }

                int ton = CuaHangDB.SoLuongTon(sp.MaSP);
                if (ton < 0) { UI.CanhBao("Sản phẩm chưa có dòng tồn kho hôm nay!"); return; }
                if (soLuong > ton) { UI.CanhBao("Số lượng bán (" + soLuong + ") vượt quá số lượng tồn (" + ton + ")!", txtSoLuong); return; }

                // Thêm chi tiết + cập nhật SLBan trong cùng transaction (Cách 1: SqlCommand Update)
                using (SqlConnection conn = CuaHangDB.MoKetNoi())
                using (SqlTransaction tran = conn.BeginTransaction())
                {
                    CuaHangDB.Lenh(conn, "INSERT INTO CHITIET_HOADON (MaHD, MaSP, SoLuong) VALUES (@hd, @sp, @sl)", tran,
                        new SqlParameter("@hd", maHD), new SqlParameter("@sp", sp.MaSP), new SqlParameter("@sl", soLuong)).ExecuteNonQuery();
                    CuaHangDB.Lenh(conn, "UPDATE TONKHO SET SLBan = SLBan + @sl WHERE MaSP = @sp AND NgayTon = @ngay", tran,
                        new SqlParameter("@sl", soLuong), new SqlParameter("@sp", sp.MaSP), new SqlParameter("@ngay", DateTime.Today)).ExecuteNonQuery();
                    tran.Commit();
                }

                lvChiTiet.Items.Add(new ListViewItem(new[] { sp.MaSP.ToString(), sp.TenSP, soLuong.ToString() }));
                txtSoLuong.Clear();
                HienTon();
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }

        /// <summary>Hủy hóa đơn đang lập: trả lại số lượng vào tồn kho, xóa chi tiết và hóa đơn.</summary>
        private bool HuyHoaDon()
        {
            try
            {
                using (SqlConnection conn = CuaHangDB.MoKetNoi())
                using (SqlTransaction tran = conn.BeginTransaction())
                {
                    CuaHangDB.Lenh(conn,
                        "UPDATE t SET t.SLBan = t.SLBan - c.SoLuong FROM TONKHO t " +
                        "JOIN CHITIET_HOADON c ON c.MaSP = t.MaSP WHERE c.MaHD = @hd AND t.NgayTon = @ngay", tran,
                        new SqlParameter("@hd", maHD), new SqlParameter("@ngay", DateTime.Today)).ExecuteNonQuery();
                    CuaHangDB.Lenh(conn, "DELETE FROM CHITIET_HOADON WHERE MaHD = @hd", tran, new SqlParameter("@hd", maHD)).ExecuteNonQuery();
                    CuaHangDB.Lenh(conn, "DELETE FROM HOADON WHERE MaHD = @hd", tran, new SqlParameter("@hd", maHD)).ExecuteNonQuery();
                    tran.Commit();
                }
                KetThucHoaDon();
                return true;
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); return false; }
        }

        private void Huy_Click(object sender, EventArgs e)
        {
            if (UI.Hoi("Hủy hóa đơn " + maHD + "? Số lượng đã bán sẽ được trả lại tồn kho."))
                if (HuyHoaDon()) UI.ThongBao("Đã hủy hóa đơn.");
        }

        private void ThanhToan_Click(object sender, EventArgs e)
        {
            if (lvChiTiet.Items.Count == 0) { UI.CanhBao("Hóa đơn chưa có sản phẩm nào!"); return; }
            try
            {
                using (SqlConnection conn = CuaHangDB.MoKetNoi())
                    CuaHangDB.Lenh(conn, "UPDATE HOADON SET TinhTrangThanhToan = 1 WHERE MaHD = @hd", null,
                        new SqlParameter("@hd", maHD)).ExecuteNonQuery();
                UI.ThongBao("Thanh toán hóa đơn " + maHD + " thành công!");
                KetThucHoaDon();
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }

        private void KetThucHoaDon()
        {
            maHD = 0;
            txtMaHD.Clear();
            txtSoLuong.Clear();
            lblTon.Text = "";
            lvChiTiet.Items.Clear();
            BatTat(false);
        }

        private void FrmBanHang_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (maHD == 0) return;
            if (!UI.Hoi("Hóa đơn " + maHD + " chưa thanh toán. Đóng form sẽ hủy hóa đơn này, tiếp tục?") || !HuyHoaDon())
                e.Cancel = true;
        }
    }
}
