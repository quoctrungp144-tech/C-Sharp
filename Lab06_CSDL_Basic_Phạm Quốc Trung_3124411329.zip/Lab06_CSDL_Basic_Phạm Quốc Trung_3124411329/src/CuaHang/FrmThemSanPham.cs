// Lab 6B - Bài tập về nhà: Thêm sản phẩm mới (đồng thời tạo dòng tồn kho)
using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Lab6
{
    public class FrmThemSanPham : Form
    {
        private TextBox txtTenSP;

        public FrmThemSanPham()
        {
            UI.CauHinhForm(this, "Thêm sản phẩm mới", 400, 130);
            StartPosition = FormStartPosition.CenterParent;
            UI.Nhan(this, "Tên sản phẩm:", 15, 20, 110);
            txtTenSP = UI.O(this, 130, 20, 250);
            AcceptButton = UI.Nut(this, "Thêm", 130, 70, 110, 34, Them_Click);
            UI.Nut(this, "Thoát", 270, 70, 110, 34, (s, e) => Close());
        }

        private void Them_Click(object sender, EventArgs e)
        {
            string ten = txtTenSP.Text.Trim();
            if (ten == "") { UI.CanhBao("Bạn phải nhập tên sản phẩm!", txtTenSP); return; }
            try
            {
                using (SqlConnection conn = CuaHangDB.MoKetNoi())
                {
                    using (SqlCommand kt = CuaHangDB.Lenh(conn, "SELECT * FROM SANPHAM WHERE TenSP = @ten", null, new SqlParameter("@ten", ten)))
                    using (SqlDataReader rd = kt.ExecuteReader())
                        if (rd.HasRows) { UI.CanhBao("Sản phẩm \"" + ten + "\" đã có!", txtTenSP); return; }

                    // Thêm sản phẩm và dòng tồn kho trong cùng một transaction
                    using (SqlTransaction tran = conn.BeginTransaction())
                    {
                        int maSP = Convert.ToInt32(CuaHangDB.Lenh(conn,
                            "INSERT INTO SANPHAM (TenSP) OUTPUT INSERTED.MaSP VALUES (@ten)", tran,
                            new SqlParameter("@ten", ten)).ExecuteScalar());
                        CuaHangDB.Lenh(conn,
                            "INSERT INTO TONKHO (MaSP, NgayTon, SLDau, SLNhap, SLBan) VALUES (@sp, @ngay, 0, 0, 0)", tran,
                            new SqlParameter("@sp", maSP), new SqlParameter("@ngay", DateTime.Today)).ExecuteNonQuery();
                        tran.Commit();
                        UI.ThongBao("Đã thêm sản phẩm mã " + maSP + " - " + ten + " (tồn kho ban đầu = 0).");
                    }
                }
                txtTenSP.Clear();
                txtTenSP.Focus();
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }
    }
}
