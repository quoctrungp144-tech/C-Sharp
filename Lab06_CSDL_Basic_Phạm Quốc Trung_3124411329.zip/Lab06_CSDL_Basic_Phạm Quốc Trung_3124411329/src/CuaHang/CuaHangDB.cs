// Lab 6B - Bài tập về nhà: truy cập CSDL QLCuaHang
using System;
using System.Data;
using System.Data.SqlClient;

namespace Lab6
{
    internal static class CuaHangDB
    {
        // Sửa "Data Source" cho đúng tên SQL Server trên máy
        public static string ChuoiKetNoi = @"Data Source=.\SQLEXPRESS;Initial Catalog=QLCuaHang;Integrated Security=True";

        public static SqlConnection MoKetNoi()
        {
            var conn = new SqlConnection(ChuoiKetNoi);
            conn.Open();
            return conn;
        }

        public static SqlCommand Lenh(SqlConnection conn, string sql, SqlTransaction tran = null, params SqlParameter[] thamSo)
        {
            var cmd = new SqlCommand(sql, conn, tran);
            cmd.Parameters.AddRange(thamSo);
            return cmd;
        }

        public static DataTable LayBang(string sql)
        {
            using (var da = new SqlDataAdapter(sql, ChuoiKetNoi))
            {
                var bang = new DataTable();
                da.Fill(bang);
                return bang;
            }
        }

        public static bool DaTaoTonKhoHomNay()
        {
            using (SqlConnection conn = MoKetNoi())
            using (SqlCommand cmd = Lenh(conn, "SELECT * FROM TONKHO WHERE NgayTon = @ngay", null, new SqlParameter("@ngay", DateTime.Today)))
            using (SqlDataReader rd = cmd.ExecuteReader())
                return rd.HasRows;
        }

        /// <summary>Số lượng tồn hiện tại của sản phẩm trong ngày hôm nay (-1 nếu chưa có dòng tồn kho).</summary>
        public static int SoLuongTon(int maSP)
        {
            const string sql = "SELECT SLDau + SLNhap - SLBan AS Ton FROM TONKHO WHERE MaSP = @sp AND NgayTon = @ngay";
            using (SqlConnection conn = MoKetNoi())
            using (SqlCommand cmd = Lenh(conn, sql, null, new SqlParameter("@sp", maSP), new SqlParameter("@ngay", DateTime.Today)))
            using (SqlDataReader rd = cmd.ExecuteReader())
                return rd.Read() ? Convert.ToInt32(rd["Ton"]) : -1;
        }
    }

    /// <summary>Một sản phẩm hiển thị trong ComboBox.</summary>
    public class SanPham
    {
        public int MaSP { get; set; }
        public string TenSP { get; set; }
        public override string ToString() { return MaSP + " - " + TenSP; }
    }
}
