// Lab 6B - Bài tập về nhà: Form chính quản lý cửa hàng (menu Tạo tồn kho / Thêm sản phẩm / Bán hàng)
using System;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace Lab6
{
    public class FrmCuaHang : Form
    {
        private DataGridView dgvTonKho;
        private Label lblNgay;

        public FrmCuaHang()
        {
            UI.CauHinhForm(this, "Quản lý cửa hàng - QLCuaHang", 720, 440);

            var menu = new MenuStrip();
            var mnuChucNang = new ToolStripMenuItem("&Chức năng");
            mnuChucNang.DropDownItems.Add("Tạo tồn kho", null, TaoTonKho_Click);
            mnuChucNang.DropDownItems.Add("Thêm sản phẩm mới", null, (s, e) => { using (var f = new FrmThemSanPham()) f.ShowDialog(this); TaiTonKho(); });
            mnuChucNang.DropDownItems.Add("Bán hàng", null, (s, e) => { using (var f = new FrmBanHang()) f.ShowDialog(this); TaiTonKho(); });
            mnuChucNang.DropDownItems.Add(new ToolStripSeparator());
            mnuChucNang.DropDownItems.Add("Thoát", null, (s, e) => Close());
            menu.Items.Add(mnuChucNang);
            MainMenuStrip = menu;
            Controls.Add(menu);

            lblNgay = UI.Nhan(this, "", 15, 35, 690);
            lblNgay.Font = new Font("Segoe UI", 11F, FontStyle.Bold);

            dgvTonKho = new DataGridView
            {
                Location = new Point(15, 70), Size = new Size(690, 355), ReadOnly = true,
                AllowUserToAddRows = false, AllowUserToDeleteRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, BackgroundColor = SystemColors.Window
            };
            Controls.Add(dgvTonKho);
            Load += (s, e) => TaiTonKho();
        }

        private void TaiTonKho()
        {
            lblNgay.Text = "Tồn kho ngày " + DateTime.Today.ToString("dd/MM/yyyy");
            try
            {
                dgvTonKho.DataSource = CuaHangDB.LayBang(
                    "SELECT t.MaSP AS [Mã SP], s.TenSP AS [Tên SP], CONVERT(varchar(10), t.NgayTon, 103) AS [Ngày tồn], " +
                    "t.SLDau AS [SL đầu], t.SLNhap AS [SL nhập], t.SLBan AS [SL bán], t.SLDau + t.SLNhap - t.SLBan AS [Còn lại] " +
                    "FROM TONKHO t JOIN SANPHAM s ON s.MaSP = t.MaSP " +
                    "WHERE t.NgayTon = CAST(GETDATE() AS date) ORDER BY t.MaSP");
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }

        /// <summary>
        /// Tạo dòng tồn kho ngày hôm nay cho tất cả sản phẩm:
        /// SLDau = SLDau + SLNhap - SLBan của ngày tồn gần nhất trước đó; SLNhap = SLBan = 0.
        /// </summary>
        private void TaoTonKho_Click(object sender, EventArgs e)
        {
            const string sql =
                "INSERT INTO TONKHO (MaSP, NgayTon, SLDau, SLNhap, SLBan) " +
                "SELECT sp.MaSP, @ngay, ISNULL(tr.SLDau + tr.SLNhap - tr.SLBan, 0), 0, 0 " +
                "FROM SANPHAM sp " +
                "OUTER APPLY (SELECT TOP 1 k.SLDau, k.SLNhap, k.SLBan FROM TONKHO k " +
                "             WHERE k.MaSP = sp.MaSP AND k.NgayTon < @ngay ORDER BY k.NgayTon DESC) tr";
            try
            {
                if (CuaHangDB.DaTaoTonKhoHomNay())
                {
                    UI.CanhBao("Tồn kho ngày " + DateTime.Today.ToString("dd/MM/yyyy") + " đã được tạo (chỉ tạo 1 lần mỗi ngày).");
                    return;
                }
                int soDong;
                using (SqlConnection conn = CuaHangDB.MoKetNoi())
                using (SqlCommand cmd = CuaHangDB.Lenh(conn, sql, null, new SqlParameter("@ngay", DateTime.Today)))
                    soDong = cmd.ExecuteNonQuery();
                UI.ThongBao("Đã tạo tồn kho cho " + soDong + " sản phẩm.");
                TaiTonKho();
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }
    }
}
