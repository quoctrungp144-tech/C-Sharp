// Lab 6B - Bài tập nâng cao - Bài 2: Danh sách điểm theo môn học trên ListView, có lọc và tính tổng
using System;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace Lab6
{
    public class FrmDiemTheoMon : Form
    {
        private ComboBox cboMonHoc;
        private ListView lvDiem;
        private TextBox txtTongDiem;

        public FrmDiemTheoMon()
        {
            UI.CauHinhForm(this, "Danh sách sinh viên", 700, 470);

            UI.Nhan(this, "Môn học:", 15, 15, 80);
            cboMonHoc = new ComboBox { Location = new Point(100, 15), Width = 250, DropDownStyle = ComboBoxStyle.DropDownList };
            Controls.Add(cboMonHoc);
            UI.Nut(this, "Lọc dữ liệu", 370, 12, 130, 32, (s, e) => HienThiDiem(cboMonHoc.Text.Trim()));

            lvDiem = new ListView
            {
                Location = new Point(15, 55), Size = new Size(670, 350),
                View = View.Details, FullRowSelect = true, GridLines = true
            };
            lvDiem.Columns.Add("STT", 50);
            lvDiem.Columns.Add("Tên SV", 200);
            lvDiem.Columns.Add("Ngày sinh", 110);
            lvDiem.Columns.Add("Tên môn học", 220);
            lvDiem.Columns.Add("Điểm", 70, HorizontalAlignment.Right);
            Controls.Add(lvDiem);

            UI.Nhan(this, "Tổng điểm:", 400, 420, 90);
            txtTongDiem = UI.O(this, 495, 420, 120);
            txtTongDiem.ReadOnly = true;

            Load += FrmDiemTheoMon_Load;
        }

        private void FrmDiemTheoMon_Load(object sender, EventArgs e)
        {
            try
            {
                cboMonHoc.Items.Clear();
                cboMonHoc.Items.Add(" "); // khoảng trắng = tất cả môn học
                using (var conn = new SqlConnection(CSDL.ChuoiKetNoi))
                using (var cmd = new SqlCommand("SELECT MaMonHoc FROM MonHoc ORDER BY MaMonHoc", conn))
                {
                    conn.Open();
                    using (SqlDataReader rd = cmd.ExecuteReader())
                        while (rd.Read()) cboMonHoc.Items.Add(rd["MaMonHoc"].ToString());
                }
                cboMonHoc.SelectedIndex = 0;
                HienThiDiem("");
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }

        /// <summary>maMH rỗng: hiển thị tất cả; ngược lại chỉ hiển thị điểm của môn đó.</summary>
        private void HienThiDiem(string maMH)
        {
            const string sql =
                "SELECT s.HoTen, s.NgaySinh, m.TenMonHoc, d.Diem " +
                "FROM Diem d JOIN SinhVien s ON s.MaSinhVien = d.MaSinhVien " +
                "JOIN MonHoc m ON m.MaMonHoc = d.MaMonHoc " +
                "WHERE @mh = '' OR d.MaMonHoc = @mh " +
                "ORDER BY s.MaSinhVien, m.MaMonHoc";

            lvDiem.Items.Clear();
            double tong = 0;
            try
            {
                using (var conn = new SqlConnection(CSDL.ChuoiKetNoi))
                using (var cmd = new SqlCommand(sql, conn))
                {
                    cmd.Parameters.Add("@mh", System.Data.SqlDbType.VarChar, 10).Value = maMH;
                    conn.Open();
                    using (SqlDataReader rd = cmd.ExecuteReader())
                    {
                        int stt = 0;
                        while (rd.Read())
                        {
                            double diem = Convert.ToDouble(rd["Diem"]);
                            tong += diem;
                            lvDiem.Items.Add(new ListViewItem(new[]
                            {
                                (++stt).ToString(), rd["HoTen"].ToString(),
                                Convert.ToDateTime(rd["NgaySinh"]).ToString("dd/MM/yyyy"),
                                rd["TenMonHoc"].ToString(), diem.ToString("0.##")
                            }));
                        }
                    }
                }
                txtTongDiem.Text = tong.ToString("0.##");
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }
    }
}
