// Lab 6B - Bài tập nâng cao - Bài 1: Hiển thị danh sách lớp trên ListView
using System;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace Lab6
{
    public class FrmDanhSachLop : Form
    {
        private ListView lvLop;

        public FrmDanhSachLop()
        {
            UI.CauHinhForm(this, "Danh sách Lớp", 620, 400);
            UI.Nut(this, "Hiển thị dữ liệu", 15, 12, 150, 34, HienThi_Click);

            lvLop = new ListView
            {
                Location = new Point(15, 55), Size = new Size(590, 280),
                View = View.Details, FullRowSelect = true, GridLines = true
            };
            lvLop.Columns.Add("STT", 50);
            lvLop.Columns.Add("Mã lớp", 110);
            lvLop.Columns.Add("Tên lớp", 300);
            lvLop.Columns.Add("Mã khoa", 100);
            Controls.Add(lvLop);

            UI.Nut(this, "Thoát", 485, 350, 120, 36, (s, e) => Close());
        }

        private void HienThi_Click(object sender, EventArgs e)
        {
            lvLop.Items.Clear();
            try
            {
                using (var conn = new SqlConnection(CSDL.ChuoiKetNoi))
                using (var cmd = new SqlCommand("SELECT MaLop, TenLop, MaKhoa FROM Lop ORDER BY MaLop", conn))
                {
                    conn.Open();
                    using (SqlDataReader rd = cmd.ExecuteReader())
                    {
                        int stt = 0;
                        while (rd.Read())
                        {
                            stt++;
                            lvLop.Items.Add(new ListViewItem(new[]
                            {
                                stt.ToString(), rd["MaLop"].ToString(), rd["TenLop"].ToString(), rd["MaKhoa"].ToString()
                            }));
                        }
                    }
                }
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }
    }
}
