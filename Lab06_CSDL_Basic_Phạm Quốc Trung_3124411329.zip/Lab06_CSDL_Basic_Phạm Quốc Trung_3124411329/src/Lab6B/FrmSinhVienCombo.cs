// Lab 6B - Bài tập tại lớp - Bài 1: Form sinh viên, mã lớp trên ComboBox
using System;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace Lab6
{
    public class FrmSinhVienCombo : FrmCSDLCoSo
    {
        private const int TUOI_TOI_THIEU = 17;
        private ComboBox cboLop;
        private TextBox txtMaSV, txtHoTen;
        private MaskedTextBox mskNgaySinh;

        public FrmSinhVienCombo() : base("6B - Bài 1: Sinh viên (ComboBox lớp)",
            "SELECT MaSinhVien AS [Mã SV], HoTen AS [Họ tên], CONVERT(varchar(10), NgaySinh, 103) AS [Ngày sinh], MaLop AS [Lớp] FROM SinhVien", 225)
        {
            UI.Nhan(this, "Lớp:", 15, 15);
            cboLop = new ComboBox { Location = new Point(130, 15), Width = 200, DropDownStyle = ComboBoxStyle.DropDownList };
            Controls.Add(cboLop);
            UI.Nhan(this, "Mã SV:", 15, 55);
            txtMaSV = UI.O(this, 130, 55, 200);
            UI.Nhan(this, "Họ tên:", 15, 95);
            txtHoTen = UI.O(this, 130, 95, 300);
            UI.Nhan(this, "Ngày sinh:", 15, 135);
            mskNgaySinh = new MaskedTextBox { Location = new Point(130, 135), Width = 120, Mask = "00/00/0000", ValidatingType = typeof(DateTime) };
            Controls.Add(mskNgaySinh);

            UI.Nut(this, "Thêm", 130, 178, 100, 34, Them_Click);
            UI.Nut(this, "Xóa", 240, 178, 100, 34, Xoa_Click);
            UI.Nut(this, "Sửa", 350, 178, 100, 34, Sua_Click);

            Load += (s, e) =>
            {
                try { CSDL.NapComboBox(cboLop, "SELECT MaLop FROM Lop ORDER BY MaLop", "MaLop"); }
                catch (SqlException ex) { CSDL.BaoLoi(ex); }
            };
        }

        private bool SinhVienTonTai(string ma)
        {
            return CSDL.CoDuLieu("SELECT * FROM SinhVien WHERE MaSinhVien = @m", CSDL.TS("@m", ma));
        }

        /// <summary>Kiểm tra đủ dữ liệu, ngày sinh hợp lệ và tuổi >= 17 (tính theo năm sinh).</summary>
        private bool KiemTraNhap(out DateTime ngaySinh)
        {
            ngaySinh = DateTime.MinValue;
            if (cboLop.SelectedItem == null) { UI.CanhBao("Bạn phải chọn Lớp!", cboLop); return false; }
            if (Rong(txtMaSV)) { UI.CanhBao("Bạn phải nhập Mã sinh viên!", txtMaSV); return false; }
            if (Rong(txtHoTen)) { UI.CanhBao("Bạn phải nhập Họ tên!", txtHoTen); return false; }
            if (!mskNgaySinh.MaskCompleted ||
                !DateTime.TryParseExact(mskNgaySinh.Text, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out ngaySinh))
            { UI.CanhBao("Ngày sinh không hợp lệ (dd/MM/yyyy)!", mskNgaySinh); return false; }

            int tuoi = DateTime.Today.Year - ngaySinh.Year;
            if (tuoi < TUOI_TOI_THIEU)
            { UI.CanhBao("Sinh viên phải từ " + TUOI_TOI_THIEU + " tuổi trở lên (hiện tại: " + tuoi + " tuổi)!", mskNgaySinh); return false; }
            return true;
        }

        private void Them_Click(object sender, EventArgs e)
        {
            DateTime ngay;
            if (!KiemTraNhap(out ngay)) return;
            try
            {
                if (SinhVienTonTai(txtMaSV.Text.Trim())) { UI.CanhBao("Mã sinh viên đã tồn tại!", txtMaSV); return; }
                CSDL.ThucThi("INSERT INTO SinhVien (MaSinhVien, HoTen, NgaySinh, MaLop) VALUES (@m, @t, @n, @l)",
                    CSDL.TS("@m", txtMaSV.Text.Trim()), CSDL.TS("@t", txtHoTen.Text.Trim()), CSDL.TS("@n", ngay), CSDL.TS("@l", cboLop.Text));
                UI.ThongBao("Thêm sinh viên thành công!");
                LamTrong(txtMaSV, txtHoTen);
                mskNgaySinh.Clear();
                TaiLai();
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }

        private void Xoa_Click(object sender, EventArgs e)
        {
            if (Rong(txtMaSV)) { UI.CanhBao("Bạn phải nhập Mã sinh viên cần xóa!", txtMaSV); return; }
            string ma = txtMaSV.Text.Trim();
            try
            {
                if (!SinhVienTonTai(ma)) { UI.CanhBao("Mã sinh viên không tồn tại!", txtMaSV); return; }
                if (CSDL.CoDuLieu("SELECT * FROM Diem WHERE MaSinhVien = @m", CSDL.TS("@m", ma)))
                { UI.CanhBao("Sinh viên " + ma + " đã có điểm (bảng Diem đang tham chiếu), không thể xóa!"); return; }
                if (!UI.Hoi("Xóa sinh viên " + ma + "?")) return;
                CSDL.ThucThi("DELETE FROM SinhVien WHERE MaSinhVien = @m", CSDL.TS("@m", ma));
                UI.ThongBao("Xóa thành công!");
                LamTrong(txtMaSV, txtHoTen);
                TaiLai();
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }

        private void Sua_Click(object sender, EventArgs e)
        {
            DateTime ngay;
            if (!KiemTraNhap(out ngay)) return;
            try
            {
                if (!SinhVienTonTai(txtMaSV.Text.Trim())) { UI.CanhBao("Mã sinh viên không tồn tại!", txtMaSV); return; }
                if (!CSDL.CoDuLieu("SELECT * FROM Lop WHERE MaLop = @l", CSDL.TS("@l", cboLop.Text)))
                { UI.CanhBao("Mã lớp không tồn tại!", cboLop); return; }
                CSDL.ThucThi("UPDATE SinhVien SET HoTen = @t, NgaySinh = @n, MaLop = @l WHERE MaSinhVien = @m",
                    CSDL.TS("@t", txtHoTen.Text.Trim()), CSDL.TS("@n", ngay), CSDL.TS("@l", cboLop.Text), CSDL.TS("@m", txtMaSV.Text.Trim()));
                UI.ThongBao("Sửa thành công!");
                LamTrong(txtMaSV, txtHoTen);
                mskNgaySinh.Clear();
                TaiLai();
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }
    }
}
