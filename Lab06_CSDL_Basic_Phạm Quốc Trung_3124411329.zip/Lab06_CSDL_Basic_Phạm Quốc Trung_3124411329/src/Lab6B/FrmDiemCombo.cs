// Lab 6B - Bài tập tại lớp - Bài 2: Cập nhật bảng Diem với ComboBox sinh viên, môn học
using System;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace Lab6
{
    public class FrmDiemCombo : FrmCSDLCoSo
    {
        private ComboBox cboSinhVien, cboMonHoc;
        private TextBox txtDiem;

        public FrmDiemCombo() : base("6B - Bài 2: Cập nhật điểm (ComboBox)",
            "SELECT MaSinhVien AS [Mã SV], MaMonHoc AS [Mã môn], Diem AS [Điểm] FROM Diem ORDER BY MaSinhVien, MaMonHoc", 185)
        {
            UI.Nhan(this, "Sinh viên:", 15, 15);
            cboSinhVien = new ComboBox { Location = new Point(130, 15), Width = 200, DropDownStyle = ComboBoxStyle.DropDownList };
            Controls.Add(cboSinhVien);
            UI.Nhan(this, "Môn học:", 15, 55);
            cboMonHoc = new ComboBox { Location = new Point(130, 55), Width = 200, DropDownStyle = ComboBoxStyle.DropDownList };
            Controls.Add(cboMonHoc);
            UI.Nhan(this, "Điểm:", 15, 95);
            txtDiem = UI.O(this, 130, 95, 100);
            UI.Nhan(this, "(0 - 10)", 240, 95, 80);

            UI.Nut(this, "Thêm", 130, 138, 100, 34, Them_Click);
            UI.Nut(this, "Xóa", 240, 138, 100, 34, Xoa_Click);
            UI.Nut(this, "Sửa", 350, 138, 100, 34, Sua_Click);

            Load += (s, e) =>
            {
                try
                {
                    CSDL.NapComboBox(cboSinhVien, "SELECT MaSinhVien FROM SinhVien ORDER BY MaSinhVien", "MaSinhVien");
                    CSDL.NapComboBox(cboMonHoc, "SELECT MaMonHoc FROM MonHoc ORDER BY MaMonHoc", "MaMonHoc");
                }
                catch (SqlException ex) { CSDL.BaoLoi(ex); }
            };
        }

        private bool ChonDu()
        {
            if (cboSinhVien.SelectedItem == null) { UI.CanhBao("Bạn phải chọn Sinh viên!", cboSinhVien); return false; }
            if (cboMonHoc.SelectedItem == null) { UI.CanhBao("Bạn phải chọn Môn học!", cboMonHoc); return false; }
            return true;
        }

        private bool DocDiem(out double diem)
        {
            diem = 0;
            if (Rong(txtDiem)) { UI.CanhBao("Bạn phải nhập Điểm!", txtDiem); return false; }
            string s = txtDiem.Text.Trim().Replace(',', '.');
            if (!double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out diem) || diem < 0 || diem > 10)
            { UI.CanhBao("Điểm phải là số trong khoảng 0 - 10!", txtDiem); return false; }
            return true;
        }

        private SqlParameter[] KhoaChinh()
        {
            return new[] { CSDL.TS("@sv", cboSinhVien.Text), CSDL.TS("@mh", cboMonHoc.Text) };
        }

        private bool DaCoDiem()
        {
            return CSDL.CoDuLieu("SELECT * FROM Diem WHERE MaSinhVien = @sv AND MaMonHoc = @mh", KhoaChinh());
        }

        /// <summary>Kiểm tra khóa ngoại: mã SV và mã MH phải có trong CSDL.</summary>
        private bool KhoaNgoaiHopLe()
        {
            if (!CSDL.CoDuLieu("SELECT * FROM SinhVien WHERE MaSinhVien = @sv", CSDL.TS("@sv", cboSinhVien.Text)))
            { UI.CanhBao("Mã sinh viên không tồn tại trong CSDL!"); return false; }
            if (!CSDL.CoDuLieu("SELECT * FROM MonHoc WHERE MaMonHoc = @mh", CSDL.TS("@mh", cboMonHoc.Text)))
            { UI.CanhBao("Mã môn học không tồn tại trong CSDL!"); return false; }
            return true;
        }

        private void Them_Click(object sender, EventArgs e)
        {
            double diem;
            if (!ChonDu() || !DocDiem(out diem)) return;
            try
            {
                if (!KhoaNgoaiHopLe()) return;
                if (DaCoDiem()) { UI.CanhBao("Trùng khóa chính: sinh viên " + cboSinhVien.Text + " đã có điểm môn " + cboMonHoc.Text + "!"); return; }
                CSDL.ThucThi("INSERT INTO Diem (MaSinhVien, MaMonHoc, Diem) VALUES (@sv, @mh, @d)",
                    CSDL.TS("@sv", cboSinhVien.Text), CSDL.TS("@mh", cboMonHoc.Text), CSDL.TS("@d", diem));
                UI.ThongBao("Thêm điểm thành công!");
                txtDiem.Clear();
                TaiLai();
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }

        private void Xoa_Click(object sender, EventArgs e)
        {
            if (!ChonDu()) return;
            try
            {
                if (!DaCoDiem()) { UI.CanhBao("Không có dòng điểm này để xóa!"); return; }
                if (!UI.Hoi("Xóa điểm môn " + cboMonHoc.Text + " của sinh viên " + cboSinhVien.Text + "?")) return;
                CSDL.ThucThi("DELETE FROM Diem WHERE MaSinhVien = @sv AND MaMonHoc = @mh", KhoaChinh());
                UI.ThongBao("Xóa thành công!");
                txtDiem.Clear();
                TaiLai();
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }

        private void Sua_Click(object sender, EventArgs e)
        {
            double diem;
            if (!ChonDu() || !DocDiem(out diem)) return;
            try
            {
                if (!KhoaNgoaiHopLe()) return;
                if (!DaCoDiem()) { UI.CanhBao("Sinh viên chưa có điểm môn này, hãy dùng Thêm!"); return; }
                CSDL.ThucThi("UPDATE Diem SET Diem = @d WHERE MaSinhVien = @sv AND MaMonHoc = @mh",
                    CSDL.TS("@d", diem), CSDL.TS("@sv", cboSinhVien.Text), CSDL.TS("@mh", cboMonHoc.Text));
                UI.ThongBao("Sửa điểm thành công!");
                txtDiem.Clear();
                TaiLai();
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }
    }
}
