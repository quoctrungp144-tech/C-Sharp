// Lab 6B - Bài tập mẫu 2: Quản lý lớp, mã khoa hiển thị trên ComboBox (SqlDataReader)
using System;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace Lab6
{
    public class FrmLopCombo : FrmCSDLCoSo
    {
        private ComboBox cboKhoa;
        private TextBox txtMaLop, txtTenLop;

        public FrmLopCombo() : base("6B - Mẫu 2: Quản lý lớp (ComboBox khoa)",
            "SELECT MaLop AS [Mã lớp], TenLop AS [Tên lớp], MaKhoa AS [Mã khoa] FROM Lop", 185)
        {
            UI.Nhan(this, "Khoa:", 15, 15);
            cboKhoa = new ComboBox { Location = new Point(130, 15), Width = 200, DropDownStyle = ComboBoxStyle.DropDownList };
            Controls.Add(cboKhoa);
            UI.Nhan(this, "Mã lớp:", 15, 55);
            txtMaLop = UI.O(this, 130, 55, 200);
            UI.Nhan(this, "Tên lớp:", 15, 95);
            txtTenLop = UI.O(this, 130, 95, 300);

            UI.Nut(this, "Thêm", 130, 138, 100, 34, Them_Click);
            UI.Nut(this, "Xóa", 240, 138, 100, 34, Xoa_Click);
            UI.Nut(this, "Sửa", 350, 138, 100, 34, Sua_Click);

            Load += (s, e) =>
            {
                try { CSDL.NapComboBox(cboKhoa, "SELECT MaKhoa FROM Khoa ORDER BY MaKhoa", "MaKhoa"); }
                catch (SqlException ex) { CSDL.BaoLoi(ex); }
            };
        }

        /// <summary>true nếu mã lớp CHƯA tồn tại (thêm được).</summary>
        private bool KT_KhoaChinh(string maLop)
        {
            return !CSDL.CoDuLieu("SELECT * FROM Lop WHERE MaLop = @l", CSDL.TS("@l", maLop));
        }

        private void Them_Click(object sender, EventArgs e)
        {
            if (cboKhoa.SelectedItem == null) { UI.CanhBao("Bạn phải chọn Khoa!", cboKhoa); return; }
            if (Rong(txtMaLop)) { UI.CanhBao("Bạn phải nhập Mã lớp!", txtMaLop); return; }
            if (Rong(txtTenLop)) { UI.CanhBao("Bạn phải nhập Tên lớp!", txtTenLop); return; }
            try
            {
                if (!KT_KhoaChinh(txtMaLop.Text.Trim())) { UI.CanhBao("Trùng mã lớp!", txtMaLop); return; }
                CSDL.ThucThi("INSERT INTO Lop (MaLop, TenLop, MaKhoa) VALUES (@l, @t, @k)",
                    CSDL.TS("@l", txtMaLop.Text.Trim()), CSDL.TS("@t", txtTenLop.Text.Trim()), CSDL.TS("@k", cboKhoa.Text));
                UI.ThongBao("Thêm lớp thành công!");
                LamTrong(txtMaLop, txtTenLop);
                TaiLai();
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }

        private void Xoa_Click(object sender, EventArgs e)
        {
            if (Rong(txtMaLop)) { UI.CanhBao("Bạn phải nhập Mã lớp cần xóa!", txtMaLop); return; }
            string ma = txtMaLop.Text.Trim();
            try
            {
                if (KT_KhoaChinh(ma)) { UI.CanhBao("Mã lớp không tồn tại!", txtMaLop); return; }
                // kiểm tra khóa ngoại: lớp còn sinh viên thì không xóa
                if (CSDL.CoDuLieu("SELECT * FROM SinhVien WHERE MaLop = @l", CSDL.TS("@l", ma)))
                { UI.CanhBao("Lớp " + ma + " đang có sinh viên, không thể xóa!"); return; }
                if (!UI.Hoi("Xóa lớp " + ma + "?")) return;
                CSDL.ThucThi("DELETE FROM Lop WHERE MaLop = @l", CSDL.TS("@l", ma));
                UI.ThongBao("Xóa thành công!");
                LamTrong(txtMaLop, txtTenLop);
                TaiLai();
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }

        private void Sua_Click(object sender, EventArgs e)
        {
            if (Rong(txtMaLop)) { UI.CanhBao("Bạn phải nhập Mã lớp!", txtMaLop); return; }
            if (Rong(txtTenLop)) { UI.CanhBao("Bạn phải nhập Tên lớp mới!", txtTenLop); return; }
            if (cboKhoa.SelectedItem == null) { UI.CanhBao("Bạn phải chọn Khoa!", cboKhoa); return; }
            try
            {
                if (KT_KhoaChinh(txtMaLop.Text.Trim())) { UI.CanhBao("Mã lớp không tồn tại!", txtMaLop); return; }
                CSDL.ThucThi("UPDATE Lop SET TenLop = @t, MaKhoa = @k WHERE MaLop = @l",
                    CSDL.TS("@t", txtTenLop.Text.Trim()), CSDL.TS("@k", cboKhoa.Text), CSDL.TS("@l", txtMaLop.Text.Trim()));
                UI.ThongBao("Sửa thành công!");
                LamTrong(txtMaLop, txtTenLop);
                TaiLai();
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }
    }
}
