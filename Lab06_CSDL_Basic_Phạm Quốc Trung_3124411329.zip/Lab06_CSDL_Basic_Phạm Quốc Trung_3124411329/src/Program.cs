// Lab 6 - Lập trình tương tác CSDL
// Sinh viên: Phạm Quốc Trung - MSSV: 3124411329
using System;
using System.Windows.Forms;

namespace Lab6
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FrmMain());
        }
    }
}
