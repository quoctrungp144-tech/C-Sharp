// Lab 6 - Form chính (MDI) chứa menu mở các bài tập Lab 6A, 6B và bài Cửa hàng
using System;
using System.Drawing;
using System.Windows.Forms;

namespace Lab6
{
    public class FrmMain : Form
    {
        public FrmMain()
        {
            Text = "Lab 6 - Lập trình tương tác CSDL | Phạm Quốc Trung - 3124411329";
            Font = UI.FontChung;
            IsMdiContainer = true;
            Size = new Size(1100, 750);
            StartPosition = FormStartPosition.CenterScreen;
            WindowState = FormWindowState.Maximized;

            var menu = new MenuStrip();

            var mnu6A = new ToolStripMenuItem("Lab 6&A");
            mnu6A.DropDownItems.Add("Bài mẫu: Quản lý khoa", null, (s, e) => HienForm<FrmKhoa>());
            mnu6A.DropDownItems.Add(new ToolStripSeparator());
            mnu6A.DropDownItems.Add("Trên lớp - Bài 1: Môn học", null, (s, e) => HienForm<FrmMonHoc>());
            mnu6A.DropDownItems.Add("Nâng cao - Bài 1: Sinh viên", null, (s, e) => HienForm<FrmSinhVienCSDL>());
            mnu6A.DropDownItems.Add("Nâng cao - Bài 2: Điểm", null, (s, e) => HienForm<FrmDiem>());
            mnu6A.DropDownItems.Add("Về nhà - Bài 1: Lớp", null, (s, e) => HienForm<FrmLop>());

            var mnu6B = new ToolStripMenuItem("Lab 6&B");
            mnu6B.DropDownItems.Add("Bài mẫu 1: Khoa (kiểm tra trùng mã)", null, (s, e) => HienForm<FrmKhoa>());
            mnu6B.DropDownItems.Add("Bài mẫu 2: Lớp (ComboBox khoa)", null, (s, e) => HienForm<FrmLopCombo>());
            mnu6B.DropDownItems.Add(new ToolStripSeparator());
            mnu6B.DropDownItems.Add("Trên lớp - Bài 1: Sinh viên (ComboBox lớp)", null, (s, e) => HienForm<FrmSinhVienCombo>());
            mnu6B.DropDownItems.Add("Trên lớp - Bài 2: Điểm (ComboBox)", null, (s, e) => HienForm<FrmDiemCombo>());
            mnu6B.DropDownItems.Add(new ToolStripSeparator());
            mnu6B.DropDownItems.Add("Nâng cao - Bài 1: Danh sách lớp (ListView)", null, (s, e) => HienForm<FrmDanhSachLop>());
            mnu6B.DropDownItems.Add("Nâng cao - Bài 2: Điểm theo môn (ListView)", null, (s, e) => HienForm<FrmDiemTheoMon>());
            mnu6B.DropDownItems.Add(new ToolStripSeparator());
            mnu6B.DropDownItems.Add("Về nhà - Bài 1: Quản lý cửa hàng (QLCuaHang)", null, (s, e) => new FrmCuaHang().Show(this));

            var mnuCuaSo = new ToolStripMenuItem("Cửa &sổ");
            mnuCuaSo.DropDownItems.Add("Xếp chồng", null, (s, e) => LayoutMdi(MdiLayout.Cascade));
            mnuCuaSo.DropDownItems.Add("Đóng tất cả", null, (s, e) => { foreach (Form f in MdiChildren) f.Close(); });
            mnuCuaSo.DropDownItems.Add(new ToolStripSeparator());

            menu.Items.AddRange(new ToolStripItem[] { mnu6A, mnu6B, mnuCuaSo, new ToolStripMenuItem("&Thoát", null, (s, e) => Close()) });
            menu.MdiWindowListItem = mnuCuaSo;
            MainMenuStrip = menu;
            Controls.Add(menu);

            var thanh = new StatusStrip();
            thanh.Items.Add(new ToolStripStatusLabel("Sinh viên: Phạm Quốc Trung - MSSV: 3124411329"));
            Controls.Add(thanh);

            FormClosing += (s, e) => { if (!UI.Hoi("Thoát chương trình?")) e.Cancel = true; };
        }

        private void HienForm<T>() where T : Form, new()
        {
            foreach (Form f in MdiChildren)
                if (f is T) { f.WindowState = FormWindowState.Normal; f.Activate(); return; }
            var moi = new T { MdiParent = this };
            moi.Show();
        }
    }
}
