// Lab 6A - Bài tập tại lớp - Bài 1: Quản lý môn học (bảng MonHoc)
using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Lab6
{
    public class FrmMonHoc : FrmCSDLCoSo
    {
        private TextBox txtMaMH, txtTenMH;

        public FrmMonHoc() : base("6A - Bài 1: Quản lý môn học", "SELECT MaMonHoc AS [Mã môn học], TenMonHoc AS [Tên môn học] FROM MonHoc", 140)
        {
            UI.Nhan(this, "Mã môn học:", 15, 15);
            txtMaMH = UI.O(this, 130, 15, 200);
            UI.Nhan(this, "Tên môn học:", 15, 55);
            txtTenMH = UI.O(this, 130, 55, 300);

            UI.Nut(this, "Thêm", 130, 95, 100, 34, Them_Click);
            UI.Nut(this, "Xóa", 240, 95, 100, 34, Xoa_Click);
            UI.Nut(this, "Sửa", 350, 95, 100, 34, Sua_Click);
            UI.Nut(this, "Làm trống", 460, 95, 110, 34, (s, e) => LamTrong(txtMaMH, txtTenMH));

            // Click 1 dòng: chỉ đưa mã môn học lên để tiện xóa / sửa
            dgvDuLieu.CellClick += (s, e) => { if (e.RowIndex >= 0) txtMaMH.Text = dgvDuLieu.Rows[e.RowIndex].Cells[0].Value.ToString(); };
        }

        private void Them_Click(object sender, EventArgs e)
        {
            if (Rong(txtMaMH) || Rong(txtTenMH)) { UI.CanhBao("Mã môn học và Tên môn học không được để trống!", Rong(txtMaMH) ? txtMaMH : txtTenMH); return; }
            try
            {
                var ma = CSDL.TS("@ma", txtMaMH.Text.Trim());
                if (CSDL.TonTai("SELECT COUNT(*) FROM MonHoc WHERE MaMonHoc = @ma", ma))
                { UI.CanhBao("Mã môn học đã tồn tại!", txtMaMH); return; }

                CSDL.ThucThi("INSERT INTO MonHoc (MaMonHoc, TenMonHoc) VALUES (@ma, @ten)",
                    CSDL.TS("@ma", txtMaMH.Text.Trim()), CSDL.TS("@ten", txtTenMH.Text.Trim()));
                UI.ThongBao("Thêm môn học thành công!");
                LamTrong(txtMaMH, txtTenMH);
                TaiLai();
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }

        private void Xoa_Click(object sender, EventArgs e)
        {
            if (Rong(txtMaMH)) { UI.CanhBao("Mã môn học không được để trống!", txtMaMH); return; }
            if (!Rong(txtTenMH)) { UI.CanhBao("Khi xóa chỉ nhập Mã môn học, không nhập Tên môn học!", txtTenMH); return; }
            if (!UI.Hoi("Xóa môn học có mã " + txtMaMH.Text.Trim() + "?")) return;
            try
            {
                int n = CSDL.ThucThi("DELETE FROM MonHoc WHERE MaMonHoc = @ma", CSDL.TS("@ma", txtMaMH.Text.Trim()));
                if (n == 0) UI.CanhBao("Không tìm thấy môn học cần xóa!");
                else { UI.ThongBao("Xóa thành công!"); LamTrong(txtMaMH, txtTenMH); TaiLai(); }
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }

        private void Sua_Click(object sender, EventArgs e)
        {
            if (Rong(txtMaMH) || Rong(txtTenMH)) { UI.CanhBao("Mã môn học và Tên môn học không được để trống!", Rong(txtMaMH) ? txtMaMH : txtTenMH); return; }
            try
            {
                int n = CSDL.ThucThi("UPDATE MonHoc SET TenMonHoc = @ten WHERE MaMonHoc = @ma",
                    CSDL.TS("@ten", txtTenMH.Text.Trim()), CSDL.TS("@ma", txtMaMH.Text.Trim()));
                if (n == 0) UI.CanhBao("Không tìm thấy môn học có mã này!");
                else { UI.ThongBao("Sửa thành công!"); LamTrong(txtMaMH, txtTenMH); TaiLai(); }
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }
    }
}
