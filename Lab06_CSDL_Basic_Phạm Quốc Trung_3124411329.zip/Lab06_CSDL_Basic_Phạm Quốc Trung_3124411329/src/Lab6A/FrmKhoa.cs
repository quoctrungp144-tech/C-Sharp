// Lab 6A / 6B - Bài tập mẫu: Quản lý Khoa (kiểm tra trùng mã khoa trước khi thêm)
using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Lab6
{
    public class FrmKhoa : FrmCSDLCoSo
    {
        private TextBox txtMaKhoa, txtTenKhoa;

        public FrmKhoa() : base("Bài mẫu: Quản lý khoa", "SELECT MaKhoa AS [Mã khoa], TenKhoa AS [Tên khoa] FROM Khoa", 140)
        {
            UI.Nhan(this, "Mã khoa:", 15, 15);
            txtMaKhoa = UI.O(this, 130, 15, 200);
            UI.Nhan(this, "Tên khoa:", 15, 55);
            txtTenKhoa = UI.O(this, 130, 55, 300);

            UI.Nut(this, "Thêm", 130, 95, 100, 34, Them_Click);
            UI.Nut(this, "Xóa", 240, 95, 100, 34, Xoa_Click);
            UI.Nut(this, "Sửa", 350, 95, 100, 34, Sua_Click);
            UI.Nut(this, "Làm trống", 460, 95, 110, 34, (s, e) => LamTrong(txtMaKhoa, txtTenKhoa));
        }

        /// <summary>Trả về true nếu mã khoa CHƯA có trong bảng Khoa (được phép thêm).</summary>
        private bool KT_MaKhoa(string ma)
        {
            int dem = Convert.ToInt32(CSDL.LayGiaTri("SELECT COUNT(*) FROM Khoa WHERE MaKhoa = @ma", CSDL.TS("@ma", ma)));
            return dem == 0;
        }

        private void Them_Click(object sender, EventArgs e)
        {
            if (Rong(txtMaKhoa) || Rong(txtTenKhoa)) { UI.CanhBao("Mã khoa và Tên khoa không được để trống!", Rong(txtMaKhoa) ? txtMaKhoa : txtTenKhoa); return; }
            try
            {
                if (!KT_MaKhoa(txtMaKhoa.Text.Trim())) { UI.CanhBao("Trùng mã khoa!", txtMaKhoa); return; }
                CSDL.ThucThi("INSERT INTO Khoa (MaKhoa, TenKhoa) VALUES (@ma, @ten)",
                    CSDL.TS("@ma", txtMaKhoa.Text.Trim()), CSDL.TS("@ten", txtTenKhoa.Text.Trim()));
                UI.ThongBao("Thêm khoa thành công!");
                LamTrong(txtMaKhoa, txtTenKhoa);
                TaiLai();
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }

        private void Xoa_Click(object sender, EventArgs e)
        {
            if (Rong(txtMaKhoa)) { UI.CanhBao("Hãy nhập mã khoa cần xóa!", txtMaKhoa); return; }
            string ma = txtMaKhoa.Text.Trim();
            try
            {
                if (KT_MaKhoa(ma)) { UI.CanhBao("Không có khoa mã " + ma + "!"); return; }
                if (CSDL.CoDuLieu("SELECT 1 FROM Lop WHERE MaKhoa = @ma", CSDL.TS("@ma", ma)))
                { UI.CanhBao("Khoa này đang có lớp, không thể xóa!"); return; }
                if (!UI.Hoi("Xóa khoa " + ma + "?")) return;
                CSDL.ThucThi("DELETE FROM Khoa WHERE MaKhoa = @ma", CSDL.TS("@ma", ma));
                UI.ThongBao("Xóa thành công!");
                LamTrong(txtMaKhoa, txtTenKhoa);
                TaiLai();
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }

        private void Sua_Click(object sender, EventArgs e)
        {
            if (Rong(txtMaKhoa) || Rong(txtTenKhoa)) { UI.CanhBao("Mã khoa và Tên khoa không được để trống!", Rong(txtMaKhoa) ? txtMaKhoa : txtTenKhoa); return; }
            try
            {
                int n = CSDL.ThucThi("UPDATE Khoa SET TenKhoa = @ten WHERE MaKhoa = @ma",
                    CSDL.TS("@ten", txtTenKhoa.Text.Trim()), CSDL.TS("@ma", txtMaKhoa.Text.Trim()));
                if (n == 0) UI.CanhBao("Không tìm thấy khoa có mã này!");
                else { UI.ThongBao("Sửa thành công!"); LamTrong(txtMaKhoa, txtTenKhoa); TaiLai(); }
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }
    }
}
