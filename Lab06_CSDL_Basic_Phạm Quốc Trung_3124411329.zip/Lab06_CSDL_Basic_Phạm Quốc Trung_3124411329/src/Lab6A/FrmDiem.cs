// Lab 6A - Bài tập nâng cao - Bài 2: Quản lý điểm (bảng Diem)
using System;
using System.Data.SqlClient;
using System.Globalization;
using System.Windows.Forms;

namespace Lab6
{
    public class FrmDiem : FrmCSDLCoSo
    {
        private TextBox txtMaSV, txtMaMH, txtDiem;

        public FrmDiem() : base("6A - Nâng cao Bài 2: Quản lý điểm",
            "SELECT d.MaSinhVien AS [Mã SV], s.HoTen AS [Họ tên], d.MaMonHoc AS [Mã MH], m.TenMonHoc AS [Tên môn], d.Diem AS [Điểm] " +
            "FROM Diem d JOIN SinhVien s ON s.MaSinhVien = d.MaSinhVien JOIN MonHoc m ON m.MaMonHoc = d.MaMonHoc", 185)
        {
            UI.Nhan(this, "Mã sinh viên:", 15, 15);
            txtMaSV = UI.O(this, 130, 15, 200);
            UI.Nhan(this, "Mã môn học:", 15, 55);
            txtMaMH = UI.O(this, 130, 55, 200);
            UI.Nhan(this, "Điểm:", 15, 95);
            txtDiem = UI.O(this, 130, 95, 100);
            UI.Nhan(this, "(0 - 10)", 240, 95, 80);
            txtDiem.KeyPress += TxtDiem_KeyPress;

            UI.Nut(this, "Thêm", 130, 138, 100, 34, Them_Click);
            UI.Nut(this, "Xóa", 240, 138, 100, 34, Xoa_Click);
            UI.Nut(this, "Sửa", 350, 138, 100, 34, Sua_Click);
            UI.Nut(this, "Làm trống", 460, 138, 110, 34, (s, e) => LamTrong(txtMaSV, txtMaMH, txtDiem));
        }

        // Chỉ cho gõ chữ số và một dấu thập phân (chấp nhận cả '.' và ',')
        private void TxtDiem_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsControl(e.KeyChar) || char.IsDigit(e.KeyChar)) return;
            if ((e.KeyChar == '.' || e.KeyChar == ',') && txtDiem.Text.IndexOfAny(new[] { '.', ',' }) < 0) return;
            e.Handled = true;
        }

        private bool DocDiem(out double diem)
        {
            string s = txtDiem.Text.Trim().Replace(',', '.');
            if (double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out diem) && diem >= 0 && diem <= 10)
                return true;
            UI.CanhBao("Điểm phải là số trong khoảng 0 - 10!", txtDiem);
            return false;
        }

        private SqlParameter[] KhoaChinh()
        {
            return new[] { CSDL.TS("@sv", txtMaSV.Text.Trim()), CSDL.TS("@mh", txtMaMH.Text.Trim()) };
        }

        private void Them_Click(object sender, EventArgs e)
        {
            foreach (TextBox t in new[] { txtMaSV, txtMaMH, txtDiem })
                if (Rong(t)) { UI.CanhBao("Mã sinh viên, Mã môn học, Điểm không được để trống!", t); return; }
            double diem;
            if (!DocDiem(out diem)) return;
            try
            {
                if (!CSDL.TonTai("SELECT COUNT(*) FROM SinhVien WHERE MaSinhVien = @sv", CSDL.TS("@sv", txtMaSV.Text.Trim())))
                { UI.CanhBao("Mã sinh viên không tồn tại!", txtMaSV); return; }
                if (!CSDL.TonTai("SELECT COUNT(*) FROM MonHoc WHERE MaMonHoc = @mh", CSDL.TS("@mh", txtMaMH.Text.Trim())))
                { UI.CanhBao("Mã môn học không tồn tại!", txtMaMH); return; }
                if (CSDL.TonTai("SELECT COUNT(*) FROM Diem WHERE MaSinhVien = @sv AND MaMonHoc = @mh", KhoaChinh()))
                { UI.CanhBao("Sinh viên này đã có điểm môn này, hãy dùng chức năng Sửa!"); return; }

                CSDL.ThucThi("INSERT INTO Diem (MaSinhVien, MaMonHoc, Diem) VALUES (@sv, @mh, @d)",
                    CSDL.TS("@sv", txtMaSV.Text.Trim()), CSDL.TS("@mh", txtMaMH.Text.Trim()), CSDL.TS("@d", diem));
                UI.ThongBao("Thêm điểm thành công!");
                LamTrong(txtMaSV, txtMaMH, txtDiem);
                TaiLai();
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }

        private void Xoa_Click(object sender, EventArgs e)
        {
            if (Rong(txtMaSV) || Rong(txtMaMH)) { UI.CanhBao("Mã sinh viên và Mã môn học không được để trống!", Rong(txtMaSV) ? txtMaSV : txtMaMH); return; }
            if (!Rong(txtDiem)) { UI.CanhBao("Khi xóa không nhập Điểm!", txtDiem); return; }
            if (!UI.Hoi("Xóa điểm môn " + txtMaMH.Text.Trim() + " của sinh viên " + txtMaSV.Text.Trim() + "?")) return;
            try
            {
                int n = CSDL.ThucThi("DELETE FROM Diem WHERE MaSinhVien = @sv AND MaMonHoc = @mh", KhoaChinh());
                if (n == 0) UI.CanhBao("Không tìm thấy dòng điểm cần xóa!");
                else { UI.ThongBao("Xóa thành công!"); LamTrong(txtMaSV, txtMaMH, txtDiem); TaiLai(); }
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }

        private void Sua_Click(object sender, EventArgs e)
        {
            if (Rong(txtMaSV) || Rong(txtMaMH)) { UI.CanhBao("Mã sinh viên và Mã môn học không được để trống!", Rong(txtMaSV) ? txtMaSV : txtMaMH); return; }
            if (Rong(txtDiem)) { UI.CanhBao("Phải nhập điểm mới!", txtDiem); return; }
            double diem;
            if (!DocDiem(out diem)) return;
            try
            {
                int n = CSDL.ThucThi("UPDATE Diem SET Diem = @d WHERE MaSinhVien = @sv AND MaMonHoc = @mh",
                    CSDL.TS("@d", diem), CSDL.TS("@sv", txtMaSV.Text.Trim()), CSDL.TS("@mh", txtMaMH.Text.Trim()));
                if (n == 0) UI.CanhBao("Sinh viên chưa có điểm môn này!");
                else { UI.ThongBao("Sửa điểm thành công!"); LamTrong(txtMaSV, txtMaMH, txtDiem); TaiLai(); }
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }
    }
}
