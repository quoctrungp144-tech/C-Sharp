// Lab 6A - Bài tập về nhà - Bài 1: Quản lý lớp (bảng Lop)
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Lab6
{
    public class FrmLop : FrmCSDLCoSo
    {
        private TextBox txtMaKhoa, txtMaLop, txtTenLop;

        public FrmLop() : base("6A - Về nhà Bài 1: Quản lý lớp",
            "SELECT l.MaLop AS [Mã lớp], l.TenLop AS [Tên lớp], l.MaKhoa AS [Mã khoa], k.TenKhoa AS [Tên khoa] FROM Lop l JOIN Khoa k ON k.MaKhoa = l.MaKhoa", 185)
        {
            UI.Nhan(this, "Mã khoa:", 15, 15);
            txtMaKhoa = UI.O(this, 130, 15, 200);
            UI.Nhan(this, "Mã lớp:", 15, 55);
            txtMaLop = UI.O(this, 130, 55, 200);
            UI.Nhan(this, "Tên lớp:", 15, 95);
            txtTenLop = UI.O(this, 130, 95, 300);

            UI.Nut(this, "Thêm", 130, 138, 100, 34, Them_Click);
            UI.Nut(this, "Xóa", 240, 138, 100, 34, Xoa_Click);
            UI.Nut(this, "Sửa", 350, 138, 100, 34, Sua_Click);
            UI.Nut(this, "Làm trống", 460, 138, 110, 34, (s, e) => LamTrong(txtMaKhoa, txtMaLop, txtTenLop));
        }

        private bool KhoaTonTai()
        {
            if (CSDL.TonTai("SELECT COUNT(*) FROM Khoa WHERE MaKhoa = @k", CSDL.TS("@k", txtMaKhoa.Text.Trim()))) return true;
            UI.CanhBao("Mã khoa không tồn tại trong bảng Khoa!", txtMaKhoa);
            return false;
        }

        private void Them_Click(object sender, EventArgs e)
        {
            foreach (TextBox t in new[] { txtMaKhoa, txtMaLop, txtTenLop })
                if (Rong(t)) { UI.CanhBao("Mã khoa, Mã lớp, Tên lớp không được để trống!", t); return; }
            try
            {
                if (!KhoaTonTai()) return;
                if (CSDL.TonTai("SELECT COUNT(*) FROM Lop WHERE MaLop = @l", CSDL.TS("@l", txtMaLop.Text.Trim())))
                { UI.CanhBao("Mã lớp đã tồn tại!", txtMaLop); return; }

                CSDL.ThucThi("INSERT INTO Lop (MaLop, TenLop, MaKhoa) VALUES (@l, @t, @k)",
                    CSDL.TS("@l", txtMaLop.Text.Trim()), CSDL.TS("@t", txtTenLop.Text.Trim()), CSDL.TS("@k", txtMaKhoa.Text.Trim()));
                UI.ThongBao("Thêm lớp thành công!");
                LamTrong(txtMaKhoa, txtMaLop, txtTenLop);
                TaiLai();
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }

        private void Xoa_Click(object sender, EventArgs e)
        {
            if (Rong(txtMaLop)) { UI.CanhBao("Mã lớp không được để trống!", txtMaLop); return; }
            if (!Rong(txtMaKhoa) || !Rong(txtTenLop)) { UI.CanhBao("Khi xóa chỉ nhập Mã lớp, không nhập Mã khoa và Tên lớp!"); return; }
            if (!UI.Hoi("Xóa lớp " + txtMaLop.Text.Trim() + "?")) return;
            try
            {
                int n = CSDL.ThucThi("DELETE FROM Lop WHERE MaLop = @l", CSDL.TS("@l", txtMaLop.Text.Trim()));
                if (n == 0) UI.CanhBao("Không tìm thấy lớp cần xóa!");
                else { UI.ThongBao("Xóa thành công!"); LamTrong(txtMaKhoa, txtMaLop, txtTenLop); TaiLai(); }
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }

        private void Sua_Click(object sender, EventArgs e)
        {
            if (Rong(txtMaLop)) { UI.CanhBao("Mã lớp không được để trống!", txtMaLop); return; }
            if (Rong(txtMaKhoa) && Rong(txtTenLop)) { UI.CanhBao("Phải nhập ít nhất Mã khoa hoặc Tên lớp!", txtMaKhoa); return; }

            var cot = new List<string>();
            var ts = new List<SqlParameter> { CSDL.TS("@l", txtMaLop.Text.Trim()) };
            try
            {
                if (!Rong(txtMaKhoa))
                {
                    if (!KhoaTonTai()) return;
                    cot.Add("MaKhoa = @k"); ts.Add(CSDL.TS("@k", txtMaKhoa.Text.Trim()));
                }
                if (!Rong(txtTenLop)) { cot.Add("TenLop = @t"); ts.Add(CSDL.TS("@t", txtTenLop.Text.Trim())); }

                int n = CSDL.ThucThi("UPDATE Lop SET " + string.Join(", ", cot) + " WHERE MaLop = @l", ts.ToArray());
                if (n == 0) UI.CanhBao("Không tìm thấy lớp có mã này!");
                else { UI.ThongBao("Sửa thành công!"); LamTrong(txtMaKhoa, txtMaLop, txtTenLop); TaiLai(); }
            }
            catch (SqlException ex) { CSDL.BaoLoi(ex); }
        }
    }
}
