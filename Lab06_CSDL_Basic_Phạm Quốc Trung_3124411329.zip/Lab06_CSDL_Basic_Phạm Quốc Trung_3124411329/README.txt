LAB 6 - LẬP TRÌNH TƯƠNG TÁC CSDL - Phạm Quốc Trung - 3124411329

CÁCH CHẠY
1. Mở SQL Server Management Studio, chạy lần lượt QLSinhVien.sql và QLCuaHang.sql.
2. Sửa "Data Source=..." cho đúng tên SQL Server trên máy ở 2 file:
   - src\CSDL.cs                 (CSDL QLSinhVien)
   - src\CuaHang\CuaHangDB.cs    (CSDL QLCuaHang)
   VD: .\SQLEXPRESS, (localdb)\MSSQLLocalDB, TEN-MAY
3. Mở src\Lab06_CSDL_Basic.csproj bằng Visual Studio 2022 -> F5.
4. Menu Lab 6A / Lab 6B để mở từng bài.
   Bài Cửa hàng: menu Lab 6B -> Về nhà. Mỗi ngày phải chọn "Tạo tồn kho" trước khi bán hàng.

BÁO CÁO
- Báo cáo .docx gồm yêu cầu, thiết kế giao diện, mã nguồn và giải thích cho từng bài.
