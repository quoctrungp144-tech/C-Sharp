-- Script tạo CSDL QLSinhVien cho bài Lab 6 (6A, 6B)
-- Sinh viên: Phạm Quốc Trung - MSSV: 3124411329
IF DB_ID(N'QLSinhVien') IS NULL
    CREATE DATABASE QLSinhVien;
GO
USE QLSinhVien;
GO

IF OBJECT_ID(N'Diem') IS NOT NULL DROP TABLE Diem;
IF OBJECT_ID(N'SinhVien') IS NOT NULL DROP TABLE SinhVien;
IF OBJECT_ID(N'MonHoc') IS NOT NULL DROP TABLE MonHoc;
IF OBJECT_ID(N'Lop') IS NOT NULL DROP TABLE Lop;
IF OBJECT_ID(N'Khoa') IS NOT NULL DROP TABLE Khoa;
GO

CREATE TABLE Khoa (
    MaKhoa  VARCHAR(10)   NOT NULL PRIMARY KEY,
    TenKhoa NVARCHAR(100) NOT NULL
);

CREATE TABLE Lop (
    MaLop  VARCHAR(15)   NOT NULL PRIMARY KEY,
    TenLop NVARCHAR(100) NOT NULL,
    MaKhoa VARCHAR(10)   NOT NULL REFERENCES Khoa(MaKhoa)
);

CREATE TABLE SinhVien (
    MaSinhVien VARCHAR(15)   NOT NULL PRIMARY KEY,
    HoTen      NVARCHAR(100) NOT NULL,
    NgaySinh   DATE          NOT NULL,
    MaLop      VARCHAR(15)   NOT NULL REFERENCES Lop(MaLop)
);

CREATE TABLE MonHoc (
    MaMonHoc  VARCHAR(10)   NOT NULL PRIMARY KEY,
    TenMonHoc NVARCHAR(100) NOT NULL
);

CREATE TABLE Diem (
    MaSinhVien VARCHAR(15) NOT NULL REFERENCES SinhVien(MaSinhVien),
    MaMonHoc   VARCHAR(10) NOT NULL REFERENCES MonHoc(MaMonHoc),
    Diem       FLOAT       NOT NULL CHECK (Diem BETWEEN 0 AND 10),
    PRIMARY KEY (MaSinhVien, MaMonHoc)
);
GO

-- Dữ liệu mẫu (mỗi bảng ít nhất 5 mẫu tin)
INSERT INTO Khoa VALUES
 ('CNTT', N'Công nghệ thông tin'), ('KT', N'Kế toán'), ('QTKD', N'Quản trị kinh doanh'),
 ('NN', N'Ngoại ngữ'), ('DTVT', N'Điện tử viễn thông');

INSERT INTO Lop VALUES
 ('DCT1241', N'Đại học CNTT 1241', 'CNTT'), ('DCT1242', N'Đại học CNTT 1242', 'CNTT'),
 ('DKT1241', N'Đại học Kế toán 1241', 'KT'), ('DQK1241', N'Đại học QTKD 1241', 'QTKD'),
 ('DNA1241', N'Đại học Ngôn ngữ Anh 1241', 'NN'), ('DDV1241', N'Đại học ĐTVT 1241', 'DTVT');

INSERT INTO SinhVien VALUES
 ('SV001', N'Trịnh Hoàng Nam',   '2006-03-14', 'DCT1241'),
 ('SV002', N'Lương Bích Ngọc',   '2006-07-02', 'DCT1241'),
 ('SV003', N'Quách Minh Tuấn',   '2006-11-25', 'DCT1242'),
 ('SV004', N'Hà Thanh Vy',       '2005-12-09', 'DKT1241'),
 ('SV005', N'Kiều Đức Long',     '2006-05-30', 'DQK1241'),
 ('SV006', N'Ông Thị Diễm',      '2006-01-18', 'DNA1241');

INSERT INTO MonHoc VALUES
 ('CSLT', N'Cơ sở lập trình'), ('CTDL', N'Cấu trúc dữ liệu và giải thuật'),
 ('CSDL', N'Cơ sở dữ liệu'), ('LTWIN', N'Lập trình Windows (C#)'),
 ('MMT', N'Mạng máy tính'), ('TRR', N'Toán rời rạc');

INSERT INTO Diem VALUES
 ('SV001', 'CSLT', 8.5), ('SV001', 'LTWIN', 9),   ('SV002', 'CSLT', 7),
 ('SV002', 'CSDL', 6.5), ('SV003', 'CTDL', 8),    ('SV004', 'TRR', 5.5),
 ('SV005', 'MMT', 7.25), ('SV006', 'CSDL', 9.5),
 ('SV003', 'CSLT', 6),   ('SV004', 'CSLT', 8),    ('SV005', 'CSLT', 4.5),
 ('SV003', 'CSDL', 7.5), ('SV004', 'LTWIN', 8.5), ('SV006', 'TRR', 6.75);
GO
