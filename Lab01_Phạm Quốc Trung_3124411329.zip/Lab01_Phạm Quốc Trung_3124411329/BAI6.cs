using System;

class BAI6
{
    // a, b, c truyền theo tham trị: hàm chỉ nhận bản sao
    public int TimMax(int a, int b, int c)
    {
        int max = a;
        if (b > max) max = b;
        if (c > max) max = c;
        return max;
    }
}
class Program
{
    static void Main()
    {
        Console.Write("Nhap a: "); int a = int.Parse(Console.ReadLine());
        Console.Write("Nhap b: "); int b = int.Parse(Console.ReadLine());
        Console.Write("Nhap c: "); int c = int.Parse(Console.ReadLine());
        BAI6 t = new BAI6();
        Console.WriteLine("Gia tri lon nhat la: {0}", t.TimMax(a, b, c));
    }
}