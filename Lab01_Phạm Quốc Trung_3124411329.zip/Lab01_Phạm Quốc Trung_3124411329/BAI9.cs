using System;

class BAI9
{
    // out: dùng khi cần trả về nhiều giá trị.
    // Biến truyền vào không cần có giá trị trước, nhưng trong hàm bắt buộc phải gán.
    public void TimMaxMin(double a, double b, double c, out double max, out double min)
    {
        max = a;
        if (b > max) max = b;
        if (c > max) max = c;

        min = a;
        if (b < min) min = b;
        if (c < min) min = c;
    }
}
class Progarm
{
    static void Main()
    {
        Console.Write("Nhap a: "); double a = double.Parse(Console.ReadLine());
        Console.Write("Nhap b: "); double b = double.Parse(Console.ReadLine());
        Console.Write("Nhap c: "); double c = double.Parse(Console.ReadLine());

        double max, min;              // khai báo suông vẫn hợp lệ với out
        BAI9 x = new BAI9();
        x.TimMaxMin(a, b, c, out max, out min);

        Console.WriteLine("Lon nhat: {0}", max);
        Console.WriteLine("Nho nhat: {0}", min);
    }
}