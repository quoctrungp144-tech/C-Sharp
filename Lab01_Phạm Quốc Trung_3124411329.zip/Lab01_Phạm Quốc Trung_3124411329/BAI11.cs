using System;
using System.Text;

class BAI11
{
    public string DaoChuoi(string s)
    {
        // string là bất biến: mỗi lần s += ch là tạo chuỗi mới -> chậm.
        // StringBuilder giữ vùng nhớ co giãn nên nối chuỗi nhanh hơn nhiều.
        StringBuilder sb = new StringBuilder();

        for (int i = s.Length - 1; i >= 0; i--)
            sb.Append(s[i]);

        return sb.ToString();
    }
}

class Program
{
    static void Main()
    {
        Console.Write("Nhap chuoi: ");
        string s = Console.ReadLine();

        BAI11 x = new BAI11();
        Console.WriteLine("Chuoi dao: {0}", x.DaoChuoi(s));
    }
}