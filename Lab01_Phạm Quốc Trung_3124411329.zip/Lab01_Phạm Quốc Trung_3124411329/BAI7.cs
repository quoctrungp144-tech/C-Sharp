using System;

class BAI7
{
    public bool LaSoNguyenTo(int n)
    {
        if (n < 2) return false;               // 0, 1, số âm đều không phải
        // chỉ xét ước tới căn(n): nếu n = a * b thì luôn có một thừa số <= căn(n)
        for (int i = 2; i <= Math.Sqrt(n); i++)
            if (n % i == 0) return false;
        return true;
    }
}

class Program
{
    static void Main()
    {
        Console.Write("Nhap n: ");
        int n = int.Parse(Console.ReadLine());

        BAI7 s = new BAI7();
        if (s.LaSoNguyenTo(n))
            Console.WriteLine("{0} la so nguyen to", n);
        else
            Console.WriteLine("{0} khong phai la so nguyen to", n);
    }
}