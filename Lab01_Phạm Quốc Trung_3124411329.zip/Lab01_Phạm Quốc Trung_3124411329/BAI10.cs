using System;

class BAI10
{
    public bool DoiXung(string s)
    {
        int i = 0, j = s.Length - 1;    // hai con trỏ chạy từ hai đầu vào giữa
        while (i < j)
        {
            if (s[i] != s[j]) return false;
            i++;
            j--;
        }
        return true;
    }
}
class Program
{
    static void Main()
    {
        Console.Write("Nhap chuoi: ");
        string s = Console.ReadLine();

        BAI10 x = new BAI10();
        Console.WriteLine(x.DoiXung(s) ? "Chuoi doi xung" : "Chuoi khong doi xung");
    }
}