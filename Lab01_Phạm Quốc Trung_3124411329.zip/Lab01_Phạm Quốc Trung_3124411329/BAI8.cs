using System;

class BAI8S
{
    // ref: hàm nhận chính biến gốc, sửa trong hàm thì a, b ở Main đổi theo.
    // Bỏ ref đi thì hàm chỉ đổi bản sao, ra khỏi hàm a, b vẫn như cũ.
    public void HoanVi(ref double a, ref double b)
    {
        double tam = a;
        a = b;
        b = tam;
    }
}
class program
{
    static void Main()
    {
        Console.Write("Nhap a: "); double a = double.Parse(Console.ReadLine());
        Console.Write("Nhap b: "); double b = double.Parse(Console.ReadLine());

        Console.WriteLine("Truoc khi hoan vi: a = {0}, b = {1}", a, b);

        BAI8 x = new BAI8();
        x.HoanVi(ref a, ref b);      // bắt buộc ghi lại ref khi gọi hàm

        Console.WriteLine("Sau khi hoan vi : a = {0}, b = {1}", a, b);
    }
}