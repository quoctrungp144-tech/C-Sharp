using System;
using System.Collections.Generic;

class BAI17
{
    // tạo 1 Random duy nhất cho cả lớp; new Random() liên tục trong vòng lặp
    // dễ sinh ra số trùng nhau vì hạt giống lấy từ đồng hồ hệ thống
    private Random rd = new Random();

    public int[,] SinhNgauNhien(int n, int m)
    {
        int[,] a = new int[n, m];

        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++)
                a[i, j] = rd.Next(10, 101);   // cận trên không lấy được nên ghi 101 để có số 100

        return a;
    }

    public void InMang(int[,] a)
    {
        // GetLength(0) = số dòng, GetLength(1) = số cột
        for (int i = 0; i < a.GetLength(0); i++)
        {
            for (int j = 0; j < a.GetLength(1); j++)
                Console.Write("{0,5}", a[i, j]);   // canh phải trong 5 ký tự cho cột thẳng hàng
            Console.WriteLine();
        }
    }

    public void TachChanLe(int[,] a, out int[] chan, out int[] le)
    {
        List<int> dsChan = new List<int>();
        List<int> dsLe = new List<int>();

        foreach (int x in a)          // foreach duyệt được cả mảng 2 chiều
        {
            if (x % 2 == 0) dsChan.Add(x);
            else dsLe.Add(x);
        }

        chan = dsChan.ToArray();
        le = dsLe.ToArray();
    }
}

class Program
{
    static void Main()
    {
        Console.Write("Nhap so dong n: ");
        int n = int.Parse(Console.ReadLine());
        Console.Write("Nhap so cot m: ");
        int m = int.Parse(Console.ReadLine());

        BAI17 x = new BAI17();
        int[,] a = x.SinhNgauNhien(n, m);

        Console.WriteLine("\nMang A[{0}x{1}]:", n, m);
        x.InMang(a);

        int[] chan, le;
        x.TachChanLe(a, out chan, out le);

        Console.Write("\nCac so chan: ");
        Console.WriteLine(string.Join(" ", chan));

        Console.Write("Cac so le  : ");
        Console.WriteLine(string.Join(" ", le));
    }
}