using System;  

class BAI2
{
    static void Main()          
    {
        // Console.Write: in ra màn hình nhưng KHÔNG xuống dòng
        Console.Write("Nhap ho ten cua ban: ");

        // Console.ReadLine: đọc 1 dòng người dùng gõ, trả về kiểu string
        string hoTen = Console.ReadLine();

        // {0} là chỗ trống, sẽ được thay bằng tham số thứ 0 (hoTen)
        Console.WriteLine("Chao ban {0}!", hoTen);
    }
}