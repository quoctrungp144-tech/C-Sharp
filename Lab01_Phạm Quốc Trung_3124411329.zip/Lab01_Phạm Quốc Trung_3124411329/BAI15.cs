using System;
using System.Collections.Generic;

class BAI15
{
    public int[] NhapMang()
    {
        int n;
        Console.Write("Nhap so phan tu n: ");
        while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
            Console.Write("n phai la so nguyen duong. Nhap lai: ");

        int[] a = new int[n];

        for (int i = 0; i < n; i++)
        {
            Console.Write("a[{0}] = ", i);
            while (!int.TryParse(Console.ReadLine(), out a[i]))
                Console.Write("Sai dinh dang. a[{0}] = ", i);
        }
        return a;
    }

    public void InMang(int[] a)
    {
        Console.Write("Mang: ");
        foreach (int x in a) Console.Write("{0} ", x);
        Console.WriteLine();
    }

    public void TimMaxMin(int[] a, out int max, out int min)
    {
        max = min = a[0];                  // lấy phần tử đầu làm mốc, duyệt từ i = 1
        for (int i = 1; i < a.Length; i++)
        {
            if (a[i] > max) max = a[i];
            if (a[i] < min) min = a[i];
        }
    }

    public bool LaSoNguyenTo(int n)
    {
        if (n < 2) return false;
        for (int i = 2; i <= Math.Sqrt(n); i++)
            if (n % i == 0) return false;
        return true;
    }

    public int[] MangSoNguyenTo(int[] a)
    {
        // chưa biết trước có bao nhiêu số nguyên tố -> dùng List rồi đổi sang mảng
        List<int> ds = new List<int>();

        foreach (int x in a)
            if (LaSoNguyenTo(x)) ds.Add(x);

        return ds.ToArray();
    }
}

class Program
{
    static void Main()
    {
        BAI15 m = new BAI15();

        int[] a = m.NhapMang();
        m.InMang(a);

        int max, min;
        m.TimMaxMin(a, out max, out min);
        Console.WriteLine("Lon nhat: {0} - Nho nhat: {1}", max, min);

        int[] nt = m.MangSoNguyenTo(a);
        if (nt.Length == 0)
            Console.WriteLine("Mang khong co so nguyen to.");
        else
        {
            Console.Write("Cac so nguyen to: ");
            m.InMang(nt);
        }
    }
}