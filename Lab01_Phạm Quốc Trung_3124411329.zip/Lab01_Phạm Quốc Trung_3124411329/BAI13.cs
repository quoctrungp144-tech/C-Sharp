using System;

class BAI13
{
    // private + property = tính đóng gói: bên ngoài không sửa trực tiếp dữ liệu được
    private string maSV;
    private string hoTen;
    private string diaChi;
    private int namThu;

    public string MaSV   { get { return maSV;   } set { maSV = value;   } }
    public string HoTen  { get { return hoTen;  } set { hoTen = value;  } }
    public string DiaChi { get { return diaChi; } set { diaChi = value; } }
    public int NamThu    { get { return namThu; } set { namThu = value; } }

    public void Nhap()
    {
        Console.Write("Nhap ma sinh vien: ");
        maSV = Console.ReadLine();

        Console.Write("Nhap ho ten: ");
        hoTen = Console.ReadLine();

        Console.Write("Nhap dia chi: ");
        diaChi = Console.ReadLine();

        Console.Write("Sinh vien nam thu: ");
        while (!int.TryParse(Console.ReadLine(), out namThu))
            Console.Write("Sai dinh dang. Nhap lai: ");
    }

    public void Xuat()
    {
        Console.WriteLine("\n--- THONG TIN SINH VIEN ---");
        Console.WriteLine("Ma sinh vien : {0}", maSV);
        Console.WriteLine("Ho ten       : {0}", hoTen);
        Console.WriteLine("Dia chi      : {0}", diaChi);
        Console.WriteLine("Nam thu      : {0}", namThu);
    }
}

class Program
{
    static void Main()
    {
        BAI13 sv = new BAI13();
        sv.Nhap();
        sv.Xuat();
    }
}