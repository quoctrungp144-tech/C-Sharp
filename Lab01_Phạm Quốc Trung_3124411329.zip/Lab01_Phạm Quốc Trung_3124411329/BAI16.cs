using System;

class BAI16
{
    static void Main()
    {
        Console.Write("Nhap so nguoi n: ");
        int n = int.Parse(Console.ReadLine());

        string[] ds = new string[n];

        for (int i = 0; i < n; i++)
        {
            Console.Write("Ho ten nguoi thu {0}: ", i + 1);
            ds[i] = Console.ReadLine();
        }

        // CurrentCulture: so sánh theo quy tắc ngôn ngữ, tiếng Việt có dấu đúng thứ tự hơn
        Array.Sort(ds, StringComparer.CurrentCulture);

        // CÁCH 2 — tự cài đặt, dùng khi không được xài Array.Sort:
        // for (int i = 0; i < n - 1; i++)
        //     for (int j = i + 1; j < n; j++)
        //         if (string.Compare(ds[i], ds[j]) > 0)   // > 0: ds[i] đứng sau ds[j]
        //         {
        //             string tam = ds[i]; ds[i] = ds[j]; ds[j] = tam;
        //         }

        Console.WriteLine("\nDanh sach sau khi sap xep tang dan:");
        foreach (string s in ds) Console.WriteLine(s);
    }
}