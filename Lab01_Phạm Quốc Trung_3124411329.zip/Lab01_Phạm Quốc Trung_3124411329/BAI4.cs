using System;

class BAI4
{
    static void Main()
    {
        int x, y;
        Console.Write("Nhap so nguyen x: ");
        // TryParse: chuyển được thì trả true và gán vào x, không được thì trả false
        // (khác int.Parse — gõ sai là văng lỗi chết chương trình)
        if (!int.TryParse(Console.ReadLine(), out x))
        {
            Console.WriteLine("Loi: x khong phai la so nguyen!");
            return;
        }
        Console.Write("Nhap so nguyen y: ");
        if (!int.TryParse(Console.ReadLine(), out y))
        {
            Console.WriteLine("Loi: y khong phai la so nguyen!");
            return;
        }
        if (y < 0)                   // y âm thì kết quả là phân số
        {
            Console.WriteLine("Loi: y phai >= 0!");
            return;
        }
        long ketQua = 1;
        for (int i = 0; i < y; i++)
            ketQua *= x;

        Console.WriteLine("Ket qua {0} mu {1} la: {2}", x, y, ketQua);
    }
}