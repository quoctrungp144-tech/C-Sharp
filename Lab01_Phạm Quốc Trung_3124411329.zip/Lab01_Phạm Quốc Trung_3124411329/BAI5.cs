using System;

class BAi5
{
    static void Main()
    {
        double x = 0, y = 0;
        bool daNhap = false;          // chặn trường hợp chọn 2, 3 trước khi chọn 1
        string chon;
        do
        {
            Console.WriteLine();
            Console.WriteLine("MENU");
            Console.WriteLine("1. Nhap hai gia tri so thuc cho x, y");
            Console.WriteLine("2. Tinh x^y");
            Console.WriteLine("3. Tinh can bac 2 cua x va y");
            Console.WriteLine("4. Thoat");
            Console.Write("Chon chuc nang: ");
            chon = Console.ReadLine();
            switch (chon)
            {
                case "1":
                    Console.Write("Nhap x: ");
                    while (!double.TryParse(Console.ReadLine(), out x))
                        Console.Write("Sai dinh dang. Nhap lai x: ");

                    Console.Write("Nhap y: ");
                    while (!double.TryParse(Console.ReadLine(), out y))
                        Console.Write("Sai dinh dang. Nhap lai y: ");

                    daNhap = true;
                    break;

                case "2":
                    if (!daNhap) { Console.WriteLine("Chua nhap x, y!"); break; }
                    Console.WriteLine("x^y = {0}", Math.Pow(x, y));
                    break;

                case "3":
                    if (!daNhap) { Console.WriteLine("Chua nhap x, y!"); break; }
                    if (x < 0 || y < 0)          // căn bậc 2 số âm không xác định
                        Console.WriteLine("Khong tinh can bac 2 cua so am!");
                    else
                        Console.WriteLine("can(x) = {0}, can(y) = {1}",
                                          Math.Sqrt(x), Math.Sqrt(y));
                    break;

                case "4":
                    Console.WriteLine("Ket thuc chuong trinh.");
                    break;

                default:
                    Console.WriteLine("Lua chon khong hop le!");
                    break;
            }
        } while (chon != "4");
    }
}