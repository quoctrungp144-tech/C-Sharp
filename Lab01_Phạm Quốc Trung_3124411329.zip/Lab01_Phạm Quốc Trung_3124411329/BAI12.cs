using System;

class BAI12
{
    public string ChuThuong(string s) { return s.ToLower(); }

    public string ChuHoa(string s) { return s.ToUpper(); }

    public int DemTu(string s)
    {
        // RemoveEmptyEntries: bỏ phần tử rỗng sinh ra khi gõ nhiều dấu cách liên tiếp
        string[] tu = s.Split(new char[] { ' ', '\t' },
                              StringSplitOptions.RemoveEmptyEntries);
        return tu.Length;
    }
}

class Program
{
    static void Main()
    {
        Console.Write("Nhap chuoi: ");
        string s = Console.ReadLine();

        BAI12 x = new BAI12();
        Console.WriteLine("Chu thuong : {0}", x.ChuThuong(s));
        Console.WriteLine("Chu hoa    : {0}", x.ChuHoa(s));
        Console.WriteLine("So tu      : {0}", x.DemTu(s));
    }
}