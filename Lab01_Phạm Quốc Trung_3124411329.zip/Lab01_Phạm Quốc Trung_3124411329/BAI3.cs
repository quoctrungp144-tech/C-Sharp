using System;

class BAI3
{
    static void Main()
    {
        Console.Write("Nhap so nguyen x: ");
        // int.Parse: chuyển chuỗi -> số nguyên. 
        int x = int.Parse(Console.ReadLine());
        Console.Write("Nhap so nguyen y: ");
        int y = int.Parse(Console.ReadLine());
        // dùng long vì lũy thừa rất nhanh vượt giới hạn của int
        long ketQua = 1;
        // nhân x vào kết quả đúng y lần: x^y = x * x * ... * x
        for (int i = 0; i < y; i++)
            ketQua *= x;             
        Console.WriteLine("Ket qua {0} mu {1} la: {2}", x, y, ketQua);
    }
}