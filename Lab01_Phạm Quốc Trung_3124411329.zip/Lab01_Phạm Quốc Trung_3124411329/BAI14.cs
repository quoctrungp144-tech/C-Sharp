using System;

class BAI14
{
    private string hoTen;
    private double mucLuong;
    private int soNgayVang;

    public const double TRU_MOI_NGAY = 100000;   // đặt hằng để sau muốn sửa chỉ sửa 1 chỗ

    public void Nhap()
    {
        Console.Write("Nhap ho ten: ");
        hoTen = Console.ReadLine();

        Console.Write("Nhap muc luong: ");
        while (!double.TryParse(Console.ReadLine(), out mucLuong))
            Console.Write("Sai dinh dang. Nhap lai muc luong: ");

        Console.Write("Nhap so ngay vang: ");
        while (!int.TryParse(Console.ReadLine(), out soNgayVang))
            Console.Write("Sai dinh dang. Nhap lai so ngay vang: ");
    }

    public double TinhLuong()
    {
        double luong = mucLuong - soNgayVang * TRU_MOI_NGAY;
        return luong < 0 ? 0 : luong;            // vắng quá nhiều thì quy về 0, không trả lương âm
    }

    public void Xuat()
    {
        Console.WriteLine("\n--- BANG LUONG ---");
        Console.WriteLine("Ho ten       : {0}", hoTen);
        Console.WriteLine("Muc luong    : {0:N0} VND", mucLuong);   // N0: có dấu phân cách nghìn
        Console.WriteLine("So ngay vang : {0}", soNgayVang);
        Console.WriteLine("Luong thuc nhan: {0:N0} VND", TinhLuong());
    }
}

class Program
{
    static void Main()
    {
        BAI14 nv = new BAI14();
        nv.Nhap();
        nv.Xuat();
    }
}
