﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Bai1MayTinh
{
    public partial class frmBaiTap4 : Form
    {
        int[] daySo = new int[100];
        int soLuong = 0;
        public frmBaiTap4()
        {
            InitializeComponent();
        }

        private void frmBaiTap4_Load(object sender, EventArgs e)
        {
        }

        private void btnNhap_Click(object sender, EventArgs e)
        {
            int so;

            if (!int.TryParse(txtNhapSo.Text, out so))
            {
                MessageBox.Show("Vui lòng nhập số nguyên!");
                txtNhapSo.Focus();
                return;
            }

            if (soLuong >= 100)
            {
                MessageBox.Show("Dãy số đã đầy!");
                return;
            }

            daySo[soLuong] = so;
            soLuong++;

            txtDayVuaNhap.Text = "";

            for (int i = 0; i < soLuong; i++)
            {
                txtDayVuaNhap.Text += daySo[i] + " ";
            }
            int tong = 0;
            int tongChan = 0;
            int tongLe = 0;

            for (int i = 0; i < soLuong; i++)
            {
                tong += daySo[i];

                if (daySo[i] % 2 == 0)
                {
                    tongChan += daySo[i];
                }
                else
                {
                    tongLe += daySo[i];
                }
            }

            txtTong.Text = tong.ToString();
            txtTongChan.Text = tongChan.ToString();
            txtTongLe.Text = tongLe.ToString();
           
            txtNhapSo.Clear();
            txtNhapSo.Focus();
        }

        private void btnTiepTuc_Click(object sender, EventArgs e)
        {
            soLuong = 0;

            txtNhapSo.Clear();
            txtDayVuaNhap.Clear();
            txtTong.Clear();
            txtTongChan.Clear();
            txtTongLe.Clear();

            txtNhapSo.Focus();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Bạn có muốn thoát chương trình không?",
                "Xác nhận",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void frmBaiTap4_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Bạn có muốn thoát chương trình không?",
                "Xác nhận",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
    }
}
