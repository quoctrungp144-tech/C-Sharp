﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Bai1MayTinh
{
    public partial class frmBaiTapVeNha : Form
    {
        public frmBaiTapVeNha()
        {
            InitializeComponent();
        }
        double soThuNhat = 0;
        string phepTinh = "";
        private void btn1_Click(object sender, EventArgs e)
        {
            txtKetQua.Text += "1";
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            txtKetQua.Text += "2";
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            txtKetQua.Text += "3";
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            txtKetQua.Text += "4";
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            txtKetQua.Text += "5";
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            txtKetQua.Text += "6";
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            txtKetQua.Text += "7";
        }

        private void frmBaiTapVeNha_Load(object sender, EventArgs e)
        {

        }

        private void btn8_Click(object sender, EventArgs e)
        {
            txtKetQua.Text += "8";
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            txtKetQua.Text += "9";
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            txtKetQua.Text += "0";
        }

        private void btnBang_Click(object sender, EventArgs e)
        {
            double soThuHai = double.Parse(txtKetQua.Text);
            double ketQua = 0;

            if (phepTinh == "+")
            {
                ketQua = soThuNhat + soThuHai;
            }
            else if (phepTinh == "-")
            {
                ketQua = soThuNhat - soThuHai;
            }
            else if (phepTinh == "*")
            {
                ketQua = soThuNhat * soThuHai;
            }
            else if (phepTinh == "/")
            {
                if (soThuHai == 0)
                {
                    MessageBox.Show("Không thể chia cho 0!");
                    return;
                }

                ketQua = soThuNhat / soThuHai;
            }

            txtKetQua.Text = ketQua.ToString();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            txtKetQua.Clear();
            soThuNhat = 0;
            phepTinh = "";
        }

        private void btnCong_Click(object sender, EventArgs e)
        {
            soThuNhat = double.Parse(txtKetQua.Text);
            phepTinh = "+";
            txtKetQua.Clear();
        }

        private void btnTru_Click(object sender, EventArgs e)
        {
            soThuNhat = double.Parse(txtKetQua.Text);
            phepTinh = "-";
            txtKetQua.Clear();
        }

        private void btnNhan_Click(object sender, EventArgs e)
        {
            soThuNhat = double.Parse(txtKetQua.Text);
            phepTinh = "*";
            txtKetQua.Clear();
        }

        private void btnChia_Click(object sender, EventArgs e)
        {
            soThuNhat = double.Parse(txtKetQua.Text);
            phepTinh = "/";
            txtKetQua.Clear();
        }

        private void frmBaiTapVeNha_FormClosing(object sender, FormClosingEventArgs e)
        {

        }
    }
}
