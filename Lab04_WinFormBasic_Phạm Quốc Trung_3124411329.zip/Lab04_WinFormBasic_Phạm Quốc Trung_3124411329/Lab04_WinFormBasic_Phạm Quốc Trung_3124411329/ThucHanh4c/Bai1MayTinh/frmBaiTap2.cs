﻿using System.Text.RegularExpressions;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Bai1MayTinh
{
    public partial class frmBaiTap2 : Form
    {
        public frmBaiTap2()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void txtDiaChiEmail_Leave(object sender, EventArgs e)
        {
            if (txtDiaChiEmail.Text.Trim() == "")
            {
                errorProvider1.SetError(
                    txtDiaChiEmail,
                    "Vui lòng nhập địa chỉ email");
            }
            else if (!Regex.IsMatch(txtDiaChiEmail.Text,
                @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                errorProvider1.SetError(
                    txtDiaChiEmail,
                    "Email không hợp lệ");
            }
            else
            {
                errorProvider1.SetError(txtDiaChiEmail, "");
            }
        }

        private void btnDangKy_Click(object sender, EventArgs e)
        {
            if (txtTenDangNhap.Text.Trim() == "")
            {
                MessageBox.Show("Vui lòng nhập tên đăng nhập!");
                return;
            }

            if (txtDiaChiEmail.Text.Trim() == "")
            {
                MessageBox.Show("Vui lòng nhập địa chỉ email!");
                return;
            }

            if (!Regex.IsMatch(txtDiaChiEmail.Text,
                @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                MessageBox.Show("Email không hợp lệ!");
                return;
            }

            if (txtMatKhau.Text.Trim() == "")
            {
                MessageBox.Show("Vui lòng nhập mật khẩu!");
                return;
            }

            if (txtXacNhanMatKhau.Text.Trim() == "")
            {
                MessageBox.Show("Vui lòng nhập xác nhận mật khẩu!");
                return;
            }

            if (txtMatKhau.Text != txtXacNhanMatKhau.Text)
            {
                MessageBox.Show("Mật khẩu xác nhận không khớp!");
                return;
            }

            MessageBox.Show(
                "Tên đăng nhập: " + txtTenDangNhap.Text +
                "\nĐịa chỉ email: " + txtDiaChiEmail.Text +
                "\nMật khẩu: " + txtMatKhau.Text +
                "\nXác nhận mật khẩu: " + txtXacNhanMatKhau.Text,
                "Thông tin đăng ký");
        }

        private void txtXacNhanMatKhau_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnDangKy.PerformClick();
            }
        }

        private void frmBaiTap2_Load(object sender, EventArgs e)
        {

        }

        private void frmBaiTap2_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Bạn có muốn thoát chương trình không?",
                "Xác nhận",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.No)
            {
                e.Cancel = true;
            }
        }

        private void blbDangKyTaiKhoan_Click(object sender, EventArgs e)
        {

        }

        private void txtTenDangNhap_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtDiaChiEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void lblMatKhau_Click(object sender, EventArgs e)
        {

        }

        private void txtMatKhau_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void lblXacNhanMatKhau_Click(object sender, EventArgs e)
        {

        }

        private void txtXacNhanMatKhau_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
