﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Bai1MayTinh
{
    public partial class frmBaiTap1 : Form
    {
        public frmBaiTap1()
        {
            InitializeComponent();
        }

        private void frmBaiTap1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double a, b;

            if (!double.TryParse(txta.Text, out a) ||
                !double.TryParse(txtb.Text, out b))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ số a và b!");
                return;
            }

            txtketqua.Text = (a + b).ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double a, b;

            if (!double.TryParse(txta.Text, out a) ||
                !double.TryParse(txtb.Text, out b))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ số a và b!");
                return;
            }

            txtketqua.Text = (a * b).ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double a, b;

            if (!double.TryParse(txta.Text, out a) ||
                !double.TryParse(txtb.Text, out b))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ số a và b!");
                return;
            }

            txtketqua.Text = (a - b).ToString();
        }

        private void btnchia_Click(object sender, EventArgs e)
        {
            double a, b;

            if (!double.TryParse(txta.Text, out a) ||
                !double.TryParse(txtb.Text, out b))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ số a và b!");
                return;
            }

            if (b == 0)
            {
                MessageBox.Show("Không thể chia cho 0!");
                return;
            }

            txtketqua.Text = (a / b).ToString();
        }

        private void txta_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != '\b')
            {
                e.Handled = true;
            }
        }

        private void txtb_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != '\b')
            {
                e.Handled = true;
            }
        }

        private void txta_Leave(object sender, EventArgs e)
        {
            if (txta.Text.Trim() == "")
            {
                errorProvider1.SetError(txta, "Vui lòng nhập số a");
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void txtb_Leave(object sender, EventArgs e)
        {
            if (txtb.Text.Trim() == "")
            {
                errorProvider1.SetError(txtb, "Vui lòng nhập số b");
            }
            else
            {
                errorProvider1.Clear();
            }
        }

        private void frmBaiTap1_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show(
        "Bạn có muốn thoát chương trình không?",
        "Xác nhận",
        MessageBoxButtons.YesNo,
        MessageBoxIcon.Question);

            if (result == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
    }
}
