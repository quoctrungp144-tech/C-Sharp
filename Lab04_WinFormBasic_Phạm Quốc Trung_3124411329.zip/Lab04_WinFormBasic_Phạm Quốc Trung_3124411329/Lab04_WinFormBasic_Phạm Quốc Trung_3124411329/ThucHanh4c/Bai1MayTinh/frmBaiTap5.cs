﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Bai1MayTinh
{
    public partial class frmBaiTap5 : Form
    {
        public frmBaiTap5()
        {
            InitializeComponent();
        }
        // Đọc số thành chữ
        private string DocSo(int so)
        {
            string[] chuSo =
            {
        "Không", "Một", "Hai", "Ba", "Bốn",
        "Năm", "Sáu", "Bảy", "Tám", "Chín"
    };

            // Từ 1 đến 9
            if (so < 10)
            {
                return chuSo[so];
            }

            // Từ 10 đến 19
            if (so < 20)
            {
                if (so == 15)
                {
                    return "Mười Lăm";
                }

                return "Mười " + chuSo[so - 10];
            }

            // Từ 20 đến 99
            if (so < 100)
            {
                int hangChuc = so / 10;
                int hangDonVi = so % 10;

                string ketQua = chuSo[hangChuc] + " Mươi";

                if (hangDonVi == 0)
                {
                    return ketQua;
                }

                if (hangDonVi == 1)
                {
                    ketQua += " Mốt";
                }
                else if (hangDonVi == 5)
                {
                    ketQua += " Lăm";
                }
                else
                {
                    ketQua += " " + chuSo[hangDonVi];
                }

                return ketQua;
            }

            // Từ 100 đến 999
            int hangTram = so / 100;
            int phanConLai = so % 100;

            string ketQuaTram = chuSo[hangTram] + " Trăm";

            if (phanConLai == 0)
            {
                return ketQuaTram;
            }

            // Ví dụ: 105
            if (phanConLai < 10)
            {
                return ketQuaTram + " Lẻ " + chuSo[phanConLai];
            }

            int hangChuc2 = phanConLai / 10;
            int hangDonVi2 = phanConLai % 10;

            ketQuaTram += " " + chuSo[hangChuc2] + " Mươi";

            if (hangDonVi2 == 0)
            {
                return ketQuaTram;
            }

            if (hangDonVi2 == 1)
            {
                ketQuaTram += " Mốt";
            }
            else if (hangDonVi2 == 5)
            {
                ketQuaTram += " Lăm";
            }
            else
            {
                ketQuaTram += " " + chuSo[hangDonVi2];
            }

            return ketQuaTram;
        }
        private void txtKetQua_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int so;

            if (!int.TryParse(txtNhapSo.Text, out so))
            {
                MessageBox.Show("Vui lòng nhập số nguyên!");
                txtNhapSo.Focus();
                return;
            }

            if (so < 1 || so > 999)
            {
                MessageBox.Show("Vui lòng nhập số từ 1 đến 999!");
                txtNhapSo.Focus();
                return;
            }

            txtKetQua.Text = DocSo(so);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtNhapSo.Clear();
            txtKetQua.Clear();

            txtNhapSo.Focus();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Bạn có muốn thoát chương trình không?",
                "Xác nhận",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void txtNhapSo_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
