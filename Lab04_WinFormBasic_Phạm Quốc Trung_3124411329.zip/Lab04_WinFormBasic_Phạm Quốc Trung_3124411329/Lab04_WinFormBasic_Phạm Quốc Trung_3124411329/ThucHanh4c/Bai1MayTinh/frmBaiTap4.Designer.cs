﻿namespace Bai1MayTinh
{
    partial class frmBaiTap4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            txtNhapSo = new TextBox();
            txtDayVuaNhap = new TextBox();
            txtTong = new TextBox();
            txtTongChan = new TextBox();
            txtTongLe = new TextBox();
            btnNhap = new Button();
            btnTiepTuc = new Button();
            btnThoat = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(292, 69);
            label1.Name = "label1";
            label1.Size = new Size(140, 15);
            label1.TabIndex = 0;
            label1.Text = "Nhập dãy số và tính tổng";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(234, 115);
            label2.Name = "label2";
            label2.Size = new Size(51, 15);
            label2.TabIndex = 1;
            label2.Text = "Nhập số";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(234, 174);
            label3.Name = "label3";
            label3.Size = new Size(79, 15);
            label3.TabIndex = 2;
            label3.Text = "Dãy vừa nhập";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(234, 230);
            label4.Name = "label4";
            label4.Size = new Size(154, 15);
            label4.TabIndex = 3;
            label4.Text = "Tổng các phần tử trong dãy";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(234, 288);
            label5.Name = "label5";
            label5.Size = new Size(64, 15);
            label5.TabIndex = 4;
            label5.Text = "Tổng chẵn";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(432, 288);
            label6.Name = "label6";
            label6.Size = new Size(47, 15);
            label6.TabIndex = 5;
            label6.Text = "Tổng lẻ";
            // 
            // txtNhapSo
            // 
            txtNhapSo.Location = new Point(304, 112);
            txtNhapSo.Name = "txtNhapSo";
            txtNhapSo.Size = new Size(100, 23);
            txtNhapSo.TabIndex = 6;
            // 
            // txtDayVuaNhap
            // 
            txtDayVuaNhap.Location = new Point(319, 171);
            txtDayVuaNhap.Name = "txtDayVuaNhap";
            txtDayVuaNhap.Size = new Size(100, 23);
            txtDayVuaNhap.TabIndex = 7;
            // 
            // txtTong
            // 
            txtTong.Location = new Point(394, 230);
            txtTong.Name = "txtTong";
            txtTong.Size = new Size(100, 23);
            txtTong.TabIndex = 8;
            // 
            // txtTongChan
            // 
            txtTongChan.Location = new Point(304, 280);
            txtTongChan.Name = "txtTongChan";
            txtTongChan.Size = new Size(100, 23);
            txtTongChan.TabIndex = 9;
            // 
            // txtTongLe
            // 
            txtTongLe.Location = new Point(496, 280);
            txtTongLe.Name = "txtTongLe";
            txtTongLe.Size = new Size(100, 23);
            txtTongLe.TabIndex = 10;
            // 
            // btnNhap
            // 
            btnNhap.Location = new Point(432, 112);
            btnNhap.Name = "btnNhap";
            btnNhap.Size = new Size(75, 23);
            btnNhap.TabIndex = 11;
            btnNhap.Text = "Nhập";
            btnNhap.UseVisualStyleBackColor = true;
            btnNhap.Click += btnNhap_Click;
            // 
            // btnTiepTuc
            // 
            btnTiepTuc.Location = new Point(292, 337);
            btnTiepTuc.Name = "btnTiepTuc";
            btnTiepTuc.Size = new Size(75, 23);
            btnTiepTuc.TabIndex = 12;
            btnTiepTuc.Text = "Tiếp tục";
            btnTiepTuc.UseVisualStyleBackColor = true;
            btnTiepTuc.Click += btnTiepTuc_Click;
            // 
            // btnThoat
            // 
            btnThoat.Location = new Point(448, 337);
            btnThoat.Name = "btnThoat";
            btnThoat.Size = new Size(75, 23);
            btnThoat.TabIndex = 13;
            btnThoat.Text = "Thoát";
            btnThoat.UseVisualStyleBackColor = true;
            btnThoat.Click += btnThoat_Click;
            // 
            // frmBaiTap4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnThoat);
            Controls.Add(btnTiepTuc);
            Controls.Add(btnNhap);
            Controls.Add(txtTongLe);
            Controls.Add(txtTongChan);
            Controls.Add(txtTong);
            Controls.Add(txtDayVuaNhap);
            Controls.Add(txtNhapSo);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "frmBaiTap4";
            Text = "frmBaiTap4";
            FormClosing += frmBaiTap4_FormClosing;
            Load += frmBaiTap4_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox txtNhapSo;
        private TextBox txtDayVuaNhap;
        private TextBox txtTong;
        private TextBox txtTongChan;
        private TextBox txtTongLe;
        private Button btnNhap;
        private Button btnTiepTuc;
        private Button btnThoat;
    }
}