﻿namespace Bai1MayTinh
{
    partial class frmBaiTap2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            blbDangKyTaiKhoan = new Label();
            lblTenDangNhap = new Label();
            lblDiaChiEmail = new Label();
            lblMatKhau = new Label();
            lblXacNhanMatKhau = new Label();
            txtTenDangNhap = new TextBox();
            txtDiaChiEmail = new TextBox();
            txtXacNhanMatKhau = new TextBox();
            txtMatKhau = new TextBox();
            btnDangKy = new Button();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            errorProvider1 = new ErrorProvider(components);
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            SuspendLayout();
            // 
            // blbDangKyTaiKhoan
            // 
            blbDangKyTaiKhoan.AutoSize = true;
            blbDangKyTaiKhoan.ForeColor = Color.Blue;
            blbDangKyTaiKhoan.Location = new Point(328, 82);
            blbDangKyTaiKhoan.Name = "blbDangKyTaiKhoan";
            blbDangKyTaiKhoan.Size = new Size(102, 15);
            blbDangKyTaiKhoan.TabIndex = 0;
            blbDangKyTaiKhoan.Text = "Đăng ký tài khoản";
            blbDangKyTaiKhoan.Click += blbDangKyTaiKhoan_Click;
            // 
            // lblTenDangNhap
            // 
            lblTenDangNhap.AutoSize = true;
            lblTenDangNhap.Location = new Point(199, 123);
            lblTenDangNhap.Name = "lblTenDangNhap";
            lblTenDangNhap.Size = new Size(87, 15);
            lblTenDangNhap.TabIndex = 1;
            lblTenDangNhap.Text = "Tên Đăng nhập";
            lblTenDangNhap.TextAlign = ContentAlignment.TopRight;
            lblTenDangNhap.Click += label2_Click;
            // 
            // lblDiaChiEmail
            // 
            lblDiaChiEmail.AutoSize = true;
            lblDiaChiEmail.Location = new Point(199, 179);
            lblDiaChiEmail.Name = "lblDiaChiEmail";
            lblDiaChiEmail.Size = new Size(75, 15);
            lblDiaChiEmail.TabIndex = 2;
            lblDiaChiEmail.Text = "Địa chỉ email";
            lblDiaChiEmail.Click += label3_Click;
            // 
            // lblMatKhau
            // 
            lblMatKhau.AutoSize = true;
            lblMatKhau.Location = new Point(199, 231);
            lblMatKhau.Name = "lblMatKhau";
            lblMatKhau.Size = new Size(57, 15);
            lblMatKhau.TabIndex = 3;
            lblMatKhau.Text = "Mật khẩu";
            lblMatKhau.Click += lblMatKhau_Click;
            // 
            // lblXacNhanMatKhau
            // 
            lblXacNhanMatKhau.AutoSize = true;
            lblXacNhanMatKhau.Location = new Point(199, 284);
            lblXacNhanMatKhau.Name = "lblXacNhanMatKhau";
            lblXacNhanMatKhau.Size = new Size(109, 15);
            lblXacNhanMatKhau.TabIndex = 4;
            lblXacNhanMatKhau.Text = "Xác nhận mật khẩu";
            lblXacNhanMatKhau.Click += lblXacNhanMatKhau_Click;
            // 
            // txtTenDangNhap
            // 
            txtTenDangNhap.Location = new Point(329, 123);
            txtTenDangNhap.Name = "txtTenDangNhap";
            txtTenDangNhap.Size = new Size(154, 23);
            txtTenDangNhap.TabIndex = 5;
            txtTenDangNhap.TextChanged += txtTenDangNhap_TextChanged;
            // 
            // txtDiaChiEmail
            // 
            txtDiaChiEmail.Location = new Point(329, 179);
            txtDiaChiEmail.Name = "txtDiaChiEmail";
            txtDiaChiEmail.Size = new Size(154, 23);
            txtDiaChiEmail.TabIndex = 6;
            txtDiaChiEmail.TextChanged += txtDiaChiEmail_TextChanged;
            txtDiaChiEmail.Leave += txtDiaChiEmail_Leave;
            // 
            // txtXacNhanMatKhau
            // 
            txtXacNhanMatKhau.Location = new Point(328, 281);
            txtXacNhanMatKhau.Name = "txtXacNhanMatKhau";
            txtXacNhanMatKhau.Size = new Size(155, 23);
            txtXacNhanMatKhau.TabIndex = 7;
            txtXacNhanMatKhau.TextChanged += txtXacNhanMatKhau_TextChanged;
            txtXacNhanMatKhau.KeyDown += txtXacNhanMatKhau_KeyDown;
            // 
            // txtMatKhau
            // 
            txtMatKhau.Location = new Point(329, 231);
            txtMatKhau.Name = "txtMatKhau";
            txtMatKhau.Size = new Size(154, 23);
            txtMatKhau.TabIndex = 8;
            txtMatKhau.TextChanged += txtMatKhau_TextChanged;
            // 
            // btnDangKy
            // 
            btnDangKy.ForeColor = Color.Blue;
            btnDangKy.Location = new Point(321, 335);
            btnDangKy.Name = "btnDangKy";
            btnDangKy.Size = new Size(162, 23);
            btnDangKy.TabIndex = 9;
            btnDangKy.Text = "Đăng ký";
            btnDangKy.UseVisualStyleBackColor = true;
            btnDangKy.Click += btnDangKy_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(514, 126);
            label6.Name = "label6";
            label6.Size = new Size(20, 15);
            label6.TabIndex = 10;
            label6.Text = "(*)";
            label6.Click += label6_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(514, 187);
            label7.Name = "label7";
            label7.Size = new Size(20, 15);
            label7.TabIndex = 11;
            label7.Text = "(*)";
            label7.Click += label7_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(514, 239);
            label8.Name = "label8";
            label8.Size = new Size(20, 15);
            label8.TabIndex = 12;
            label8.Text = "(*)";
            label8.Click += label8_Click;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // frmBaiTap2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(btnDangKy);
            Controls.Add(txtMatKhau);
            Controls.Add(txtXacNhanMatKhau);
            Controls.Add(txtDiaChiEmail);
            Controls.Add(txtTenDangNhap);
            Controls.Add(lblXacNhanMatKhau);
            Controls.Add(lblMatKhau);
            Controls.Add(lblDiaChiEmail);
            Controls.Add(lblTenDangNhap);
            Controls.Add(blbDangKyTaiKhoan);
            Name = "frmBaiTap2";
            Text = "frmBaiTap2";
            FormClosing += frmBaiTap2_FormClosing;
            Load += frmBaiTap2_Load;
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label blbDangKyTaiKhoan;
        private Label lblTenDangNhap;
        private Label lblDiaChiEmail;
        private Label lblMatKhau;
        private Label lblXacNhanMatKhau;
        private TextBox txtTenDangNhap;
        private TextBox txtDiaChiEmail;
        private TextBox txtXacNhanMatKhau;
        private TextBox txtMatKhau;
        private Button btnDangKy;
        private Label label6;
        private Label label7;
        private Label label8;
        private ErrorProvider errorProvider1;
    }
}