﻿namespace Bai1MayTinh
{
    partial class frmBaiTap1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            lbla = new Label();
            lblb = new Label();
            lblketqua = new Label();
            txta = new TextBox();
            txtb = new TextBox();
            txtketqua = new TextBox();
            btncong = new Button();
            btntru = new Button();
            btnnahn = new Button();
            btnchia = new Button();
            errorProvider1 = new ErrorProvider(components);
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            SuspendLayout();
            // 
            // lbla
            // 
            lbla.AutoSize = true;
            lbla.Location = new Point(135, 130);
            lbla.Name = "lbla";
            lbla.Size = new Size(21, 15);
            lbla.TabIndex = 0;
            lbla.Text = "a=";
            lbla.Click += label1_Click;
            // 
            // lblb
            // 
            lblb.AutoSize = true;
            lblb.Location = new Point(297, 130);
            lblb.Name = "lblb";
            lblb.Size = new Size(22, 15);
            lblb.TabIndex = 1;
            lblb.Text = "b=";
            lblb.Click += label2_Click;
            // 
            // lblketqua
            // 
            lblketqua.AutoSize = true;
            lblketqua.Location = new Point(135, 187);
            lblketqua.Name = "lblketqua";
            lblketqua.Size = new Size(46, 15);
            lblketqua.TabIndex = 2;
            lblketqua.Text = "ket qua";
            lblketqua.Click += label3_Click;
            // 
            // txta
            // 
            txta.Location = new Point(162, 130);
            txta.Name = "txta";
            txta.Size = new Size(100, 23);
            txta.TabIndex = 3;
            txta.TextChanged += textBox1_TextChanged;
            txta.KeyPress += txta_KeyPress;
            txta.Leave += txta_Leave;
            // 
            // txtb
            // 
            txtb.Location = new Point(336, 130);
            txtb.Name = "txtb";
            txtb.Size = new Size(100, 23);
            txtb.TabIndex = 4;
            txtb.TextChanged += textBox2_TextChanged;
            txtb.KeyPress += txtb_KeyPress;
            txtb.Leave += txtb_Leave;
            // 
            // txtketqua
            // 
            txtketqua.Location = new Point(187, 184);
            txtketqua.Name = "txtketqua";
            txtketqua.Size = new Size(249, 23);
            txtketqua.TabIndex = 5;
            txtketqua.TextChanged += textBox3_TextChanged;
            // 
            // btncong
            // 
            btncong.Location = new Point(135, 234);
            btncong.Name = "btncong";
            btncong.Size = new Size(75, 23);
            btncong.TabIndex = 6;
            btncong.Text = "+";
            btncong.UseVisualStyleBackColor = true;
            btncong.Click += button1_Click;
            // 
            // btntru
            // 
            btntru.Location = new Point(216, 234);
            btntru.Name = "btntru";
            btntru.Size = new Size(75, 23);
            btntru.TabIndex = 7;
            btntru.Text = "-";
            btntru.UseVisualStyleBackColor = true;
            btntru.Click += button2_Click;
            // 
            // btnnahn
            // 
            btnnahn.Location = new Point(297, 234);
            btnnahn.Name = "btnnahn";
            btnnahn.Size = new Size(75, 23);
            btnnahn.TabIndex = 8;
            btnnahn.Text = "x";
            btnnahn.UseVisualStyleBackColor = true;
            btnnahn.Click += button3_Click;
            // 
            // btnchia
            // 
            btnchia.Location = new Point(378, 234);
            btnchia.Name = "btnchia";
            btnchia.Size = new Size(75, 23);
            btnchia.TabIndex = 9;
            btnchia.Text = "/";
            btnchia.UseVisualStyleBackColor = true;
            btnchia.Click += btnchia_Click;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // frmBaiTap1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnchia);
            Controls.Add(btnnahn);
            Controls.Add(btntru);
            Controls.Add(btncong);
            Controls.Add(txtketqua);
            Controls.Add(txtb);
            Controls.Add(txta);
            Controls.Add(lblketqua);
            Controls.Add(lblb);
            Controls.Add(lbla);
            Name = "frmBaiTap1";
            Text = "frmBaiTap1";
            FormClosing += frmBaiTap1_FormClosing;
            Load += frmBaiTap1_Load;
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbla;
        private Label lblb;
        private Label lblketqua;
        private TextBox txta;
        private TextBox txtb;
        private TextBox txtketqua;
        private Button btncong;
        private Button btntru;
        private Button btnnahn;
        private Button btnchia;
        private ErrorProvider errorProvider1;
    }
}