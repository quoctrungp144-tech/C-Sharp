﻿namespace ThucHanh4d
{
    partial class baitailop1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            txta = new TextBox();
            txtb = new TextBox();
            txtc = new TextBox();
            txtKetQua = new TextBox();
            chkBacNhat = new CheckBox();
            chkBacHai = new CheckBox();
            btnGiai = new Button();
            btnThoat = new Button();
            errorProvider1 = new ErrorProvider(components);
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(338, 58);
            label1.Name = "label1";
            label1.Size = new Size(100, 15);
            label1.TabIndex = 0;
            label1.Text = "Giải phương trình";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(187, 82);
            label2.Name = "label2";
            label2.Size = new Size(103, 15);
            label2.TabIndex = 1;
            label2.Text = "Bạn vui lòng chọn";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(187, 188);
            label3.Name = "label3";
            label3.Size = new Size(48, 15);
            label3.TabIndex = 2;
            label3.Text = "Nhập a:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(187, 225);
            label4.Name = "label4";
            label4.Size = new Size(49, 15);
            label4.TabIndex = 3;
            label4.Text = "Nhập b:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(187, 269);
            label5.Name = "label5";
            label5.Size = new Size(48, 15);
            label5.TabIndex = 4;
            label5.Text = "Nhập c:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(187, 316);
            label6.Name = "label6";
            label6.Size = new Size(50, 15);
            label6.TabIndex = 5;
            label6.Text = "Kết quả:";
            // 
            // txta
            // 
            txta.Location = new Point(276, 180);
            txta.Name = "txta";
            txta.Size = new Size(100, 23);
            txta.TabIndex = 6;
            // 
            // txtb
            // 
            txtb.Location = new Point(276, 225);
            txtb.Name = "txtb";
            txtb.Size = new Size(100, 23);
            txtb.TabIndex = 7;
            // 
            // txtc
            // 
            txtc.Location = new Point(276, 261);
            txtc.Name = "txtc";
            txtc.Size = new Size(100, 23);
            txtc.TabIndex = 8;
            // 
            // txtKetQua
            // 
            txtKetQua.Location = new Point(276, 308);
            txtKetQua.Name = "txtKetQua";
            txtKetQua.Size = new Size(236, 23);
            txtKetQua.TabIndex = 9;
            // 
            // chkBacNhat
            // 
            chkBacNhat.AutoSize = true;
            chkBacNhat.Location = new Point(256, 111);
            chkBacNhat.Name = "chkBacNhat";
            chkBacNhat.Size = new Size(145, 19);
            chkBacNhat.TabIndex = 10;
            chkBacNhat.Text = "Phương trình bặc nhất";
            chkBacNhat.UseVisualStyleBackColor = true;
            // 
            // chkBacHai
            // 
            chkBacHai.AutoSize = true;
            chkBacHai.Location = new Point(256, 136);
            chkBacHai.Name = "chkBacHai";
            chkBacHai.Size = new Size(137, 19);
            chkBacHai.TabIndex = 11;
            chkBacHai.Text = "Phương trình bậc hai";
            chkBacHai.UseVisualStyleBackColor = true;
            // 
            // btnGiai
            // 
            btnGiai.Location = new Point(437, 221);
            btnGiai.Name = "btnGiai";
            btnGiai.Size = new Size(75, 23);
            btnGiai.TabIndex = 12;
            btnGiai.Text = "Giải ";
            btnGiai.UseVisualStyleBackColor = true;
            // 
            // btnThoat
            // 
            btnThoat.Location = new Point(437, 265);
            btnThoat.Name = "btnThoat";
            btnThoat.Size = new Size(75, 23);
            btnThoat.TabIndex = 13;
            btnThoat.Text = "Thoát";
            btnThoat.UseVisualStyleBackColor = true;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // baitailop1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 619);
            Controls.Add(btnThoat);
            Controls.Add(btnGiai);
            Controls.Add(chkBacHai);
            Controls.Add(chkBacNhat);
            Controls.Add(txtKetQua);
            Controls.Add(txtc);
            Controls.Add(txtb);
            Controls.Add(txta);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "baitailop1";
            Text = "baitailop1";
            FormClosing += baitailop1_FormClosing;
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox txta;
        private TextBox txtb;
        private TextBox txtc;
        private TextBox txtKetQua;
        private CheckBox chkBacNhat;
        private CheckBox chkBacHai;
        private Button btnGiai;
        private Button btnThoat;
        private ErrorProvider errorProvider1;
    }
}