﻿namespace ThucHanh4d
{
    partial class bai1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtb = new TextBox();
            txta = new TextBox();
            txtKetQua = new TextBox();
            errorProvider1 = new ErrorProvider(components);
            rdoCong = new RadioButton();
            rdoTru = new RadioButton();
            rdoNhan = new RadioButton();
            rdoChia = new RadioButton();
            btnTinh = new Button();
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(207, 118);
            label1.Name = "label1";
            label1.Size = new Size(21, 15);
            label1.TabIndex = 0;
            label1.Text = "a=";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(377, 118);
            label2.Name = "label2";
            label2.Size = new Size(22, 15);
            label2.TabIndex = 1;
            label2.Text = "b=";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(207, 185);
            label3.Name = "label3";
            label3.Size = new Size(47, 15);
            label3.TabIndex = 2;
            label3.Text = "Kết quả";
            // 
            // txtb
            // 
            txtb.Location = new Point(446, 115);
            txtb.Name = "txtb";
            txtb.Size = new Size(100, 23);
            txtb.TabIndex = 3;
            // 
            // txta
            // 
            txta.Location = new Point(262, 115);
            txta.Name = "txta";
            txta.Size = new Size(100, 23);
            txta.TabIndex = 4;
            // 
            // txtKetQua
            // 
            txtKetQua.Location = new Point(273, 177);
            txtKetQua.Name = "txtKetQua";
            txtKetQua.Size = new Size(100, 23);
            txtKetQua.TabIndex = 5;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // rdoCong
            // 
            rdoCong.AutoSize = true;
            rdoCong.Location = new Point(151, 242);
            rdoCong.Name = "rdoCong";
            rdoCong.Size = new Size(33, 19);
            rdoCong.TabIndex = 6;
            rdoCong.TabStop = true;
            rdoCong.Text = "+";
            rdoCong.UseVisualStyleBackColor = true;
            // 
            // rdoTru
            // 
            rdoTru.AutoSize = true;
            rdoTru.Location = new Point(268, 242);
            rdoTru.Name = "rdoTru";
            rdoTru.Size = new Size(30, 19);
            rdoTru.TabIndex = 7;
            rdoTru.TabStop = true;
            rdoTru.Text = "-";
            rdoTru.UseVisualStyleBackColor = true;
            // 
            // rdoNhan
            // 
            rdoNhan.AutoSize = true;
            rdoNhan.Location = new Point(402, 242);
            rdoNhan.Name = "rdoNhan";
            rdoNhan.Size = new Size(30, 19);
            rdoNhan.TabIndex = 8;
            rdoNhan.TabStop = true;
            rdoNhan.Text = "x";
            rdoNhan.UseVisualStyleBackColor = true;
            // 
            // rdoChia
            // 
            rdoChia.AutoSize = true;
            rdoChia.Location = new Point(527, 242);
            rdoChia.Name = "rdoChia";
            rdoChia.Size = new Size(30, 19);
            rdoChia.TabIndex = 9;
            rdoChia.TabStop = true;
            rdoChia.Text = "/";
            rdoChia.UseVisualStyleBackColor = true;
            // 
            // btnTinh
            // 
            btnTinh.Location = new Point(287, 304);
            btnTinh.Name = "btnTinh";
            btnTinh.Size = new Size(75, 23);
            btnTinh.TabIndex = 10;
            btnTinh.Text = "Tính";
            btnTinh.UseVisualStyleBackColor = true;
            btnTinh.Click += btnTinh_Click;
            // 
            // bai1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnTinh);
            Controls.Add(rdoChia);
            Controls.Add(rdoNhan);
            Controls.Add(rdoTru);
            Controls.Add(rdoCong);
            Controls.Add(txtKetQua);
            Controls.Add(txta);
            Controls.Add(txtb);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "bai1";
            Text = "bai1";
            FormClosing += bai1_FormClosing;
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtb;
        private TextBox txta;
        private TextBox txtKetQua;
        private ErrorProvider errorProvider1;
        private RadioButton rdoChia;
        private RadioButton rdoNhan;
        private RadioButton rdoTru;
        private RadioButton rdoCong;
        private Button btnTinh;
    }
}