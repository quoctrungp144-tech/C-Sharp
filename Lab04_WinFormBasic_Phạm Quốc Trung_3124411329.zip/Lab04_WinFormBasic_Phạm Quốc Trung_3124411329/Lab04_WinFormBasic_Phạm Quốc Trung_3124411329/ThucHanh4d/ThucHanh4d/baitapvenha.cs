﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ThucHanh4d
{
    public partial class baitapvenha : Form
    {
        int tongLuotKhach = 0;
        double tongTien = 0;
        public baitapvenha()
        {
            InitializeComponent();
        }
        private void baitapvenha_Load(object sender, EventArgs e)
        {
            txtHoTen.Text = "";
            txtDiaChi.Text = "";
            txtSoNgay.Text = "";

            rdoPhongDon.Checked = false;
            rdoPhongDoi.Checked = false;
            rdoPhongBa.Checked = false;

            chkTivi.Checked = false;
            chkInternet.Checked = false;
            chkMayNuocNong.Checked = false;
            chkKaraoke.Checked = false;
            chkAnSang.Checked = false;

            lblThanhTien.Text = "0 VND";
            lblSoLuotNguoi.Text = "0";
            lblTongSoTien.Text = "0 VND";

            btnThanhToan.Enabled = false;
            btnNhapMoi.Enabled = false;
            btnTongKet.Enabled = false;
        }

        // Kiểm tra dữ liệu đã nhập đủ chưa
        private void KiemTraDuLieu()
        {
            int soNgay;

            bool hopLe =
                txtHoTen.Text.Trim() != "" &&
                txtDiaChi.Text.Trim() != "" &&
                int.TryParse(txtSoNgay.Text, out soNgay) &&
                soNgay > 0 &&
                (rdoPhongDon.Checked ||
                 rdoPhongDoi.Checked ||
                 rdoPhongBa.Checked);

            btnThanhToan.Enabled = hopLe;
        }

        // Khi nhập họ tên
        private void txtHoTen_TextChanged(object sender, EventArgs e)
        {
            KiemTraDuLieu();
        }

        // Khi nhập địa chỉ
        private void txtDiaChi_TextChanged(object sender, EventArgs e)
        {
            KiemTraDuLieu();
        }

        // Khi nhập số ngày
        private void txtSoNgay_TextChanged(object sender, EventArgs e)
        {
            KiemTraDuLieu();
        }

        // Chọn loại phòng
        private void rdoPhongDon_CheckedChanged(object sender, EventArgs e)
        {
            KiemTraDuLieu();
        }

        private void rdoPhongDoi_CheckedChanged(object sender, EventArgs e)
        {
            KiemTraDuLieu();
        }

        private void rdoPhongBa_CheckedChanged(object sender, EventArgs e)
        {
            KiemTraDuLieu();
        }

        // Thanh toán
        private void btnThanhToan_Click(object sender, EventArgs e)
        {
            int soNgay = int.Parse(txtSoNgay.Text);

            double giaPhong = 0;
            double thanhTien;

            // Giá phòng
            if (rdoPhongDon.Checked)
            {
                giaPhong = 300000;
            }
            else if (rdoPhongDoi.Checked)
            {
                giaPhong = 350000;
            }
            else if (rdoPhongBa.Checked)
            {
                giaPhong = 400000;
            }

            // Tiền phòng
            thanhTien = giaPhong * soNgay;

            // Tiện nghi: mỗi loại + 10.000
            if (chkTivi.Checked)
            {
                thanhTien += 10000;
            }

            if (chkInternet.Checked)
            {
                thanhTien += 10000;
            }

            if (chkMayNuocNong.Checked)
            {
                thanhTien += 10000;
            }

            // Dịch vụ
            if (chkKaraoke.Checked)
            {
                thanhTien += 50000;
            }

            if (chkAnSang.Checked)
            {
                thanhTien += 15000 * soNgay;
            }

            // Hiển thị thành tiền
            lblThanhTien.Text = thanhTien.ToString("N0") + " VND";

            // Lưu tổng
            tongLuotKhach++;
            tongTien += thanhTien;

            // Sau khi thanh toán
            btnNhapMoi.Enabled = true;
            btnTongKet.Enabled = true;
            btnThanhToan.Enabled = false;
        }

        // Nhập mới
        private void btnNhapMoi_Click(object sender, EventArgs e)
        {
            txtHoTen.Text = "";
            txtDiaChi.Text = "";
            txtSoNgay.Text = "";

            rdoPhongDon.Checked = false;
            rdoPhongDoi.Checked = false;
            rdoPhongBa.Checked = false;

            chkTivi.Checked = false;
            chkInternet.Checked = false;
            chkMayNuocNong.Checked = false;
            chkKaraoke.Checked = false;
            chkAnSang.Checked = false;

            lblThanhTien.Text = "0 VND";

            btnThanhToan.Enabled = false;
            btnNhapMoi.Enabled = false;
        }

        // Tổng kết
        private void btnTongKet_Click(object sender, EventArgs e)
        {
            lblSoLuotNguoi.Text = tongLuotKhach.ToString();
            lblTongSoTien.Text = tongTien.ToString("N0") + " VND";


            btnTongKet.Enabled = false;
        }

        // Thoát
        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Bạn có chắc muốn thoát chương trình không?",
                "Xác nhận",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void baitapvenha_FormClosing(object sender, FormClosingEventArgs e)
        {

        }
    }
}
