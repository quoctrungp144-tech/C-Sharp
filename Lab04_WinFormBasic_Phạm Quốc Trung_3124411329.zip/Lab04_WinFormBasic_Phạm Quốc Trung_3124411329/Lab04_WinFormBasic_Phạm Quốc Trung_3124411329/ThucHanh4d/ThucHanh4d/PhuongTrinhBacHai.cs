﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ThucHanh4d
{
    public class PhuongTrinhBacHai
    {
        public double A { get; set; }
        public double B { get; set; }
        public double C { get; set; }

        public PhuongTrinhBacHai(double a, double b, double c)
        {
            A = a;
            B = b;
            C = c;
        }

        public string GiaiBacNhat()
        {
            if (A == 0)
            {
                if (B == 0)
                {
                    return "Vô số nghiệm";
                }

                return "Vô nghiệm";
            }

            double x = -B / A;

            return "x = " + x;
        }

        public string GiaiBacHai()
        {
            double delta = B * B - 4 * A * C;

            if (delta < 0)
            {
                return "Vô nghiệm";
            }

            if (delta == 0)
            {
                double x = -B / (2 * A);

                return "x = " + x;
            }

            double x1 = (-B + Math.Sqrt(delta)) / (2 * A);
            double x2 = (-B - Math.Sqrt(delta)) / (2 * A);

            return "x1 = " + x1 + "\r\nx2 = " + x2;
        }
    }
}
