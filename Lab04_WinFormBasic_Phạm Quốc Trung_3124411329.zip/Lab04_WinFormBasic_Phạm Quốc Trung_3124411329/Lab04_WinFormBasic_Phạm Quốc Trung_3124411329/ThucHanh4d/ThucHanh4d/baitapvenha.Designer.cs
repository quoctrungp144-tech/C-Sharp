﻿namespace ThucHanh4d
{
    partial class baitapvenha
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            lblThanhTien = new Label();
            label9 = new Label();
            lblSoLuotNguoi = new Label();
            lblTongSoTien = new Label();
            btnThoat = new Button();
            btnTongKet = new Button();
            btnThanhToan = new Button();
            btnNhapMoi = new Button();
            txtHoTen = new TextBox();
            txtDiaChi = new TextBox();
            txtSoNgay = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            rdoPhongDon = new RadioButton();
            rdoPhongDoi = new RadioButton();
            rdoPhongBa = new RadioButton();
            chkTivi = new CheckBox();
            chkInternet = new CheckBox();
            chkMayNuocNong = new CheckBox();
            chkKaraoke = new CheckBox();
            chkAnSang = new CheckBox();
            errorProvider1 = new ErrorProvider(components);
            ((System.ComponentModel.ISupportInitialize)errorProvider1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(328, 31);
            label1.Name = "label1";
            label1.Size = new Size(198, 15);
            label1.TabIndex = 0;
            label1.Text = "Khách sạn Thanh Thanh - trả phòng";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(140, 73);
            label2.Name = "label2";
            label2.Size = new Size(58, 15);
            label2.TabIndex = 1;
            label2.Text = "Họ và tên";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(140, 111);
            label3.Name = "label3";
            label3.Size = new Size(43, 15);
            label3.TabIndex = 2;
            label3.Text = "Địa chỉ";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(140, 151);
            label4.Name = "label4";
            label4.Size = new Size(59, 15);
            label4.TabIndex = 3;
            label4.Text = "Số ngày ở";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(140, 211);
            label5.Name = "label5";
            label5.Size = new Size(67, 15);
            label5.TabIndex = 4;
            label5.Text = "Loại phòng";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(263, 211);
            label6.Name = "label6";
            label6.Size = new Size(57, 15);
            label6.TabIndex = 5;
            label6.Text = "Tiện nghi";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(392, 211);
            label7.Name = "label7";
            label7.Size = new Size(47, 15);
            label7.TabIndex = 6;
            label7.Text = "Dịch vụ";
            // 
            // lblThanhTien
            // 
            lblThanhTien.AutoSize = true;
            lblThanhTien.Location = new Point(552, 111);
            lblThanhTien.Name = "lblThanhTien";
            lblThanhTien.Size = new Size(64, 15);
            lblThanhTien.TabIndex = 7;
            lblThanhTien.Text = "Thành tiền";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(552, 184);
            label9.Name = "label9";
            label9.Size = new Size(106, 15);
            label9.TabIndex = 8;
            label9.Text = "Thông tin tổng kết";
            // 
            // lblSoLuotNguoi
            // 
            lblSoLuotNguoi.AutoSize = true;
            lblSoLuotNguoi.Location = new Point(552, 231);
            lblSoLuotNguoi.Name = "lblSoLuotNguoi";
            lblSoLuotNguoi.Size = new Size(78, 15);
            lblSoLuotNguoi.TabIndex = 9;
            lblSoLuotNguoi.Text = "Số lượt người";
            // 
            // lblTongSoTien
            // 
            lblTongSoTien.AutoSize = true;
            lblTongSoTien.Location = new Point(552, 275);
            lblTongSoTien.Name = "lblTongSoTien";
            lblTongSoTien.Size = new Size(73, 15);
            lblTongSoTien.TabIndex = 10;
            lblTongSoTien.Text = "Tổng số tiền";
            // 
            // btnThoat
            // 
            btnThoat.Location = new Point(552, 318);
            btnThoat.Name = "btnThoat";
            btnThoat.Size = new Size(75, 26);
            btnThoat.TabIndex = 11;
            btnThoat.Text = "Thoát";
            btnThoat.UseVisualStyleBackColor = true;
            // 
            // btnTongKet
            // 
            btnTongKet.Location = new Point(540, 145);
            btnTongKet.Name = "btnTongKet";
            btnTongKet.Size = new Size(75, 26);
            btnTongKet.TabIndex = 12;
            btnTongKet.Text = "Tổng kết";
            btnTongKet.UseVisualStyleBackColor = true;
            // 
            // btnThanhToan
            // 
            btnThanhToan.Location = new Point(540, 62);
            btnThanhToan.Name = "btnThanhToan";
            btnThanhToan.Size = new Size(90, 26);
            btnThanhToan.TabIndex = 13;
            btnThanhToan.Text = "Thanh toán";
            btnThanhToan.UseVisualStyleBackColor = true;
            // 
            // btnNhapMoi
            // 
            btnNhapMoi.Location = new Point(669, 62);
            btnNhapMoi.Name = "btnNhapMoi";
            btnNhapMoi.Size = new Size(75, 26);
            btnNhapMoi.TabIndex = 14;
            btnNhapMoi.Text = "Nhập mới";
            btnNhapMoi.UseVisualStyleBackColor = true;
            // 
            // txtHoTen
            // 
            txtHoTen.Location = new Point(226, 70);
            txtHoTen.Name = "txtHoTen";
            txtHoTen.Size = new Size(100, 23);
            txtHoTen.TabIndex = 15;
            // 
            // txtDiaChi
            // 
            txtDiaChi.Location = new Point(226, 103);
            txtDiaChi.Name = "txtDiaChi";
            txtDiaChi.Size = new Size(233, 23);
            txtDiaChi.TabIndex = 16;
            // 
            // txtSoNgay
            // 
            txtSoNgay.Location = new Point(226, 143);
            txtSoNgay.Name = "txtSoNgay";
            txtSoNgay.Size = new Size(100, 23);
            txtSoNgay.TabIndex = 17;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(644, 103);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(100, 23);
            textBox4.TabIndex = 18;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(644, 223);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(100, 23);
            textBox5.TabIndex = 19;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(644, 267);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(100, 23);
            textBox6.TabIndex = 20;
            // 
            // rdoPhongDon
            // 
            rdoPhongDon.AutoSize = true;
            rdoPhongDon.Location = new Point(140, 250);
            rdoPhongDon.Name = "rdoPhongDon";
            rdoPhongDon.Size = new Size(84, 19);
            rdoPhongDon.TabIndex = 21;
            rdoPhongDon.TabStop = true;
            rdoPhongDon.Text = "phòng đơn";
            rdoPhongDon.UseVisualStyleBackColor = true;
            // 
            // rdoPhongDoi
            // 
            rdoPhongDoi.AutoSize = true;
            rdoPhongDoi.Location = new Point(140, 289);
            rdoPhongDoi.Name = "rdoPhongDoi";
            rdoPhongDoi.Size = new Size(80, 19);
            rdoPhongDoi.TabIndex = 22;
            rdoPhongDoi.TabStop = true;
            rdoPhongDoi.Text = "phòng đôi";
            rdoPhongDoi.UseVisualStyleBackColor = true;
            // 
            // rdoPhongBa
            // 
            rdoPhongBa.AutoSize = true;
            rdoPhongBa.Location = new Point(140, 325);
            rdoPhongBa.Name = "rdoPhongBa";
            rdoPhongBa.Size = new Size(76, 19);
            rdoPhongBa.TabIndex = 23;
            rdoPhongBa.TabStop = true;
            rdoPhongBa.Text = "phòng ba";
            rdoPhongBa.UseVisualStyleBackColor = true;
            // 
            // chkTivi
            // 
            chkTivi.AutoSize = true;
            chkTivi.Location = new Point(263, 251);
            chkTivi.Name = "chkTivi";
            chkTivi.Size = new Size(42, 19);
            chkTivi.TabIndex = 24;
            chkTivi.Text = "tivi";
            chkTivi.UseVisualStyleBackColor = true;
            // 
            // chkInternet
            // 
            chkInternet.AutoSize = true;
            chkInternet.Location = new Point(263, 289);
            chkInternet.Name = "chkInternet";
            chkInternet.Size = new Size(67, 19);
            chkInternet.TabIndex = 25;
            chkInternet.Text = "internet";
            chkInternet.UseVisualStyleBackColor = true;
            // 
            // chkMayNuocNong
            // 
            chkMayNuocNong.AutoSize = true;
            chkMayNuocNong.Location = new Point(263, 326);
            chkMayNuocNong.Name = "chkMayNuocNong";
            chkMayNuocNong.Size = new Size(110, 19);
            chkMayNuocNong.TabIndex = 26;
            chkMayNuocNong.Text = "máy nước nóng";
            chkMayNuocNong.UseVisualStyleBackColor = true;
            // 
            // chkKaraoke
            // 
            chkKaraoke.AutoSize = true;
            chkKaraoke.Location = new Point(392, 250);
            chkKaraoke.Name = "chkKaraoke";
            chkKaraoke.Size = new Size(67, 19);
            chkKaraoke.TabIndex = 27;
            chkKaraoke.Text = "karaoke";
            chkKaraoke.UseVisualStyleBackColor = true;
            // 
            // chkAnSang
            // 
            chkAnSang.AutoSize = true;
            chkAnSang.Location = new Point(392, 289);
            chkAnSang.Name = "chkAnSang";
            chkAnSang.Size = new Size(67, 19);
            chkAnSang.TabIndex = 28;
            chkAnSang.Text = "ăn sáng";
            chkAnSang.UseVisualStyleBackColor = true;
            // 
            // errorProvider1
            // 
            errorProvider1.ContainerControl = this;
            // 
            // baitapvenha
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(chkAnSang);
            Controls.Add(chkKaraoke);
            Controls.Add(chkMayNuocNong);
            Controls.Add(chkInternet);
            Controls.Add(chkTivi);
            Controls.Add(rdoPhongBa);
            Controls.Add(rdoPhongDoi);
            Controls.Add(rdoPhongDon);
            Controls.Add(textBox6);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(txtSoNgay);
            Controls.Add(txtDiaChi);
            Controls.Add(txtHoTen);
            Controls.Add(btnNhapMoi);
            Controls.Add(btnThanhToan);
            Controls.Add(btnTongKet);
            Controls.Add(btnThoat);
            Controls.Add(lblTongSoTien);
            Controls.Add(lblSoLuotNguoi);
            Controls.Add(label9);
            Controls.Add(lblThanhTien);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "baitapvenha";
            Text = "baitapvenha";
            FormClosing += baitapvenha_FormClosing;
            ((System.ComponentModel.ISupportInitialize)errorProvider1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label lblThanhTien;
        private Label label9;
        private Label lblSoLuotNguoi;
        private Label lblTongSoTien;
        private Button btnThoat;
        private Button btnTongKet;
        private Button btnThanhToan;
        private Button btnNhapMoi;
        private TextBox txtHoTen;
        private TextBox txtDiaChi;
        private TextBox txtSoNgay;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox6;
        private RadioButton rdoPhongDon;
        private RadioButton rdoPhongDoi;
        private RadioButton rdoPhongBa;
        private CheckBox chkTivi;
        private CheckBox chkInternet;
        private CheckBox chkMayNuocNong;
        private CheckBox chkKaraoke;
        private CheckBox chkAnSang;
        private ErrorProvider errorProvider1;
    }
}