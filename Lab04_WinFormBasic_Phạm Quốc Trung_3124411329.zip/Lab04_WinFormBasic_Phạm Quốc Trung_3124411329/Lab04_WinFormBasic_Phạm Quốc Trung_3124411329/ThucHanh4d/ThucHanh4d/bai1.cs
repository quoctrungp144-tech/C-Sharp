﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ThucHanh4d
{
    public partial class bai1 : Form
    {
        public bai1()
        {
            InitializeComponent();

            txtKetQua.ReadOnly = true;

            rdoCong.Checked = true;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void bai1_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Bạn có muốn đóng chương trình không?",
                "Xác nhận",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.No)
            {
                e.Cancel = true;
            }
}

        private void btnTinh_Click(object sender, EventArgs e)
        {
            double a;
            double b;

            // Kiểm tra a
            if (!double.TryParse(txta.Text, out a))
            {
                MessageBox.Show("Vui lòng nhập số a!");
                txta.Focus();
                return;
            }

            // Kiểm tra b
            if (!double.TryParse(txtb.Text, out b))
            {
                MessageBox.Show("Vui lòng nhập số b!");
                txtb.Focus();
                return;
            }

            // Không cho chia 0
            if (rdoChia.Checked && b == 0)
            {
                MessageBox.Show("Không thể chia cho 0!");
                txtb.Focus();
                return;
            }

            // Gọi class tính toán
            tinhtoanbai1 tinh = new tinhtoanbai1(a, b);

            double ketQua = 0;

            if (rdoCong.Checked)
            {
                ketQua = tinh.Cong();
            }
            else if (rdoTru.Checked)
            {
                ketQua = tinh.Tru();
            }
            else if (rdoNhan.Checked)
            {
                ketQua = tinh.Nhan();
            }
            else if (rdoChia.Checked)
            {
                ketQua = tinh.Chia();
            }

            // Hiển thị kết quả
            txtKetQua.Text = ketQua.ToString();
        }
    }
}
