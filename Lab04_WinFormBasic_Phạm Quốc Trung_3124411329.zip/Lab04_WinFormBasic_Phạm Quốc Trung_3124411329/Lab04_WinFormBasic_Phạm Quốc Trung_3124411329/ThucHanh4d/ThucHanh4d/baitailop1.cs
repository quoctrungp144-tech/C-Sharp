﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ThucHanh4d
{
    public partial class baitailop1 : Form
    {
        public baitailop1()
        {
            InitializeComponent();
            btnGiai.Enabled = false;
            txtc.Enabled = false;
            chkBacNhat.Checked = true;
        }
        private void chkBacNhat_CheckedChanged(object sender, EventArgs e)
        {
            if (chkBacNhat.Checked)
            {
                chkBacHai.Checked = false;
                txtc.Enabled = false;
            }

            KiemTraDuLieu();
        }

        // Chọn phương trình bậc hai
        private void chkBacHai_CheckedChanged(object sender, EventArgs e)
        {
            if (chkBacHai.Checked)
            {
                chkBacNhat.Checked = false;
                txtc.Enabled = true;
            }

            KiemTraDuLieu();
        }

        // Kiểm tra đã nhập đủ dữ liệu chưa
        private void txta_TextChanged(object sender, EventArgs e)
        {
            KiemTraDuLieu();
        }

        private void txtb_TextChanged(object sender, EventArgs e)
        {
            KiemTraDuLieu();
        }

        private void txtc_TextChanged(object sender, EventArgs e)
        {
            KiemTraDuLieu();
        }

        private void KiemTraDuLieu()
        {
            bool duLieuHopLe = double.TryParse(txta.Text, out _) &&
                                double.TryParse(txtb.Text, out _);

            if (chkBacHai.Checked)
            {
                duLieuHopLe = duLieuHopLe &&
                               double.TryParse(txtc.Text, out _);
            }

            btnGiai.Enabled = duLieuHopLe;
        }

        // Nút Giải
        private void btnGiai_Click(object sender, EventArgs e)
        {
            double a = double.Parse(txta.Text);
            double b = double.Parse(txtb.Text);
            double c = 0;

            if (chkBacHai.Checked)
            {
                c = double.Parse(txtc.Text);
            }

            PhuongTrinhBacHai pt =
                new PhuongTrinhBacHai(a, b, c);

            if (chkBacNhat.Checked)
            {
                txtKetQua.Text = pt.GiaiBacNhat();
            }
            else if (chkBacHai.Checked)
            {
                if (a == 0)
                {
                    txtKetQua.Text = pt.GiaiBacNhat();
                }
                else
                {
                    txtKetQua.Text = pt.GiaiBacHai();
                }
            }
        }

        // Nút Thoát
        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Bạn có chắc muốn thoát không?",
                "Xác nhận",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }
        private void baitailop1_FormClosing(object sender, FormClosingEventArgs e)
        {

        }
    }
}
