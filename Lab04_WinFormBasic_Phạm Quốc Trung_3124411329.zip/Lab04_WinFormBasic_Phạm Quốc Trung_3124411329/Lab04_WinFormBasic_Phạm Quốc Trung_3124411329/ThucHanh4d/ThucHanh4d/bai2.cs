﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ThucHanh4d
{
    public partial class bai2 : Form
    {
        public bai2()
        {
            InitializeComponent();
            rdoAutoColor.Checked = true;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void bai2_Load(object sender, EventArgs e)
        {

        }

        private void chkRegular_CheckedChanged(object sender, EventArgs e)
        {
            DoiFont();
        }

        private void chkBold_CheckedChanged(object sender, EventArgs e)
        {
            DoiFont();
        }

        private void chkMetalic_CheckedChanged(object sender, EventArgs e)
        {
            DoiFont();
        }

        private void chkBoldMetalic_CheckedChanged(object sender, EventArgs e)
        {
            DoiFont();
        }
        private void DoiFont()
        {
            FontStyle style = FontStyle.Regular;

            if (chkBold.Checked)
            {
                style = style | FontStyle.Bold;
            }

            if (chkMetalic.Checked)
            {
                style = style | FontStyle.Italic;
            }

            if (chkBoldMetalic.Checked)
            {
                style = style | FontStyle.Bold | FontStyle.Italic;
            }

            if (chkRegular.Checked)
            {
                style = FontStyle.Regular;
            }

            lblNoiDung.Font = new Font(
                lblNoiDung.Font.FontFamily,
                lblNoiDung.Font.Size,
                style
            );
        }
        private void rdoAutoColor_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoAutoColor.Checked)
                lblNoiDung.ForeColor = SystemColors.ControlText;
        }

        private void rdoRed_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoRed.Checked)
                lblNoiDung.ForeColor = Color.Red;
        }

        private void rdoGreen_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoGreen.Checked)
                lblNoiDung.ForeColor = Color.Green;
        }

        private void rdoBlue_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoBlue.Checked)
                lblNoiDung.ForeColor = Color.Blue;
        }
        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Bạn có chắc muốn thoát không?",
                "Xác nhận",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
    }
