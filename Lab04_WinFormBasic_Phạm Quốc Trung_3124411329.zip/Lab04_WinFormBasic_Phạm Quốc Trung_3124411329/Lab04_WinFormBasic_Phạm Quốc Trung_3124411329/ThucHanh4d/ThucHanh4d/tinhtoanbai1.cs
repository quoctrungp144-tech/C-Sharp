﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ThucHanh4d
{
    public class tinhtoanbai1
    {
        public double A { get; set; }
        public double B { get; set; }

        public tinhtoanbai1(double a, double b)
        {
            A = a;
            B = b;
        }

        public double Cong()
        {
            return A + B;
        }

        public double Tru()
        {
            return A - B;
        }

        public double Nhan()
        {
            return A * B;
        }

        public double Chia()
        {
            return A / B;
        }
    }
}
