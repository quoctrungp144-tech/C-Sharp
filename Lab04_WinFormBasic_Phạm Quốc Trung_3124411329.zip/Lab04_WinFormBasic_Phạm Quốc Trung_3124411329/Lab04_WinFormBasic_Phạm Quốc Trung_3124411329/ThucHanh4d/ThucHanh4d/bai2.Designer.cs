﻿namespace ThucHanh4d
{
    partial class bai2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            lblNoiDung = new Label();
            chkRegular = new CheckBox();
            chkBold = new CheckBox();
            chkMetalic = new CheckBox();
            chkBoldMetalic = new CheckBox();
            label3 = new Label();
            rdoAutoColor = new RadioButton();
            rdoRed = new RadioButton();
            rdoGreen = new RadioButton();
            rdoBlue = new RadioButton();
            btnExit = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(194, 73);
            label1.Name = "label1";
            label1.Size = new Size(56, 15);
            label1.TabIndex = 0;
            label1.Text = "FontStyle";
            label1.Click += label1_Click;
            // 
            // lblNoiDung
            // 
            lblNoiDung.AutoSize = true;
            lblNoiDung.Location = new Point(194, 9);
            lblNoiDung.Name = "lblNoiDung";
            lblNoiDung.Size = new Size(350, 15);
            lblNoiDung.TabIndex = 1;
            lblNoiDung.Text = "Trường đại học công nghệ thực phẩm Khoa công nghệt hông tin";
            // 
            // chkRegular
            // 
            chkRegular.AutoSize = true;
            chkRegular.Location = new Point(194, 118);
            chkRegular.Name = "chkRegular";
            chkRegular.Size = new Size(66, 19);
            chkRegular.TabIndex = 2;
            chkRegular.Text = "Regular";
            chkRegular.UseVisualStyleBackColor = true;
            chkRegular.CheckedChanged += chkRegular_CheckedChanged;
            // 
            // chkBold
            // 
            chkBold.AutoSize = true;
            chkBold.Location = new Point(194, 159);
            chkBold.Name = "chkBold";
            chkBold.Size = new Size(50, 19);
            chkBold.TabIndex = 3;
            chkBold.Text = "Bold";
            chkBold.UseVisualStyleBackColor = true;
            chkBold.CheckedChanged += chkBold_CheckedChanged;
            // 
            // chkMetalic
            // 
            chkMetalic.AutoSize = true;
            chkMetalic.Location = new Point(194, 201);
            chkMetalic.Name = "chkMetalic";
            chkMetalic.Size = new Size(65, 19);
            chkMetalic.TabIndex = 4;
            chkMetalic.Text = "Metalic";
            chkMetalic.UseVisualStyleBackColor = true;
            chkMetalic.CheckedChanged += chkMetalic_CheckedChanged;
            // 
            // chkBoldMetalic
            // 
            chkBoldMetalic.AutoSize = true;
            chkBoldMetalic.Location = new Point(194, 247);
            chkBoldMetalic.Name = "chkBoldMetalic";
            chkBoldMetalic.Size = new Size(115, 19);
            chkBoldMetalic.TabIndex = 5;
            chkBoldMetalic.Text = "Bold and Metalic";
            chkBoldMetalic.UseVisualStyleBackColor = true;
            chkBoldMetalic.CheckedChanged += chkBoldMetalic_CheckedChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(446, 73);
            label3.Name = "label3";
            label3.Size = new Size(36, 15);
            label3.TabIndex = 6;
            label3.Text = "Color";
            // 
            // rdoAutoColor
            // 
            rdoAutoColor.AutoSize = true;
            rdoAutoColor.Location = new Point(450, 117);
            rdoAutoColor.Name = "rdoAutoColor";
            rdoAutoColor.Size = new Size(83, 19);
            rdoAutoColor.TabIndex = 7;
            rdoAutoColor.TabStop = true;
            rdoAutoColor.Text = "Auto Color";
            rdoAutoColor.UseVisualStyleBackColor = true;
            // 
            // rdoRed
            // 
            rdoRed.AutoSize = true;
            rdoRed.Location = new Point(446, 158);
            rdoRed.Name = "rdoRed";
            rdoRed.Size = new Size(45, 19);
            rdoRed.TabIndex = 8;
            rdoRed.TabStop = true;
            rdoRed.Text = "Red";
            rdoRed.UseVisualStyleBackColor = true;
            rdoRed.CheckedChanged += radioButton2_CheckedChanged;
            // 
            // rdoGreen
            // 
            rdoGreen.AutoSize = true;
            rdoGreen.Location = new Point(446, 200);
            rdoGreen.Name = "rdoGreen";
            rdoGreen.Size = new Size(56, 19);
            rdoGreen.TabIndex = 9;
            rdoGreen.TabStop = true;
            rdoGreen.Text = "Green";
            rdoGreen.UseVisualStyleBackColor = true;
            // 
            // rdoBlue
            // 
            rdoBlue.AutoSize = true;
            rdoBlue.Location = new Point(446, 246);
            rdoBlue.Name = "rdoBlue";
            rdoBlue.Size = new Size(48, 19);
            rdoBlue.TabIndex = 10;
            rdoBlue.TabStop = true;
            rdoBlue.Text = "Blue";
            rdoBlue.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(446, 306);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(75, 23);
            btnExit.TabIndex = 11;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.Click += btnExit_Click;
            // 
            // bai2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnExit);
            Controls.Add(rdoBlue);
            Controls.Add(rdoGreen);
            Controls.Add(rdoRed);
            Controls.Add(rdoAutoColor);
            Controls.Add(label3);
            Controls.Add(chkBoldMetalic);
            Controls.Add(chkMetalic);
            Controls.Add(chkBold);
            Controls.Add(chkRegular);
            Controls.Add(lblNoiDung);
            Controls.Add(label1);
            Name = "bai2";
            Text = "bai2";
            Load += bai2_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label lblNoiDung;
        private CheckBox chkRegular;
        private CheckBox chkBold;
        private CheckBox chkMetalic;
        private CheckBox chkBoldMetalic;
        private Label label3;
        private RadioButton rdoAutoColor;
        private RadioButton rdoRed;
        private RadioButton rdoGreen;
        private RadioButton rdoBlue;
        private Button btnExit;
    }
}