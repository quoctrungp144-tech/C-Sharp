namespace BaiTap;

// Lớp biểu diễn mảng 2 chiều
public class Mang2D
{
    // Mảng 2 chiều
    private int[,] a;

    // Constructor mặc định
    public Mang2D() { a = new int[0, 0]; }

    // Constructor tạo mảng có n dòng, m cột
    public Mang2D(int n, int m) { a = new int[n, m]; }

    // Constructor tạo mảng từ mảng có sẵn
    public Mang2D(int[,] arr) { a = (int[,])arr.Clone(); }

    // Constructor sao chép
    public Mang2D(Mang2D other) : this(other.a) { }

    // Số dòng của mảng
    public int Rows => a.GetLength(0);

    // Số cột của mảng
    public int Cols => a.GetLength(1);

    // Indexer truy cập phần tử trong mảng
    public int this[int i, int j]
    {
        get => a[i, j];
        set => a[i, j] = value;
    }

    // Nhập mảng 2 chiều
    public void Input()
    {
        // Nhập số dòng và số cột
        int n = Helper.ReadInt("Số dòng n: ");
        int m = Helper.ReadInt("Số cột m: ");

        // Tạo mảng mới
        a = new int[Math.Max(n, 0), Math.Max(m, 0)];

        // Nhập từng phần tử
        for (int i = 0; i < Rows; i++)
            for (int j = 0; j < Cols; j++)
                a[i, j] = Helper.ReadInt($"  a[{i},{j}] = ");
    }

    // Xuất mảng 2 chiều
    public void Output()
    {
        // Duyệt từng dòng
        for (int i = 0; i < Rows; i++)
        {
            // Duyệt từng cột
            for (int j = 0; j < Cols; j++)
                Console.Write($"{a[i, j],5}");

            // Xuống dòng
            Console.WriteLine();
        }
    }

    // Kiểm tra một số có phải số nguyên tố hay không
    private static bool LaNguyenTo(int x)
    {
        // Số nhỏ hơn 2 không phải số nguyên tố
        if (x < 2) return false;

        // Kiểm tra các ước từ 2 đến căn bậc hai của x
        for (int i = 2; (long)i * i <= x; i++)
            if (x % i == 0) return false;

        // Không tìm thấy ước nên là số nguyên tố
        return true;
    }

    // Tìm các số nguyên tố trong mảng
    public List<int> TimNguyenTo()
    {
        // Danh sách lưu các số nguyên tố
        List<int> kq = new List<int>();

        // Duyệt qua tất cả phần tử trong mảng
        foreach (int x in a)
            if (LaNguyenTo(x))
                kq.Add(x);

        // Trả về danh sách số nguyên tố
        return kq;
    }
}

// Lớp thực hiện bài 2_4
public static class Bai2_4
{
    public static void Run()
    {
        // Tạo đối tượng mảng 2 chiều
        Mang2D m = new Mang2D();

        // Nhập mảng
        m.Input();

        // In ma trận
        Console.WriteLine("Ma trận:");
        m.Output();

        // Tìm và in các số nguyên tố
        Console.WriteLine(
            "Các số nguyên tố: " + string.Join(" ", m.TimNguyenTo())
        );
    }
}