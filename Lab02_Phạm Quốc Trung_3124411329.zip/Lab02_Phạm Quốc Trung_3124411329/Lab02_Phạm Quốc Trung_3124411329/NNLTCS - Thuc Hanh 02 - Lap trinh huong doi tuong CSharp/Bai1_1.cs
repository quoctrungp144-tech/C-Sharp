namespace BaiTap;

public static class Bai1_1
{
    public static void Run()
    {
        string hoTen = Helper.ReadString("Họ tên: ");
        int namSinh = Helper.ReadInt("Năm sinh: ");
        int tuoi = DateTime.Now.Year - namSinh;
        Console.WriteLine($"Sinh viên {hoTen} có tuổi: {tuoi}");
    }
}
