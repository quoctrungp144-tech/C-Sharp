namespace BaiTap;

public class Point
{
    private double x, y;
    public double X { get => x; set => x = value; }
    public double Y { get => y; set => y = value; }

    public Point() { x = 0; y = 0; }
    public Point(double x, double y) { this.x = x; this.y = y; }

    public void Input()
    {
        x = Helper.ReadDouble("  x = ");
        y = Helper.ReadDouble("  y = ");
    }
    public void Output() => Console.WriteLine(this);
    public override string ToString() => $"({x}, {y})";

    public static Point operator +(Point a, Point b) => new Point(a.x + b.x, a.y + b.y);
    public static Point operator -(Point a, Point b) => new Point(a.x - b.x, a.y - b.y);
    public static Point operator -(Point a) => new Point(-a.x, -a.y);

    // (a) Khoảng cách
    public double KhoangCach(Point p) => Math.Sqrt((x - p.x) * (x - p.x) + (y - p.y) * (y - p.y));
    public static double KhoangCach(Point a, Point b) => a.KhoangCach(b);

    // (b) Trung điểm
    public Point TrungDiem(Point p) => new Point((x + p.x) / 2, (y + p.y) / 2);
    public static Point TrungDiem(Point a, Point b) => new Point((a.x + b.x) / 2, (a.y + b.y) / 2);
}

public static class Bai1_2
{
    public static void Run()
    {
        Point A = new Point(), B = new Point();
        Console.WriteLine("Nhập điểm A:"); A.Input();
        Console.WriteLine("Nhập điểm B:"); B.Input();

        Console.Write("A = "); A.Output();
        Console.Write("B = "); B.Output();
        Console.WriteLine($"A + B = {A + B}");
        Console.WriteLine($"A - B = {A - B}");
        Console.WriteLine($"-A    = {-A}");

        Console.WriteLine($"Khoảng cách (phương thức thành viên): {A.KhoangCach(B)}");
        Console.WriteLine($"Khoảng cách (phương thức tĩnh)      : {Point.KhoangCach(A, B)}");
        Console.WriteLine($"Trung điểm (phương thức thành viên) : {A.TrungDiem(B)}");
        Console.WriteLine($"Trung điểm (phương thức tĩnh)       : {Point.TrungDiem(A, B)}");
    }
}
