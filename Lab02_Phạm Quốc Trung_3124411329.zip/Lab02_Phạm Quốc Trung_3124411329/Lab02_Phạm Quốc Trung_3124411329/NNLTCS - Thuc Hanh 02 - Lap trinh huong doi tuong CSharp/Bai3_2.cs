namespace BaiTap;
// Lớp thực hiện chức năng sắp xếp
public static class MySorter
{
    // Mô phỏng Array.Sort: đối tượng phải cài đặt interface IComparable<T>
    // Kiểu dữ liệu T phải cài đặt IComparable<T>
    public static void Sort<T>(T[] a) where T : IComparable<T>
    {
        for (int i = 0; i < a.Length - 1; i++)
            for (int j = i + 1; j < a.Length; j++)
                if (a[i].CompareTo(a[j]) > 0)
                    (a[i], a[j]) = (a[j], a[i]);
    }
}
// Lớp thực hiện bài 3_2
public static class Bai3_2
{
    public static void Run()
    {
        // Tạo mảng số nguyên
        int[] so = { 5, 2, 9, 1, 7 };
        // Tạo mảng số nguyên
        MySorter.Sort(so);
        // Xuất mảng sau khi sắp xếp
        Console.WriteLine("int[]    : " + string.Join(" ", so));
        // Tạo mảng chuỗi
        string[] chuoi = { "cam", "xoài", "bưởi", "ổi" };

        // Sắp xếp mảng chuỗi
        MySorter.Sort(chuoi);
        // Xuất mảng chuỗi sau khi sắp xếp
        Console.WriteLine("string[] : " + string.Join(" ", chuoi));
        // Tạo mảng sinh viên
        SinhVien[] sv =
        {
            new SinhVien("An", 8.5), new SinhVien("Bình", 6.0), new SinhVien("Chi", 9.0)
        };
        // Sắp xếp sinh viên theo điểm tăng dần
        // SinhVien đã cài đặt IComparable<SinhVien>
        MySorter.Sort(sv);
        // Xuất danh sách sinh viên sau khi sắp xếp
        Console.WriteLine("SinhVien[] (theo điểm tăng): " + string.Join(", ", sv.Select(s => s.ToString())));
    }
}
