namespace BaiTap;

// Lớp nhân viên cơ bản
public class NhanVienCoBan
{
    // Số tiền bị trừ cho mỗi ngày vắng
    public const double TienTruMoiNgayVang = 100000;

    // Họ tên nhân viên
    public string HoTen { get; set; }

    // Mức lương của nhân viên
    public double MucLuong { get; set; }

    // Số ngày vắng
    public int SoNgayVang { get; set; }

    // Nhập thông tin nhân viên
    public void Input()
    {
        HoTen = Helper.ReadString("  Họ tên: ");
        MucLuong = Helper.ReadDouble("  Mức lương: ");
        SoNgayVang = Helper.ReadInt("  Số ngày vắng: ");
    }

    // Tính lương thực lĩnh
    public double LuongThucLinh() =>
        MucLuong - SoNgayVang * TienTruMoiNgayVang;
}


// Lớp phòng ban
public class PhongBan
{
    // Danh sách nhân viên trong phòng ban
    private List<NhanVienCoBan> ds = new List<NhanVienCoBan>();

    // Nhập danh sách nhân viên
    public void Input()
    {
        // Nhập số lượng nhân viên
        int n = Helper.ReadInt("Số nhân viên: ");

        // Nhập thông tin từng nhân viên
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Nhân viên {i + 1}:");

            // Tạo nhân viên mới
            var nv = new NhanVienCoBan();

            // Nhập thông tin nhân viên
            nv.Input();

            // Thêm nhân viên vào danh sách
            ds.Add(nv);
        }
    }

    // Xuất danh sách nhân viên
    public void Output()
    {
        // Duyệt qua từng nhân viên
        foreach (var nv in ds)
            Console.WriteLine(
                $"  {nv.HoTen,-20} lương {nv.MucLuong:N0}, " +
                $"vắng {nv.SoNgayVang} ngày -> " +
                $"thực lĩnh {nv.LuongThucLinh():N0}"
            );
    }

    // Tính tổng lương thực lĩnh của phòng ban
    public double TongLuong() =>
        ds.Sum(nv => nv.LuongThucLinh());
}


// Lớp thực hiện bài 2_5
public static class Bai2_5
{
    public static void Run()
    {
        // Tạo phòng ban
        PhongBan pb = new PhongBan();

        // Nhập danh sách nhân viên
        pb.Input();

        // Xuất danh sách nhân viên
        pb.Output();

        // Tính và xuất tổng lương phòng ban
        Console.WriteLine(
            $"Tổng lương phòng ban: {pb.TongLuong():N0} VNĐ"
        );
    }
}