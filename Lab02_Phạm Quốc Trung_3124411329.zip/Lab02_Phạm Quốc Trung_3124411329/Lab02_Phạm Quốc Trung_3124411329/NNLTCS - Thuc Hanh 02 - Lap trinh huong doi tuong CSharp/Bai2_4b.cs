namespace BaiTap;

// Lớp biểu diễn dãy các phân số
public class DayPhanSo
{
    // Mảng lưu các phân số
    private PhanSo[] a = new PhanSo[0];

    // Constructor mặc định
    public DayPhanSo() { }

    // Constructor tạo dãy có n phân số
    public DayPhanSo(int n)
    {
        // Tạo mảng n phần tử
        a = new PhanSo[n];

        // Khởi tạo từng phân số
        for (int i = 0; i < n; i++)
            a[i] = new PhanSo();
    }

    // Indexer truy cập phân số theo vị trí
    public PhanSo this[int i]
    {
        get => a[i];
        set => a[i] = value;
    }

    // Nhập dãy phân số
    public void Input()
    {
        // Nhập số lượng phân số
        int n = Helper.ReadInt("Số phân số n: ");

        // Tạo mảng mới
        a = new PhanSo[Math.Max(n, 0)];

        // Nhập từng phân số
        for (int i = 0; i < a.Length; i++)
        {
            Console.WriteLine($"Phân số thứ {i + 1}:");
            a[i] = PhanSo.Read();
        }
    }

    // Xuất dãy phân số
    public void Output() =>
        Console.WriteLine(string.Join("  ", a.Select(p => p.ToString())));

    // Tính tổng các phân số
    public PhanSo Tong()
    {
        // Khởi tạo tổng bằng 0
        PhanSo s = new PhanSo(0);

        // Cộng lần lượt các phân số
        foreach (var p in a)
            s = s + p;

        // Trả về tổng
        return s;
    }
}

// Lớp thực hiện bài 2_4b
public static class Bai2_4b
{
    public static void Run()
    {
        // Tạo đối tượng dãy phân số
        DayPhanSo d = new DayPhanSo();

        // Nhập dãy phân số
        d.Input();

        // Xuất dãy phân số
        Console.Write("Dãy phân số: ");
        d.Output();

        // Tính và xuất tổng các phân số
        Console.WriteLine("Tổng = " + d.Tong());
    }
}