namespace BaiTap;

// Lớp SinhVien thực hiện IComparable để có thể sắp xếp
public class SinhVien : IComparable<SinhVien>
{
    // Họ tên sinh viên
    public string HoTen { get; set; }

    // Điểm của sinh viên
    public double Diem { get; set; }

    // Constructor mặc định
    public SinhVien() { }

    // Constructor có tham số
    public SinhVien(string hoTen, double diem)
    {
        HoTen = hoTen;
        Diem = diem;
    }

    // Nhập thông tin sinh viên
    public void Input()
    {
        HoTen = Helper.ReadString("  Họ tên: ");
        Diem = Helper.ReadDouble("  Điểm: ");
    }

    // So sánh sinh viên theo điểm tăng dần
    public int CompareTo(SinhVien other) =>
        Diem.CompareTo(other.Diem);

    // Chuyển thông tin sinh viên thành chuỗi
    public override string ToString() =>
        $"{HoTen} ({Diem})";
}


// Lớp thực hiện bài 3_1
public static class Bai3_1
{
    public static void Run()
    {
        // Nhập số lượng sinh viên
        int n = Helper.ReadInt("Số sinh viên: ");

        // Tạo mảng sinh viên
        SinhVien[] ds = new SinhVien[n];

        // Nhập thông tin từng sinh viên
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Sinh viên {i + 1}:");

            // Tạo sinh viên mới
            ds[i] = new SinhVien();

            // Nhập thông tin sinh viên
            ds[i].Input();
        }

        // Sắp xếp mảng theo điểm tăng dần
        // dựa vào CompareTo()
        Array.Sort(ds);

        // In danh sách sau khi sắp xếp
        Console.WriteLine("Sau khi sắp xếp theo điểm tăng dần:");

        // Duyệt và xuất từng sinh viên
        foreach (var sv in ds)
            Console.WriteLine("  " + sv);
    }
}