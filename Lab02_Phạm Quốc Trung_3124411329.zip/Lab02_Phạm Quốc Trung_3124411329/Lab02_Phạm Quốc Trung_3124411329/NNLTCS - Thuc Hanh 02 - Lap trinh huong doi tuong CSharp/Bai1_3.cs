namespace BaiTap;

public class Person
{
    private int id;
    private string name;
    private int yob;
    private int yod;

    public int Id => id;
    public string Name => name;
    public int Yob => yob;
    public int Yod => yod;

    public Person() { id = 0; name = ""; yob = 0; yod = 0; }
    public Person(Person p) { id = p.id; name = p.name; yob = p.yob; yod = p.yod; }

    public void Input()
    {
        id = Helper.ReadInt("  Mã (id): ");
        name = Helper.ReadString("  Họ tên: ");
        yob = Helper.ReadInt("  Năm sinh: ");
        yod = Helper.ReadInt("  Năm mất (0 nếu còn sống): ");
    }

    public void Output()
    {
        Console.WriteLine($"  [{id}] {name} - Sinh: {yob} - " + (IsLiving() ? "Còn sống" : $"Mất năm {yod}"));
    }

    public bool IsLiving() => yod == 0;
}

public static class Bai1_3
{
    public static void Run()
    {
        Person p = new Person();
        Console.WriteLine("Nhập thông tin người:");
        p.Input();
        Person q = new Person(p);   // copy constructor
        Console.WriteLine("Thông tin (bản sao):");
        q.Output();
        Console.WriteLine("Còn sống? " + q.IsLiving());
    }
}
