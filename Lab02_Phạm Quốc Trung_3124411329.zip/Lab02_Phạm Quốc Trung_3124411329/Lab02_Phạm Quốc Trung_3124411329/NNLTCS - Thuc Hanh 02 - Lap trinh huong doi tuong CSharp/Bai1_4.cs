using System;

namespace BaiTap;

/// 
/// Đại diện cho một phân số tối giản trong toán học.
/// Thực thi giao diện IComparable để hỗ trợ so sánh lớn nhỏ giữa các phân số.
/// 
public class PhanSo : IComparable<PhanSo>
{
    // Các trường (fields) lưu trữ tử số và mẫu số. 
    // Được giấu kín (private) để đảm bảo tính đóng gói (encapsulation).
    private long tu, mau; 

    // Các thuộc tính (properties) chỉ đọc (readonly) cho phép truy xuất giá trị tử và mẫu từ bên ngoài.
    public long Tu => tu;
    public long Mau => mau;

    #region Các Constructor (Hàm khởi tạo)

    // Khởi tạo phân số mặc định là 0/1 (tương đương 0).
    public PhanSo() : this(0, 1) { }

    // Khởi tạo phân số có dạng một số nguyên (tử = tu, mẫu = 1).
    public PhanSo(long tu) : this(tu, 1) { }

    // Khởi tạo phân số đầy đủ với tử và mẫu, đồng thời tự động tối giản hóa phân số.
    public PhanSo(long tu, long mau)
    {
        // Kiểm tra điều kiện mẫu số không được bằng 0.
        if (mau == 0) throw new DivideByZeroException("Mẫu số phải khác 0");

        // Quy ước chuẩn hóa: Dấu trừ (-) luôn nằm ở tử số, mẫu số luôn dương (> 0).
        if (mau < 0) { tu = -tu; mau = -mau; }

        // Tìm ước chung lớn nhất (UCLN) của giá trị tuyệt đối tử và mẫu để tối giản phân số.
        long g = UCLN(Math.Abs(tu), mau);
        this.tu = tu / g;
        this.mau = mau / g;
    }

    // Constructor sao chép (copy constructor): tạo một phân số mới từ phân số có sẵn.
    public PhanSo(PhanSo p) : this(p.tu, p.mau) { }

    #endregion

    #region Phương thức hỗ trợ (Helper methods)

    // Thuật toán Euclid để tìm Ước chung lớn nhất (UCLN) nhằm tối giản phân số.
    private static long UCLN(long a, long b)
    {
        while (b != 0) { long t = a % b; a = b; b = t; }
        return a == 0 ? 1 : a;
    }

    // Nhập giá trị cho phân số từ bàn phím thông qua lớp Helper.
    public void Input()
    {
        long t = Helper.ReadLong("  Tử số: ");
        long m;
        // Bắt buộc người dùng nhập mẫu số khác 0.
        do { m = Helper.ReadLong("  Mẫu số (khác 0): "); } while (m == 0);

        // Tạo phân số tạm thời để chuẩn hóa và tối giản, sau đó gán lại cho đối tượng hiện tại.
        var p = new PhanSo(t, m);
        tu = p.tu; mau = p.mau;
    }

    // Phương thức tĩnh (static) giúp khởi tạo và đọc phân số mới trực tiếp.
    public static PhanSo Read()
    {
        var p = new PhanSo();
        p.Input();
        return p;
    }

    // Ghi đè phương thức ToString() để hiển thị phân số dưới dạng chuỗi (Ví dụ: "3/4" hoặc "5" nếu mẫu là 1).
    public override string ToString() => mau == 1 ? tu.ToString() : $"{tu}/{mau}";

    #endregion

    #region Overload Toán tử (Operators)

    // Toán tử một ngôi (Unary operators)
    public static PhanSo operator +(PhanSo a) => new PhanSo(a);                  // Giữ nguyên dấu
    public static PhanSo operator -(PhanSo a) => new PhanSo(-a.tu, a.mau);        // Đổi dấu phân số

    // Toán tử hai ngôi (Binary operators) thực hiện các phép toán cộng, trừ, nhân, chia phân số.
    // Công thức cộng: a/b + c/d = (a*d + b*c) / (b*d)
    public static PhanSo operator +(PhanSo a, PhanSo b) => new PhanSo(a.tu * b.mau + b.tu * a.mau, a.mau * b.mau);
    
    // Công thức trừ: a/b - c/d = (a*d - b*c) / (b*d)
    public static PhanSo operator -(PhanSo a, PhanSo b) => new PhanSo(a.tu * b.mau - b.tu * a.mau, a.mau * b.mau);
    
    // Công thức nhân: (a/b) * (c/d) = (a*c) / (b*d)
    public static PhanSo operator *(PhanSo a, PhanSo b) => new PhanSo(a.tu * b.tu, a.mau * b.mau);
    
    // Công thức chia: (a/b) / (c/d) = (a*d) / (b*c)
    public static PhanSo operator /(PhanSo a, PhanSo b) => new PhanSo(a.tu * b.mau, a.mau * b.tu);

    #endregion

    #region So sánh (Comparisons)

    // Thực hiện so sánh hai phân số thông qua giao diện IComparable.
    // Quy tắc quy đồng nhân chéo: a/b so với c/d tương đương so sánh (a*d) với (c*b).
    public int CompareTo(PhanSo other) => (tu * other.mau).CompareTo(other.tu * mau);

    // Overload các toán tử so sánh lớn hơn, nhỏ hơn, bằng,... dựa vào phương thức CompareTo ở trên.
    public static bool operator >(PhanSo a, PhanSo b) => a.CompareTo(b) > 0;
    public static bool operator <(PhanSo a, PhanSo b) => a.CompareTo(b) < 0;
    public static bool operator >=(PhanSo a, PhanSo b) => a.CompareTo(b) >= 0;
    public static bool operator <=(PhanSo a, PhanSo b) => a.CompareTo(b) <= 0;
    public static bool operator ==(PhanSo a, PhanSo b) => a.CompareTo(b) == 0;
    public static bool operator !=(PhanSo a, PhanSo b) => a.CompareTo(b) != 0;

    // Ghi đè Equals và GetHashCode để đảm bảo tính nhất quán khi so sánh đối tượng.
    public override bool Equals(object obj) => obj is PhanSo p && this == p;
    public override int GetHashCode() => HashCode.Combine(tu, mau);

    #endregion
}

/// 
/// Lớp chứa chương trình mẫu thực hiện bài tập nhập vào 2 phân số và kiểm tra các phép toán, so sánh.
/// 
public static class Bai1_4
{
    public static void Run()
    {
        // Nhập hai phân số a và b từ bàn phím.
        Console.WriteLine("Nhập phân số a:"); PhanSo a = PhanSo.Read();
        Console.WriteLine("Nhập phân số b:"); PhanSo b = PhanSo.Read();

        // In ra giá trị cơ bản của a và b.
        Console.WriteLine($"a = {a}, b = {b}");
        
        // Thử nghiệm toán tử một ngôi.
        Console.WriteLine($"+a = {+a}, -a = {-a}");
        
        // Thử nghiệm các phép tính số học hai ngôi (+, -, *, /).
        Console.WriteLine($"a + b = {a + b}");
        Console.WriteLine($"a - b = {a - b}");
        Console.WriteLine($"a * b = {a * b}");
        
        // Kiểm tra điều kiện mẫu/tử khác 0 trước khi chia để tránh ngoại lệ chia cho 0.
        if (b.Tu != 0) Console.WriteLine($"a / b = {a / b}");
        else Console.WriteLine("a / b: không chia được (b = 0)");
        
        // Thử nghiệm các phép toán so sánh lớn hơn, nhỏ hơn, bằng nhau.
        Console.WriteLine($"a > b : {a > b}");
        Console.WriteLine($"a < b : {a < b}");
        Console.WriteLine($"a >= b: {a >= b}");
        Console.WriteLine($"a <= b: {a <= b}");
        Console.WriteLine($"a == b: {a == b}");
        Console.WriteLine($"a != b: {a != b}");
    }
}