using System;

namespace BaiTap;

// Đơn thức P(x) = a.x^n
public class DonThuc
{
    private double a;
    private int n;
    
    // Thuộc tính cho hệ số a và số mũ n (số mũ luôn >= 0)
    public double A { get => a; set => a = value; }
    public int N { get => n; set => n = value < 0 ? 0 : value; }

    // Các hàm khởi tạo
    public DonThuc() { a = 0; n = 0; }
    public DonThuc(double a, int n) { this.a = a; this.n = n < 0 ? 0 : n; }

    // Nhập hệ số và số mũ từ bàn phím
    public void Input()
    {
        a = Helper.ReadDouble("  Hệ số a: ");
        int t;
        do { t = Helper.ReadInt("  Số mũ n (>= 0): "); } while (t < 0);
        n = t;
    }

    // (a) Tính giá trị đơn thức tại x
    public double TinhGiaTri(double x) => a * Math.Pow(x, n);

    // (b) Tính đạo hàm của đơn thức: Q(x) = a.n.x^(n-1)
    public DonThuc DaoHam() => n == 0 ? new DonThuc(0, 0) : new DonThuc(a * n, n - 1);

    // Hiển thị đơn thức dưới dạng chuỗi
    public override string ToString() => n == 0 ? $"{a}" : (n == 1 ? $"{a}x" : $"{a}x^{n}");
}

public static class Bai1_5
{
    public static void Run()
    {
        DonThuc p = new DonThuc();
        Console.WriteLine("Nhập đơn thức P(x) = a.x^n:");
        p.Input();
        
        Console.WriteLine($"P(x) = {p}");
        
        double x = Helper.ReadDouble("Nhập x: ");
        Console.WriteLine($"P({x}) = {p.TinhGiaTri(x)}");
        
        Console.WriteLine($"P'(x) = {p.DaoHam()}");
    }
}