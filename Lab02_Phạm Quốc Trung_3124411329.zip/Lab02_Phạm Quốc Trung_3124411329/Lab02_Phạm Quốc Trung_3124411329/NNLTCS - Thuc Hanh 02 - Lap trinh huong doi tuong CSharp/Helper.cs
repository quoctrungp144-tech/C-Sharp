using System.Globalization;
namespace BaiTap;

public static class Helper
{
    public static int ReadInt(string msg)
    {
        while (true)
        {
            Console.Write(msg);
            if (int.TryParse(Console.ReadLine(), out int v)) return v;
            Console.WriteLine("Giá trị không hợp lệ, nhập lại.");
        }
    }
    public static long ReadLong(string msg)
    {
        while (true)
        {
            Console.Write(msg);
            if (long.TryParse(Console.ReadLine(), out long v)) return v;
            Console.WriteLine("Giá trị không hợp lệ, nhập lại.");
        }
    }
    public static double ReadDouble(string msg)
    {
        while (true)
        {
            Console.Write(msg);
            string s = (Console.ReadLine() ?? "").Replace(',', '.');
            if (double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out double v)) return v;
            Console.WriteLine("Giá trị không hợp lệ, nhập lại.");
        }
    }
    public static string ReadString(string msg)
    {
        Console.Write(msg);
        return Console.ReadLine() ?? "";
    }
}
