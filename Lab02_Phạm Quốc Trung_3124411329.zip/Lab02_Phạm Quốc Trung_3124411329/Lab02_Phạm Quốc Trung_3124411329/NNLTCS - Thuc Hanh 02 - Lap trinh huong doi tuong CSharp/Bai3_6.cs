namespace BaiTap;

// Lớp thí sinh trừu tượng
public abstract class ThiSinh
{
    // Số báo danh
    public string Sbd { get; set; }

    // Họ tên thí sinh
    public string HoTen { get; set; }

    // Điểm 3 bài thi
    public double Bai1 { get; set; }
    public double Bai2 { get; set; }
    public double Bai3 { get; set; }

    // Nhập thông tin thí sinh
    public virtual void Input()
    {
        Sbd = Helper.ReadString("  SBD: ");
        HoTen = Helper.ReadString("  Họ tên: ");
        Bai1 = Helper.ReadDouble("  Điểm bài 1: ");
        Bai2 = Helper.ReadDouble("  Điểm bài 2: ");
        Bai3 = Helper.ReadDouble("  Điểm bài 3: ");
    }

    // Loại thí sinh
    public abstract string Loai { get; }

    // Tính tổng điểm
    public abstract double TongDiem();

    // Xuất thông tin thí sinh
    public void Output() =>
        Console.WriteLine(
            $"  {Sbd,-8} {HoTen,-20} {Loai,-8} Tổng điểm: {TongDiem()}"
        );
}


// Thí sinh chuyên
public class ThiSinhChuyen : ThiSinh
{
    // Điểm tiếng Anh
    public double TiengAnh { get; set; }

    // Loại thí sinh
    public override string Loai => "Chuyên";

    // Nhập thông tin thí sinh chuyên
    public override void Input()
    {
        // Nhập thông tin chung
        base.Input();

        // Nhập điểm tiếng Anh
        TiengAnh = Helper.ReadDouble("  Điểm tiếng Anh: ");
    }

    // Tính tổng điểm thí sinh chuyên
    public override double TongDiem()
    {
        // Cộng điểm 3 bài thi
        double tong = Bai1 + Bai2 + Bai3;

        // Tiếng Anh từ 9 đến 10 được cộng 2 điểm
        if (TiengAnh >= 9 && TiengAnh <= 10)
            tong += 2;

        // Tiếng Anh từ 7 đến 8 được cộng 1 điểm
        else if (TiengAnh >= 7 && TiengAnh <= 8)
            tong += 1;

        return tong;
    }
}


// Thí sinh siêu cúp
public class ThiSinhSieuCup : ThiSinh
{
    // Điểm CSDL
    public double Csdl { get; set; }

    // Loại thí sinh
    public override string Loai => "Siêu cúp";

    // Nhập thông tin thí sinh siêu cúp
    public override void Input()
    {
        // Nhập thông tin chung
        base.Input();

        // Nhập điểm CSDL
        Csdl = Helper.ReadDouble("  Điểm CSDL: ");
    }

    // Tính tổng điểm thí sinh siêu cúp
    public override double TongDiem() =>
        Bai1 + Bai2 + Bai3 + Csdl;
}


// Lớp quản lý cuộc thi
public class CuocThi
{
    // Danh sách thí sinh
    private List<ThiSinh> ds = new List<ThiSinh>();

    // Nhập danh sách thí sinh
    public void Input()
    {
        // Nhập số lượng thí sinh
        int n = Helper.ReadInt("Số thí sinh: ");

        // Nhập từng thí sinh
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"Thí sinh {i + 1}:");

            // Nhập loại thí sinh
            int loai;
            do
            {
                loai = Helper.ReadInt(
                    "  Đối tượng (1 = Chuyên, 2 = Siêu cúp): "
                );
            }
            while (loai != 1 && loai != 2);

            // Tạo thí sinh theo loại
            ThiSinh ts = loai == 1
                ? new ThiSinhChuyen()
                : new ThiSinhSieuCup();

            // Nhập thông tin thí sinh
            ts.Input();

            // Thêm thí sinh vào danh sách
            ds.Add(ts);
        }
    }

    // Xuất kết quả cuộc thi
    public void Output()
    {
        Console.WriteLine("Kết quả cuộc thi:");

        // Duyệt và xuất từng thí sinh
        foreach (var ts in ds)
            ts.Output();
    }
}


// Lớp thực hiện bài 3_6
public static class Bai3_6
{
    public static void Run()
    {
        // Tạo đối tượng cuộc thi
        CuocThi ct = new CuocThi();

        // Nhập danh sách thí sinh
        ct.Input();

        // Xuất kết quả
        ct.Output();
    }
}